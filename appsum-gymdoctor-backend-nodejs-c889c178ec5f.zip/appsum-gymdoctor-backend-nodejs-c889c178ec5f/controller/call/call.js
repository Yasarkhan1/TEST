const user = require('../../model/user')
const walletModel = require('../../model/wallet')
// const fs = require('fs')

var AccessToken = require('twilio').jwt.AccessToken;
var VideoGrant = AccessToken.VideoGrant;

const commonFunction = require('../../utility/common')
// Substitute your Twilio AccountSid and ApiKey details
var ACCOUNT_SID = 'AC76818e8eac68fa014d6ff34a9b0d65a6';
var API_KEY_SID = 'SKfb2ce1e93223ade171fabecbe34c4efb';
var API_KEY_SECRET = 'BzcwYdtMWSY3byG4Tob3GxzvGz13oN5Z';
// var apn = require("apn");
// var service = new apn.Provider({
//     cert: __dirname + '/../../../voipCertificate/cert.pem',
//     key: __dirname + '/../../../voipCertificate/key.pem'
// });


module.exports = {


    getTwilioToken: async (req, res) => {
        try {
            console.log("============req.body", req.body)
            userId = req.userId
            let roomName = `room_${req.body.appointmentId}`

            // Create an Access Token
            var accessToken = new AccessToken(
                ACCOUNT_SID,
                API_KEY_SID,
                API_KEY_SECRET
            );

            // Set the Identity of this token
            accessToken.identity = req.body.receiverId;

            // Grant access to Video
            var grant = new VideoGrant();
            grant.room = roomName;
            accessToken.addGrant(grant);

            // Serialize the token as a JWT
            var jwt = accessToken.toJwt();
            let senderData = await user.findOne({
                _id: userId
            })
            let query = {
                _id: req.body.receiverId
            }
            let receiverData = await user.findOne(query)
            if (!receiverData) {
                return res.status(404).send({
                    responseMessage: "User Not found"
                })
            }

            var fullName;
            if (senderData.userType == "DOCTOR") {
                fullName = senderData.fullName
            } else {
                fullName = senderData.firstName + ' ' + senderData.lastName
            }

            let pushdata = {
                senderId: userId,
                receiverId: req.body.receiverId,
                fullName: fullName,
                profilePic: senderData.profilePic,
                pushType: req.body.pushType, //"audio/video",
                twilioToken: jwt,
                room: roomName
            }

            // Create an Access Token
            var accessToken1 = new AccessToken(
                ACCOUNT_SID,
                API_KEY_SID,
                API_KEY_SECRET
            );

            // Set the Identity of this token
            accessToken1.identity = userId;

            // Grant access to Video
            var grant1 = new VideoGrant();
            grant1.room = roomName;
            accessToken1.addGrant(grant1);

            // Serialize the token as a JWT
            var jwt1 = accessToken1.toJwt();
            if (receiverData.deviceType === "ANDROID" || receiverData.deviceType === "WEB") {
                console.log("=========deviceType", receiverData.deviceType)
                commonFunction.callPushNotification(receiverData.deviceToken, pushdata)
            }
            // let callerName = fullName
            // let note = new apn.Notification();
            // note.payload = {
            //     'calling': callerName,
            //     senderId: userId,
            //     receiverId: req.body.receiverId,
            //     fullName: fullName,
            //     profilePic: senderData.profilePic,
            //     pushType: req.body.pushType,
            //     twilioToken: jwt,
            //     room:roomName,
            //     appointmentId:req.body.appointmentId

            // };
            // note.topic = "com.appsums.swiftlaw.voip";
            // note.priority = 10;
            // service.send(note, receiverData.voipToken)

            //}
            let twilioToken = jwt1
            return res.status(200).send({
                responseMessage: "Access Token",
                twilioToken,
                roomName
            })

        } catch (e) {
            console.log("===========e", e)
            return res.status(501).send({
                responseMessage: "Something went wrong",
                e
            })
        }

    },



    callDisconnect: async (req, res) => {
        try {
            let query = {
                _id: req.body.receiverId,status:"ACTIVE"
            }
            let receiverData = await user.findOne(query)
            if (!receiverData) {
                console.log("========in not found")
                return res.status(404).send({
                    responseCode: 404,
                    responseMessage: "User Not found"
                })
            }
            let pushdata = {
                isAccepted: false,
                pushType: req.body.pushType,
                type: "call_reject"

            }
            console.log("===========pushdata",pushdata)
            console.log("===========receiverData.deviceToken",receiverData.deviceToken)
            commonFunction.callPushNotification(receiverData.deviceToken, pushdata)
            return res.status(200).send({
                responseCode: 200,
                responseMessage: "ok",
                pushdata
            })


        } catch (e) {
            return res.status(501).send({
                responseCode: 501,
                responseMessage: "Something went wrong",
                e
            })
        }

    },
    // get remaining minute when doctor initiate the call.
    getRemainingMinute: async (req, res) => {
        let userId = req.userId
        let result = await walletModel.findOne({
            userId: userId
        })
        return res.status(200).send({
            responseMessage: "ok",
            result
        })

    },

    updateRemainingMinute: async (req, res) => {
        let userId = req.userId
        let result = await walletModel.findOne({
            userId: userId
        })
        if (!result)
            return res.status(404).send({
                responseMessage: "Not found"
            })
        else {
            if (req.body.type == "video") {
                let updateData = await walletModel.findOneAndUpdate({
                    _id: result._id
                }, {
                    $set: {
                        minutesOfVideoCalls: result.minutesOfVideoCalls - req.body.minutes
                    }
                }, {
                    new: true
                })
                return res.status(200).send({
                    responseMessage: "Updated"
                })
            } else {
                let updateData = await walletModel.findOneAndUpdate({
                    _id: result._id
                }, {
                    $set: {
                        minutesOfAudioCalls: result.minutesOfAudioCalls - req.body.minutes
                    }
                }, {
                    new: true
                })
                return res.status(200).send({
                    responseMessage: "Updated"
                })

            }


        }
    },

}