const card = require('../../model/card')
const referral = require('../../model/referral')
const user = require('../../model/user')
const booking = require('../../model/appointment')
const commonfunction = require('../../utility/common')
const multiparty = require('multiparty');
const bucket = process.env.bucket
const AWS = require('aws-sdk');
const fs = require('fs');
const { ErrorMessage } = require('../../helper/message');
const { SuccessMessage } = require('../../helper/message');
const s3 = new AWS.S3({
    accessKeyId: process.env.accessKeyId,
    secretAccessKey: process.env.secretAccessKey
});




module.exports = {

    uploadFile: (req, res) => {
        let form = new multiparty.Form();
        form.parse(req, async (err, fields, files) => {
            if (err) return res.status(500).send({ responseMessage: "Internal Server Error", err })
            const filename = fs.readFileSync(files.file[0].path);
            let ext = files.file[0].path.split('.')
            let extension = ext[1]
            uniqueKey = new Date().getTime();
            const params = {
                Bucket: bucket, // pass your bucket name
                Key: `${uniqueKey}.${extension}`, // file will be saved as testBucket/contacts.csv
                Body: filename
            };
            s3.upload(params, async (s3Err, data) => {
                if (err) return res.status(500).send({ responseMessage: "Internal Server Error", err })
                let result = {
                    url: data.Location
                }
                return res.status(200).send({ responseMessage: "uploaded", result })

            });
        })
    },

    makeCard_primary: async (req, res) => {
        try {
            let data = await card.findOne({status:"ACTIVE",userId:userId,isPrimary:true})
            if(data){
                await card.findOneAndUpdate({ _id: data._id }, { $set: { isPrimary:false} }, { new: true })
            }
            let updateData = await card.findOneAndUpdate({ _id: req.query.cardId }, { $set: { isPrimary:true}}, { new: true })
            if (!updateData) return res.status(500).send({ responseMessage: ErrorMessage.INTERNAL_ERROR })
            return res.status(200).send({ responseMessage:"Successfully Done", updateData })
        }
        catch (e) {
            return res.status(501).send({ responseMessage: ErrorMessage.SOMETHING_WRONG, e })
        }
    },


    getReferralCode: async (req, res) => {
        try {
            let userId = req.userId
            let code = commonfunction.generateString(8).trim()
            // let url = `https://gym-doctor.proaws.com/referral/${code}`
            let url = `https://flexuslab.us/referral/${code}`
            let obj = {
                userId: userId,
                referralCode : code,
                referralUrl: url
            }
            let dataObj = new referral(obj);
            dataObj.save((error, result) => {
                if (error) return res.status(500).send({ responseMessage: ErrorMessage.INTERNAL_ERROR })
                return res.status(200).send({ responseMessage: "Url found successfully", url })
            })
        }
        catch (e) {
            return res.status(501).send({ responseMessage: ErrorMessage.SOMETHING_WRONG, e })
        }
    },


    invitationReportList: async (req, res) => {
        try {
            userId = req.userId
            let totalList = 0;
            let pageNumber = +req.query.pageNumber || 1
            let limit = +req.query.limit || 100000
            let query = { userId: userId,status:"Joined"}
            totalList = await referral.find(query).countDocuments();
            let documentList = await referral.find(query,{ status:0})
            .populate('joinerId','firstName lastName fullName email profilePic userType').sort({ createdAt: -1 })
                .skip((limit * pageNumber) - limit).limit(limit).lean();
            if (!documentList) {
                return res.status(404).send({ responseCode: 404, responseMessage: ErrorMessage.NOT_FOUND })
            } else {
                return res.status(200).send({ responseCode: 200, responseMessage: SuccessMessage.DATA_FOUND, documentList, totalList })
            }
        } catch (e) {
            return res.status(501).send({ responseMessage: ErrorMessage.SOMETHING_WRONG, e })
        }
    },


    appointment_Count_Update: async (req, res) => {
        let currentTime = new Date(new Date().getTime())
        let query = { status: 'accepted', is_counted: false, appointmentStartTime: { $lt: currentTime } }
        let appointmentData = await booking.find(query);
        console.log("========appointmentData",appointmentData)
        var ids = []
        for (let i = 0; i < appointmentData.length; i++) {
            ids.push(appointmentData[i]._id);
        }
        console.log('============ids',ids)
        appointmentData.forEach(async x => {
            console.log("========inner ids",x.serviceProviderId)
            await user.findOneAndUpdate({ _id: x.serviceProviderId }, { $inc: { totalAppointment: 1 } })
        })
        await booking.updateMany({ _id: { $in: ids } }, { $set: { is_counted: true } }, { multi: true })

    },



}