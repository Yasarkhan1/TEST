const user = require('../../model/user')
const subscriptionModel = require('../../model/subscription')
const laboratoryModel = require('../../model/laboratory')
const specialtyModel = require('../../model/specialties')
const primarySpecialtyModel = require('../../model/primarySpecialties')
const transaction = require('../../model/transaction')
const walletModel = require('../../model/wallet')
const ratingModel = require('../../model/rating')
const booking = require('../../model/appointment')
const notification = require('../../model/notification')
const commonFunction = require('../../utility/common')
const schedule = require('node-schedule');

const { commonResponse: response } = require('../../helper/commonResponseHandler');
const { ErrorMessage } = require('../../helper/message');
const { SuccessMessage } = require('../../helper/message');

const mongoose = require('mongoose')

const { findOne, findOneAndUpdate } = require('../../model/user')




module.exports = {

    upcomingAppointments: async (req, res) => {
        try {
            userId = req.userId
            let totalList = 0;
            let pageNumber = +req.query.pageNumber || 1
            let limit = +req.query.limit || 100000
            let currentDate = new Date()
            let query = { serviceProviderId: userId, status: { $in: ["accepted", "cancelled"] }, appointmentEndTime: { $gt: currentDate } }
            totalList = await booking.find(query).countDocuments();
            let appointmentData = await booking.find(query, { appointmentStartTime: 1, appointmentEndTime: 1, amount: 1, status: 1 }).sort({ appointmentStartTime: 1 }).populate('patientId')
                .skip((limit * pageNumber) - limit).limit(limit).lean();
            if (!appointmentData) {
                return res.status(404).send({ responseCode: 404, responseMessage: ErrorMessage.NOT_FOUND })
            } else {
                return res.status(200).send({ responseCode: 200, responseMessage: SuccessMessage.DATA_FOUND, appointmentData, totalList })

            }
        } catch (e) {
            console.log(e)
            return res.status(501).send({ responseCode: 501, responseMessage: ErrorMessage.SOMETHING_WRONG, e })
        }
    },

    previousAppointments: async (req, res) => {
        try {
            userId = req.userId
            let totalList = 0;
            let pageNumber = +req.query.pageNumber || 1
            let limit = +req.query.limit || 100000
            let currentDate = new Date()
            let query = { serviceProviderId: userId, status: { $in: ["accepted", "cancelled"] }, appointmentEndTime: { $lt: currentDate } }
            totalList = await booking.find(query).countDocuments();
            let appointmentData = await booking.find(query, { appointmentStartTime: 1, appointmentEndTime: 1, amount: 1, status: 1 }).sort({ appointmentStartTime: 1 }).populate('patientId')
                .skip((limit * pageNumber) - limit).limit(limit).lean();
            if (!appointmentData) {
                return res.status(404).send({ responseCode: 404, responseMessage: ErrorMessage.NOT_FOUND })
            } else {
                return res.status(200).send({ responseCode: 200, responseMessage: SuccessMessage.DATA_FOUND, appointmentData, totalList })

            }
        } catch (e) {
            return res.status(501).send({ responseCode: 501, responseMessage: ErrorMessage.SOMETHING_WRONG, e })
        }
    },
    viewAppointment: async (req, res) => {
        try {
            let query = { _id: req.params.id }
            booking.findOne(query, { appointmentStartTime: 1, appointmentEndTime: 1, reason: 1, document: 1, amount: 1, status: 1 }).populate('patientId').exec((appointmentErr, appointmentDetails) => {
                if (appointmentErr) return res.status(500).send({ responseCode: 500, responseMessage: ErrorMessage.INTERNAL_ERROR, appointmentErr })
                else if (!appointmentDetails) {
                    return res.status(404).send({ responseCode: 404, responseMessage: ErrorMessage.NOT_FOUND })
                } else {
                    return res.status(200).send({ responseCode: 200, responseMessage: SuccessMessage.DATA_FOUND, appointmentDetails })

                }
            })
        } catch (e) {
            return res.status(501).send({ responseCode: 501, responseMessage: ErrorMessage.SOMETHING_WRONG, e })
        }
    },

    getSlot: async (req, res) => {
        try {
            let serviceProviderId = req.userId
            let availableSlots;
            let selectedDate = req.query.bookingDate
            let day = new Date(req.query.bookingDate).toDateString().split(' ')[0]
            let date = new Date(selectedDate)
            let serviceProviderData = await user.findOne({ _id: serviceProviderId }, { 'availability': 1 }).lean();
            let slotData = serviceProviderData.availability.find(e => e.day == day);
            if (!slotData) {
                return res.status(404).send({ responseMessage: "Not available on this day" })
            }
            availableSlots = slotData.slots
            let query = { serviceProviderId: serviceProviderId, bookingDate: date, status: 'accepted' }
            booking.find(query, (bookingErr, bookingData) => {
                if (bookingErr) return res.status(500).send({ responseMessage: ErrorMessage.INTERNAL_ERROR })
                let bookedSlots = bookingData.map((e) => e.slotId.toString())
                let slots = availableSlots.map((item) => {
                    if (!bookedSlots.includes(item._id.toString())) {
                        return item;
                    }
                }).filter(e => e)
                delete slotData.slots
                slotData['slots'] = slots
                if (slotData.slots.length == 0) {
                    return res.status(404).send({ responseMessage: "Slot not available" })

                }
                return res.status(200).send({ responseMessage: "ok", slotData })

            })
        } catch (e) {
            return res.status(501).send({ responseMessage: ErrorMessage.SOMETHING_WRONG, e })
        }
    },




    rescheduleAppointment: async (req, res) => {
        try {
            let userId = req.userId
            let userData = await user.findOne({ _id: userId })
            let query = { _id: req.body.appointmentId }
            let appointmentDetails = await booking.findOne(query).lean()
            if (!appointmentDetails) {
                return res.status(404).send({ responseCode: 404, responseMessage: ErrorMessage.NOT_FOUND })
            } else {
                let patientData = await user.findOne({ _id: appointmentDetails.patientId })
                let currentTime = new Date().getTime()
                let appointmentDate = appointmentDetails.appointmentStartTime
                let appointmentTime = appointmentDate.getTime()
                console.log("=========appointmentTime", appointmentTime)
                console.log("=================currentTime", currentTime)
                if (appointmentTime - currentTime >= 3600000) {
                    console.log("difference", appointmentTime - currentTime)
                    let updatedAppointmentStatus = await booking.findOneAndUpdate({ _id: req.body.appointmentId }, { $set: { status: 'rescheduled' } }, { new: true })

                    req.body.serviceProviderId = userId
                    req.body.patientId = appointmentDetails.patientId
                    req.body.reason = appointmentDetails.reason
                    req.body.document = appointmentDetails.document
                    req.body.paymentStatus = 'paid'
                    req.body.status = "pending"
                    req.body.oldAppointmentId = appointmentDetails._id
                    req.body.amount = userData.serviceCharge
                    req.body.appointmentStartTime = req.body.appointmentStartTime
                    req.body.appointmentEndTime = req.body.appointmentEndTime
                    req.body.bookingDate = new Date(req.body.bookingDate)
                    let data = new booking(req.body);
                    let bookingData = data.save()
                    if (bookingData) {
                        let serviceProviderName = userData.fullName
                        const pushTitle = "Reschedule"
                        const pushBody = `Your appointment with ${serviceProviderName} has requested for appointment rescheduling. Check the update under the requests.`
                        commonFunction.pushNotification(patientData.deviceToken, pushTitle, pushBody)
                        let notify = {
                            userId: patientData._id,
                            title: "Reschedule",
                            body: `Your appointment with ${serviceProviderName} has requested for appointment rescheduling. Check the update under the requests.`,
                            notificationType: 'RESCHEDULE',
                            appointmentId: bookingData._id
                        }
                        let notiData = new notification(notify)
                        notiData.save((notiErr, notiSaveData) => {
                            if (notiErr) return res.status(500).send({ responseMessage: ErrorMessage.INTERNAL_ERROR, notiErr })
                            return res.status(200).send({ responseMessage: SuccessMessage.BOOKING_SUCCESS })

                        })
                    }
                } else {
                    return res.status(200).send({ responseMessage: "Can't reschedule now" })
                }
            }
        } catch (e) {
            console.log(e)
            return res.status(501).send({ responseCode: 501, responseMessage: ErrorMessage.SOMETHING_WRONG, e })
        }
    },


    cancelAppointment: async (req, res) => {
        try {
            let userId = req.userId
            let userData = await user.findOne({ _id: userId })
            let query = { _id: req.body.appointmentId }
            let appointmentDetails = await booking.findOne(query).lean()
            if (!appointmentDetails) {
                return res.status(404).send({ responseCode: 404, responseMessage: ErrorMessage.NOT_FOUND })
            } else {
                let patientData = await user.findOne({ _id: appointmentDetails.patientId })
                let currentTime = new Date().getTime()
                let appointmentDate = appointmentDetails.appointmentStartTime
                let appointmentTime = appointmentDate.getTime()
                if (appointmentTime - currentTime >= 3600000) {
                    let updatedAppointmentStatus = await booking.findOneAndUpdate({ _id: req.body.appointmentId }, { $set: { status: 'cancelled', cancelReason: req.body.reason } }, { new: true })
                    if (updatedAppointmentStatus) {


                        let doctorDataWallet = await walletModel.findOne({ userId: userData._id })
                        let balance = doctorDataWallet.totalBalance - appointmentDetails.amount
                        await walletModel.findOneAndUpdate({ userId: userData._id }, { $set: { totalBalance: balance } }, { new: true })
                        if (appointmentDetails.appointmentType == "BANK_CARD") {
                            let userWalletData = await walletModel.findOne({ userId: patientData._id })
                            let walletBalance = userWalletData.totalBalance + appointmentDetails.amount
                            await walletModel.findOneAndUpdate({ userId: patientData._id }, { $set: { totalBalance: walletBalance } }, { new: true })
                        }
                        if (appointmentDetails.appointmentType == "SUBSCRIPTION") {
                            let userWalletData = await walletModel.findOne({ userId: patientData._id })
                            let totalSession = userWalletData.sessions + 1
                            await walletModel.findOneAndUpdate({ userId: patientData._id }, { $set: { sessions: totalSession } }, { new: true })
                        }
                        const serviceProviderName = userData.fullName
                        console.log("========serviceproviderName",serviceProviderName)
                        const pushTitle = "Cancel"
                        const pushBody = `${serviceProviderName} has cancel a appointment with you.`
                        commonFunction.pushNotification(patientData.deviceToken, pushTitle, pushBody)
                        let notify = {
                            userId: patientData._id,
                            title: "Cancel",
                            body: `${serviceProviderName} has cancel a appointment with you.`,
                            notificationType: 'CANCEL',
                            appointmentId: appointmentDetails._id
                        }
                        let notiData = new notification(notify)
                        notiData.save((notiErr, notiSaveData) => {
                            if (notiErr) return res.status(500).send({ responseMessage: ErrorMessage.INTERNAL_ERROR, notiErr })
                            var my_job = schedule.scheduledJobs[JSON.stringify(req.body.appointmentId)];
                            if (my_job) {
                                my_job.cancel();
                            }
                            return res.status(200).send({ responseMessage: "You have successfully canceled the appointment" })

                        })
                    }
                } else {
                    return res.status(200).send({ responseMessage: "Can't cancel now" })
                }
            }
        } catch (e) {
            console.log(e)
            return res.status(501).send({ responseCode: 501, responseMessage: ErrorMessage.SOMETHING_WRONG, e })
        }
    },





}