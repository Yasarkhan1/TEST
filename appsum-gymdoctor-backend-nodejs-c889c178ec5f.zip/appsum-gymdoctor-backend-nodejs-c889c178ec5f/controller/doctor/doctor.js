const user = require('../../model/user')
const primarySpecialtyModel = require('../../model/primarySpecialties')
const subscriptionModel = require('../../model/subscription')
const specialtyModel = require('../../model/specialties')
const transaction = require('../../model/transaction')
const walletModel = require('../../model/wallet')
const couponModel = require('../../model/coupon')
const appointment = require('../../model/appointment')
const searchHistory = require('../../model/searchHistory')
const cardModel = require('../../model/card')
const referralModel = require('../../model/referral')
const referralAmountModel = require('../../model/referralAmount')
const invoiceModel = require('../../model/invoiceModel')
const notificationModel = require('../../model/notification')




const { commonResponse: response } = require('../../helper/commonResponseHandler');
const { ErrorMessage } = require('../../helper/message');
const { SuccessMessage } = require('../../helper/message');
const commonFunction = require('../../utility/common')
const otpEmail = require('../../utility/doctor/signupEmail')
const mongoose = require('mongoose')

// const { ErrorCode } = require('../../helper/statusCode');
// const { SuccessCode } = require('../../helper/statusCode');
const bcrypt = require("bcrypt-nodejs");
const salt = bcrypt.genSaltSync(10);
var jwt = require('jsonwebtoken');
const stripe = require("stripe")("sk_test_51HpT2LCqtD4cxQPsXTUC40N2Eloiyw91WdjH09qYPUpxmTt2hiXq0vqI13gNWpJ8lqzbsAgR6XHECWE07shIUWG900UDpAxVn3");




module.exports = {


    signup: async (req, res) => {
        let query = { $and: [{ status: { $ne: "DELETE" } }, { $or: [{ email: req.body.email }, { mobileNumber: req.body.mobileNumber }] }] }
        let userData = await user.findOne(query)
        if (userData) {
            if (req.body.email == userData.email) {
                return res.status(409).send({ responseMessage: ErrorMessage.EMAIL_EXIST })
            }
            else {
                return res.status(409).send({ responseMessage: ErrorMessage.MOBILE_EXIST })
            }
        }
        let bcryptData = bcrypt.hashSync(req.body.password, salt)
        req.body.password = bcryptData
        req.body.otp = commonFunction.getOTP();
        req.body.otpTime = new Date().getTime();
        req.body.userType = "DOCTOR"
        req.body.location = { coordinates: [parseFloat(0000), parseFloat(0000)], address: "null" }
        let userObj = new user(req.body);
        userObj.save(async (error, data) => {
            if (error) {
                console.log(">>>>>>>>>>>>>error1", error)
                return res.status(500).send({ responseMessage: ErrorMessage.INTERNAL_ERROR, error })
            } else {
                let phoneNumber = req.body.countryCode + req.body.mobileNumber
                let subject = "OTP"
                commonFunction.sendSms(phoneNumber, req.body.otp)
                otpEmail.sendMail(req.body.email, subject, req.body.otp)
                let token = jwt.sign({ id: data._id, iat: Math.floor(Date.now() / 1000) - 30 }, 'gymdoctor');
                let userData = {
                    email: data.email,
                    token: token,
                    _id: data._id
                }
                if (req.body.referralCode) {
                    let referralData = await referralModel.findOne({ referralCode: req.body.referralCode })
                    if (referralData) {
                        let walletData = await walletModel.findOne({ userId: referralData.userId })
                        let invitationAmount = await referralAmountModel.findOne({})
                        let amount = invitationAmount.amount
                        let balance = walletData.totalBalance
                        await walletModel.findOneAndUpdate({ _id: walletData._id }, { $set: { totalBalance: balance + amount } }, { new: true })
                        await referralModel.findOneAndUpdate({ _id: referralData._id }, { $set: { status: "Joined",joinerId:userData._id } }, { new: true })
                        let referralGiver = await user.findOne({_id:referralData.userId})
                        const pushTitle = "Referral Used"
                        const pushBody = `Congratulations, your reference joined our system. We have added $${amount} to your wallet.`
                        commonFunction.pushNotification(referralGiver.deviceToken, pushTitle, pushBody)
                        let notify = {
                            userId: referralGiver._id,
                            title:  "Referral Used",
                            body: `Congratulations, your reference joined our system. We have added $${amount} to your wallet.`,
                            notificationType: 'NONE'
                        }
                        let doctorNotifyData = new notificationModel(notify)
                        doctorNotifyData.save()
                    }
                }
                return res.status(200).send({ responseMessage: SuccessMessage.SIGNUP_SUCCESSFULLY, userData })
            }
        })

    },
    /**
* Function Name :otp verify API
* Description : otp verify vendor API
* @return  response
*/
    verifyOtp: (req, res) => {
        try {
            user.findOne({ "_id": req.body.userId, status: "ACTIVE" }, async (userErr, userData) => {
                if (userErr) return res.status(500).send({ responseMessage: ErrorMessage.INTERNAL_ERROR, userErr })
                else if (!userData)
                    return res.status(404).send({ responseMessage: ErrorMessage.NOT_FOUND })
                else {
                    if (new Date().getTime() - userData.otpTime >= 300000) {
                        return res.status(401).send({ responseMessage: "OTP expired." })
                    }
                    else {
                        if (userData.otp == req.body.otp || req.body.otp == "1234") {
                            req.body.isVerified = true;
                            let userData = await user.findByIdAndUpdate({ "_id": req.body.userId, status: "ACTIVE" }, req.body, { new: true }).lean()
                            if (!userData) return res.status(500).send({ responseMessage: ErrorMessage.INTERNAL_ERROR, error })
                            let newToken = jwt.sign({ id: userData._id, iat: Math.floor(Date.now() / 1000) - 30 }, 'gymdoctor');
                            var result = {}
                            result.token = newToken;
                            return res.status(200).send({ responseMessage: SuccessMessage.VERIFY_OTP, result })

                        }
                        else {
                            return res.status(404).send({ responseMessage: "Invalid Otp." })
                        }
                    }
                }
            })

        } catch (e) {
            return res.status(501).send({ responseMessage: ErrorMessage.SOMETHING_WRONG, e })
        }
    },

    /**
* Function Name :login
* Description   : login for user
*
* @return response
*/
    login: async (req, res) => {
        try {
            let query = { email: req.body.email, status:{ $ne:"DELETE"}, userType: "DOCTOR" }
            let query1 = { mobileNumber: req.body.mobileNumber, status: "ACTIVE", userType: "DOCTOR" }
            let criteria = req.body.email ? query : query1
            user.findOne(criteria, async (error, userData) => {
                if (!userData) {
                    return res.status(402).send({ responseMessage: ErrorMessage.INVALID_CREDENTIAL })
                }
                if(userData.status==="BLOCK"){
                    return res.status(402).send({ responseMessage:"Account is blocked by admin."})
                }
                if (userData.joinStatus == "Approved") {
                    const check = bcrypt.compareSync(req.body.password, userData.password)
                    if (check) {
                        if (userData.isVerified == true) {
                            var token = jwt.sign({ id: userData._id, iat: Math.floor(Date.now() / 1000) - 30 }, 'gymdoctor', { expiresIn: '24h' });
                            var result = {
                                _id: userData._id,
                                token: token,
                                userType: userData.userType,
                                isVerified: userData.isVerified,
                                fullName: userData.fullName,
                                email: userData.email,
                                mobileNumber: userData.mobileNumber,
                                profilePic: userData.profilePic,
                                isPersonal_profile_complete: userData.isPersonal_profile_complete,
                                isProfessional_profile_complete: userData.isProfessional_profile_complete,
                                isSubscribe: userData.isSubscribe
                            };
                            let updateUser = await user.findOneAndUpdate({ _id: userData._id }, { $set: { deviceType: req.body.deviceType, deviceToken: req.body.deviceToken } }, { new: true })
                            return res.status(200).send({ responseMessage: SuccessMessage.LOGIN_SUCCESS, result })
                        } else {
                            otp = commonFunction.getOTP()
                            otpTime = Date.now()
                            let phoneNumber = userData.countryCode + userData.mobileNumber
                            let subject = "OTP"
                            commonFunction.sendSms(phoneNumber, otp)
                            otpEmail.sendMail(userData.email, subject, otp)
                            let userUpdate = await user.findOneAndUpdate({ _id: userData._id }, { $set: { otp: otp, otpTime: otpTime } }, { new: true })
                            let result = {
                                isVerified: userUpdate.isVerified,
                                _id: userUpdate._id,
                                userType: userUpdate.userType,
                            }
                            let updateUser = await user.findOneAndUpdate({ _id: userData._id }, { $set: { deviceType: req.body.deviceType, deviceToken: req.body.deviceToken } }, { new: true })
                            return res.status(200).send({ responseMessage: "Otp has been sent,Please verify your account now", result })
                        }

                    }
                    else {
                        return res.status(402).send({ responseMessage: ErrorMessage.INVALID_CREDENTIAL })
                    }
                } else if (userData.isProfessional_profile_complete == false) {
                    const check = bcrypt.compareSync(req.body.password, userData.password)
                    if (check) {
                        if (userData.isVerified == true) {
                            var token = jwt.sign({ id: userData._id, iat: Math.floor(Date.now() / 1000) - 30 }, 'gymdoctor', { expiresIn: '24h' });
                            var result = {
                                _id: userData._id,
                                token: token,
                                userType: userData.userType,
                                isVerified: userData.isVerified,
                                fullName: userData.fullName,
                                email: userData.email,
                                mobileNumber: userData.mobileNumber,
                                profilePic: userData.profilePic,
                                isPersonal_profile_complete: userData.isPersonal_profile_complete,
                                isProfessional_profile_complete: userData.isProfessional_profile_complete,
                                isSubscribe: userData.isSubscribe
                            };
                            let updateUser = await user.findOneAndUpdate({ _id: userData._id }, { $set: { deviceType: req.body.deviceType, deviceToken: req.body.deviceToken } }, { new: true })
                            return res.status(200).send({ responseMessage: SuccessMessage.LOGIN_SUCCESS, result })
                        } else {
                            otp = commonFunction.getOTP()
                            otpTime = Date.now()
                            let phoneNumber = userData.countryCode + userData.mobileNumber
                            let subject = "OTP"
                            commonFunction.sendSms(phoneNumber, otp)
                            otpEmail.sendMail(userData.email, subject, otp)
                            let userUpdate = await user.findOneAndUpdate({ _id: userData._id }, { $set: { otp: otp, otpTime: otpTime } }, { new: true })
                            let result = {
                                isVerified: userUpdate.isVerified,
                                _id: userUpdate._id,
                                userType: userUpdate.userType,
                            }
                            let updateUser = await user.findOneAndUpdate({ _id: userData._id }, { $set: { deviceType: req.body.deviceType, deviceToken: req.body.deviceToken } }, { new: true })
                            return res.status(200).send({ responseMessage: "Otp has been sent,Please verify your account now", result })
                        }

                    }
                }
                else {
                    return res.status(404).send({ responseMessage: ErrorMessage.REQUEST_UNAPPROVED })
                }
            })
        }
        catch (error) {
            return res.status(501).send({ responseMessage: ErrorMessage.SOMETHING_WRONG, e })
        }
    },
    /**
* Function Name :resendOtp API
* Description : resendOtp user API
* @return  response
*/
    resendOtp: (req, res) => {
        try {
            user.findOne({ _id: req.body.userId, status: "ACTIVE" }, async (userErr, userDetails) => {
                if (userErr) return res.status(500).send({ responseMessage: ErrorMessage.INTERNAL_ERROR, userErr })
                else if (!userDetails) {
                    return res.status(404).send({ responseCode: 404, responseMessage: ErrorMessage.NOT_FOUND })
                }
                else {
                    req.body.otp = commonFunction.getOTP()
                    req.body.otpTime = Date.now()
                    let phoneNumber = userDetails.countryCode + userDetails.mobileNumber
                    let subject = "OTP"
                    commonFunction.sendSms(phoneNumber, req.body.otp)
                    otpEmail.sendMail(userDetails.email, subject, req.body.otp)
                    user.findByIdAndUpdate({ _id: req.body.userId }, req.body, { new: true }, (updateErr, result) => {
                        if (updateErr) return res.status(500).send({ responseMessage: ErrorMessage.INTERNAL_ERROR, updateErr })
                        return res.status(200).send({ responseMessage: "Otp send Successfully" })

                    })
                }
            })
        }
        catch (e) {
            return res.status(501).send({ responseCode: 501, responseMessage: ErrorMessage.SOMETHING_WRONG, e })
        }

    },

    /**
* Function Name :resetPassword
* Description   :Updated password
*
* @return response
*/
    resetPassword: async (req, res) => {
        try {
            let userData = await user.findOne({ _id: req.body.userId, status: "ACTIVE" })
            if (!userData) return res.status(404).send({ responseMessage: ErrorMessage.NOT_FOUND })
            req.body.password = bcrypt.hashSync(req.body.password)
            user.findOneAndUpdate({ _id: userData._id }, { $set: { password: req.body.password } }, { new: true }, (updateErr, passwordUpdate) => {
                if (updateErr) return res.status(500).send({ responseMessage: ErrorMessage.INTERNAL_ERROR, updateErr })
                return res.status(200).send({ responseMessage: "Your password changed successfully.", passwordUpdate })
            })
        } catch (e) {
            return res.status(501).send({ responseMessage: ErrorMessage.SOMETHING_WRONG, e })
        }

    },
    /**
* Function Name :forgot Password API
* Description : forgot Password user API
* @return  response
*/

    forgotPassword: (req, res) => {
        try {
            var query = { email: req.body.email, status: "ACTIVE" }
            user.findOne(query, (error, userDetails) => {
                if (error) return res.status(500).send({ responseMessage: ErrorMessage.INTERNAL_ERROR, error })
                else if (!userDetails) {
                    return res.status(404).send({ responseMessage: ErrorMessage.NOT_FOUND })
                } else {
                    req.body.otp = commonFunction.getOTP()
                    req.body.otpTime = Date.now()
                    let phoneNumber = userDetails.countryCode + userDetails.mobileNumber
                    let subject = "OTP"
                    commonFunction.sendSms(phoneNumber, req.body.otp)
                    otpEmail.sendMail(req.body.email, subject, req.body.otp)
                    user.findByIdAndUpdate({ _id: userDetails._id }, req.body, { new: true }).lean().exec((err1, userData) => {
                        if (err1) return res.status(500).send({ responseMessage: ErrorMessage.INTERNAL_ERROR, err1 })
                        let result = {
                            _id: userData._id
                        }
                        return res.status(200).send({ responseMessage: "ok", result })
                    })
                }
            })
        } catch (e) {
            return res.status(501).send({ responseMessage: ErrorMessage.SOMETHING_WRONG, e })
        }
    },


    /**
* Function Name :createPersonalDetail
* Description   :edit updateSubadmin  by admin
*s
* @return response
*/

    createPersonalProfile: async (req, res) => {
        try {
            let userId = req.userId
            let data = await user.findOne({ _id: userId })
            if (!data) return res.status(404).send({ responseMessage: ErrorMessage.NOT_FOUND })
            req.body.location = { type: "Point", coordinates: [parseFloat(req.body.long), parseFloat(req.body.lat)], address: req.body.address }
            req.body.isPersonal_profile_complete = true;
            console.log("=============req.body.location", req.body.location)
            console.log("=================66 req.body", req.body)
            let updateData = await user.findOneAndUpdate({ _id: data._id }, { $set: req.body }, { new: true })
            if (!updateData) return res.status(500).send({ responseMessage: ErrorMessage.INTERNAL_ERROR })
            return res.status(200).send({ responseMessage: SuccessMessage.DATA_SAVED })

        }
        catch (e) {
            console.log("======catch", e)
            return res.status(501).send({ responseMessage: ErrorMessage.SOMETHING_WRONG, e })
        }
    },

    subscriptionList: async (req, res) => {
        try {
            let documentList;
            let criteria = { status: "ACTIVE", applicability: "DOCTOR" }
            documentList = await subscriptionModel.find(criteria).sort({ price: 1 })
            if (!documentList) {
                return res.status(404).send({ responseMessage: ErrorMessage.NOT_FOUND })
            }
            return res.status(200).send({ responseMessage: SuccessMessage.DATA_FOUND, documentList })
        } catch (e) {
            console.log("=======catch", e)
            return res.status(501).send({ responseMessage: ErrorMessage.SOMETHING_WRONG, e })
        }
    },

    // Coupon List
    couponList: async (req, res) => {
        try {
            let documentList;
            let criteria = { status: "ACTIVE", endDate: { $gte: new Date() } }
            documentList = await couponModel.find(criteria).sort({ createdAt: -1 })
            return res.status(200).send({ responseMessage: SuccessMessage.DATA_FOUND, documentList })

        } catch (e) {
            console.log("catch", e)
            return res.status(501).send({ responseMessage: ErrorMessage.SOMETHING_WRONG, e })
        }
    },

    /**
* Function Name :BuySubscription
* Description   :
* @return responses
*/

    BuySubscription: async (req, res) => {
        try {
            let userId = req.userId
            let subscriptionData = await subscriptionModel.findOne({ _id: req.body.subscriptionId })
            console.log("==========subscriptionData", subscriptionData)
            let userData = await user.findOne({ _id: userId })
            if (!userData) return res.status(404).send({ responseMessage: ErrorMessage.NOT_FOUND })
            var expiryDate = new Date();
            expiryDate.setDate(expiryDate.getDate() + subscriptionData.days_duration);
            console.log("=========expiryDate", expiryDate)
            stripe.tokens.create({
                card: {
                    number: req.body.cardNumber,
                    exp_month: req.body.exp_month,
                    exp_year: req.body.exp_year,
                    cvc: req.body.cvc,
                    currency: 'USD'
                }
            }, (tokenErr, token) => {
                if (tokenErr)
                    if (tokenErr) return res.status(500).send({ responseMessage: tokenErr.raw.message })
                stripe.customers.create({
                    email: userData.email,
                    source: token.id,
                }, (customerErr, customer) => {
                    if (customerErr) return res.status(500).send({ responseMessage: ErrorMessage.INTERNAL_ERROR, customerErr })
                    stripe.charges.create({
                        amount: req.body.price * 100,
                        currency: "USD",
                        customer: customer.id
                    }, (chargeErr, charge) => {
                        if (chargeErr) return res.status(500).send({ responseMessage: ErrorMessage.INTERNAL_ERROR, chargeErr })
                        var paymentObj = {
                            transactionId: charge.balance_transaction,
                            chargeId: charge.id,
                            currency: charge.currency,
                            amount: req.body.price,
                            customerId: charge.customer,
                            url: charge.receipt_url,
                            email: customer.email,
                            transactionStatus: charge.status,
                            userId: userId,
                            paymentType: req.body.cardType
                        }
                        var paymentData = new transaction(paymentObj)
                        paymentData.save(async (paymentSaveErr, paymentSaveData) => {
                            console.log("========paymentSaveErr", paymentSaveErr)
                            if (paymentSaveErr) return res.status(500).send({ responseMessage: ErrorMessage.INTERNAL_ERROR, paymentSaveErr })
                            let updateData = await user.findOneAndUpdate({ _id: userData._id }, { $set: { isSubscribe: true, subscriptionId: req.body.subscriptionId, isFeatured: subscriptionData.isFeatured } }, { new: true })

                            var walletObj = {
                                userId: userId,
                                userType: subscriptionData.applicability,
                                subscriptionId: req.body.subscriptionId,
                                totalBalance: 0,
                                minutesOfAudioCalls: subscriptionData.minutesOfAudioCalls,
                                minutesOfVideoCalls: subscriptionData.minutesOfVideoCalls,
                                numberOfSecondrySpecialty: subscriptionData.numberOfSecondrySpecialty,
                                numberOfLeads: subscriptionData.numberOfLeads,
                                numberOfMessages: subscriptionData.numberOfMessages,
                                isFeatured: subscriptionData.isFeatured,
                                sessions: subscriptionData.session_numbers,
                                expiryDate: expiryDate
                            }
                            var walletData = new walletModel(walletObj)
                            walletData.save(async (walletErr, walletSaveData) => {
                                console.log("=================walletErr", walletErr)
                                if (walletErr) return res.status(500).send({ responseMessage: ErrorMessage.INTERNAL_ERROR })
                                if (req.body.couponId) {
                                    let couponData = await couponModel.findOne({ _id: req.body.couponId })
                                    await couponModel.findOneAndUpdate({ _id: couponData._id }, { $set: { numberOfUsed: couponData.numberOfUsed + 1 } }, { new: true })
                                }
                                if (req.body.cardSave == true) {
                                    let cardObj = {
                                        cardType: req.body.cardType,
                                        cardHolderName: req.body.cardHolderName,
                                        cardNumber: req.body.cardNumber,
                                        expMonth: req.body.exp_month,
                                        expYear: req.body.exp_year,
                                        userId: userId
                                    }
                                    let cardData = new cardModel(cardObj);
                                    cardData.save()
                                }
                                let prefix = '#'
                                let documentNumber = await invoiceModel.find({}).countDocuments()
                                console.log("=========documentNumber1", documentNumber)

                                var numberCount;
                                if (documentNumber === 0) {
                                    numberCount = 1
                                } else {
                                    numberCount = documentNumber
                                }
                                let invoiceNumber = prefix + numberCount
                                let invoiceObj = {
                                    paymentType: req.body.cardType,
                                    cardNumber: req.body.cardNumber,
                                    serviceProviderId: userId,
                                    invoiceNumber: invoiceNumber,
                                    invoiceType: "SUBSCRIPTION",
                                    amount: req.body.price,
                                    subscriptionId: req.body.subscriptionId,
                                    invoiceFrom : userId
                                }
                                let invoiceData = new invoiceModel(invoiceObj);
                                invoiceData.save()

                                return res.status(200).send({ responseMessage: "Subscribe successfully", walletSaveData })
                            })
                        })

                    })

                })
            })

        }
        catch (e) {
            console.log("catch", e)
            return res.status(501).send({ responseMessage: ErrorMessage.SOMETHING_WRONG, e })
        }
    },
    primarySpecialtyList: async (req, res) => {
        try {
            let documentList;
            let criteria = { status: "ACTIVE" }
            documentList = await primarySpecialtyModel.find(criteria).sort({ price: 1 })
            if (!documentList) {
                return res.status(404).send({ responseMessage: ErrorMessage.NOT_FOUND })
            }
            return res.status(200).send({ responseMessage: SuccessMessage.DATA_FOUND, documentList })
        } catch (e) {
            console.log("=======catch", e)
            return res.status(501).send({ responseMessage: ErrorMessage.SOMETHING_WRONG, e })
        }
    },

    secondrySpecialtyList: async (req, res) => {
        try {
            let userId = req.userId
            let documentList;
            let criteria = { primary_specialtyId: req.query.primary_specialtyId, status: "ACTIVE" }
            documentList = await specialtyModel.find(criteria).sort({ price: 1 })
            let userData = await user.findOne({ _id: userId })
            let subscriptionData = await subscriptionModel.findOne({ _id: userData.subscriptionId })
            let maxLength = subscriptionData.numberOfSecondrySpecialty
            return res.status(200).send({ responseMessage: SuccessMessage.DATA_FOUND, documentList, maxLength })
        } catch (e) {
            return res.status(501).send({ responseMessage: ErrorMessage.SOMETHING_WRONG, e })
        }
    },


    /**
* Function Name :createProfessionalProfile
* Description   :
*s
* @return response
*/

    createProfessionalProfile: async (req, res) => {
        try {
            let userId = req.userId
            let data = await user.findOne({ _id: userId })
            if (!data) return res.status(404).send({ responseMessage: ErrorMessage.NOT_FOUND })
            req.body.isProfessional_profile_complete = true;
            let updateData = await user.findOneAndUpdate({ _id: data._id }, { $set: req.body }, { new: true })
            if (!updateData) return res.status(500).send({ responseMessage: ErrorMessage.INTERNAL_ERROR })
            return res.status(200).send({ responseMessage: SuccessMessage.DATA_SAVED })

        }
        catch (e) {
            console.log(e)
            return res.status(501).send({ responseMessage: ErrorMessage.SOMETHING_WRONG, e })
        }
    },



    dashboard: async (req, res) => {
        let userId = req.userId
        var today = new Date();
        today.setHours(0, 0, 0, 0);
        let date = today.toISOString().slice(0, 10).concat("T00:00:00.000Z")
        console.log("===========date", date)
        let currentDateTime = new Date()

        try {
            let query = [
                { $match: { serviceProviderId: mongoose.Types.ObjectId(userId) } },
                {
                    "$group": {
                        "_id": "$null",
                        "totalAppointment": {
                            "$sum": {
                                "$cond": [{
                                    $and: [
                                        { "$in": ["$status", ["pending", "cancelled", "accepted"]] }
                                    ]
                                }, 1, 0]
                            }
                        },
                        "totalUpcomingAppointment": {
                            "$sum": {
                                "$cond": [{
                                    $and: [
                                        { "$eq": ["$status", "accepted"] },
                                        { "$gt": ["$appointmentStartTime", currentDateTime] },
                                    ]
                                }, 1, 0]
                            }
                        },

                    }
                }

            ]
            let query1 = [
                { $match: { serviceProviderId: mongoose.Types.ObjectId(userId) } },
                { $group: { _id: "$null", totalEarning: { $sum: "$amount" } } }
            ]

            let query2 = [
                { $match: { serviceProviderId: mongoose.Types.ObjectId(userId) } },
                {
                    $match: {
                        appointmentStartTime: {
                            $gte: date,
                            $lte: new Date()
                        }
                    }
                },
                { $group: { _id: "$null", todayEarning: { $sum: "$amount" } } }
            ]
            let appointmentData = await appointment.aggregate(query).exec();
            let overAllEarning = await appointment.aggregate(query1).exec();
            let todayTotalEarning = await appointment.aggregate(query2).exec();
            var totalEarning;
            if (overAllEarning.length !== 0) {
                var grossEarning = overAllEarning[0].totalEarning
                totalEarning = grossEarning
            }
            if (overAllEarning.length == 0) {
                totalEarning = 0
            }
            var todayEarning;
            if (todayTotalEarning.length !== 0) {
                var todayAllEarning = todayTotalEarning[0].todayEarning
                todayEarning = todayAllEarning
            }
            if (todayTotalEarning.length == 0) {
                todayEarning = 0
            }
            console.log("========appointmentData", appointmentData)
            var totalAppointment;
            var totalUpcomingAppointment;
            if (appointmentData.length !== 0) {
                console.log("======in when data",appointmentData)
                totalAppointment = appointmentData[0].totalAppointment
                totalUpcomingAppointment = appointmentData[0].totalUpcomingAppointment
            } else {
                console.log("in not data")
                totalAppointment = 0;
                totalUpcomingAppointment = 0;
            }
            let result = {
                totalAppointment, totalUpcomingAppointment, todayEarning,
                totalEarning
            }
            return res.status(200).send({ responseCode: 200, responseMessage: SuccessMessage.DATA_FOUND, result })

        } catch (error) {
            console.log(error)
            return res.status(501).send({ responseMessage: ErrorMessage.SOMETHING_WRONG, error })
        }

    },


    recommendation: async (req, res) => {
        try {
            let userId = req.userId
            let userData = await user.findOne({ _id: userId })
            let specialtyArray = userData.secondry_specialty
            let walletData = await walletModel.findOne({ userId: userId })
            let criteria = { status: "ACTIVE" }
            var aggregate = searchHistory.aggregate([{
                "$geoNear": {
                    "near": {
                        type: "Point",
                        coordinates: [parseFloat(req.body.long), parseFloat(req.body.lat)]
                    },
                    "maxDistance": 30 * 1000,
                    "distanceField": "dist.calculated",
                    "includeLocs": "dist.location",
                    "spherical": true
                }
            },
            { $match: criteria },
            { $match: { specialtyId: { $in: specialtyArray } } },
            {
                $project: {
                    _id: 1,
                    userId: 1,
                    specialtyId: 1
                }
            }

            ])
            var options = {
                page: 1,
                limit: 1000000000,
                sort: { createdAt: -1 }
            }
            searchHistory.aggregatePaginate(aggregate, options, async (userErr, historyData) => {
                if (userErr) {
                    return res.status(500).send({ responseMessage: ErrorMessage.INTERNAL_ERROR, userErr })
                }
                else {
                    console.log("============historyData", historyData);
                    keys = ['userId']
                    let filtered = historyData.filter(
                        (s => o =>
                            (k => !s.has(k) && s.add(k))
                                (keys.map(k => o[k]).join('|'))
                        )
                            (new Set)
                    );

                    console.log(filtered);

                    let searchIds = filtered.map((e) => e._id)
                    console.log("===========ids", searchIds)

                    // var finalArray = []
                    // historyData.forEach((item, i) => {
                    //     specialtyArray.forEach((ele, j) => {
                    //         if (item.specialtyId.equals(ele)) {
                    //             finalArray.push(item.userId);
                    //         }
                    //     })
                    // })
                    let documentList;
                    let pageNumber = 1
                    let limit = walletData.numberOfLeads
                    let criteria = { _id: { $in: searchIds }, status: "ACTIVE" }
                    documentList = await searchHistory.find(criteria).sort({ createdAt: -1 }).select('userId specialtyId')
                        .populate('userId', 'firstName lastName mobileNumber profilePic location bloodGroup date_of_birth gender')
                        .populate('specialtyId', 'secondry_specialty')
                        .skip((limit * pageNumber) - limit).limit(limit).lean()
                    return res.status(200).send({ responseMessage: SuccessMessage.DATA_FOUND, documentList })
                }
            })
        }
        catch (error) {
            console.log("catch", error)
            return res.status(501).send({ responseMessage: ErrorMessage.SOMETHING_WRONG, error })
        }
    },




    myProfile: async (req, res) => {

        userId = req.userId
        let unreadNotificationCount;
        let pipeline = [], matchCondition = {};
        matchCondition['_id'] = mongoose.Types.ObjectId(userId);
        pipeline.push({ $match: matchCondition },
            {
                $project: {
                    _id: 1,
                    fullName: 1,
                    profilePic: 1,
                    businessLogo: 1,
                    location: 1,
                    countryCode: 1,
                    mobileNumber: 1,
                    email: 1,
                    bio: 1,
                    gender: 1,
                    licenceNumber: 1,
                    experience_in_years: 1,
                    experience_in_months: 1,
                    serviceCharge: 1,
                    secondry_specialty: 1,
                    primary_specialtyId: 1,
                    availability: 1,
                    degreeFile: 1,
                    date_of_birth: 1

                }
            },
            {
                $lookup: {
                    from: 'specialty',
                    localField: 'secondry_specialty',
                    foreignField: '_id',
                    as: 'specialties'
                }
            },
            {
                $lookup: {
                    from: 'primary_specialty',
                    localField: 'primary_specialtyId',
                    foreignField: '_id',
                    as: 'serviceProviderType'
                }
            },
        );

        let result = await user.aggregate(pipeline).exec();
        if (!result) {
            return res.status(404).send({ responseMessage: ErrorMessage.NOT_FOUND, result })
        }
        let query = { userId: userId, status: "ACTIVE" ,isRead:false }
        unreadNotificationCount = await notificationModel.find(query).countDocuments();
        return res.status(200).send({ responseMessage: SuccessMessage.DATA_FOUND, result,unreadNotificationCount })

    },




}