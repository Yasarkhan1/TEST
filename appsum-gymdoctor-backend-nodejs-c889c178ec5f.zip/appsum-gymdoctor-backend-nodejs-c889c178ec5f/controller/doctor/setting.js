const user = require('../../model/user')
const cms = require('../../model/cms')
const card = require('../../model/card')
const laboratoryModel = require('../../model/laboratory')
const ratingModel = require('../../model/rating')
const walletModel = require('../../model/wallet')
const cardModel = require('../../model/card')
const transactionModel = require('../../model/transaction')
const couponModel = require('../../model/coupon')
const subscriptionModel = require('../../model/subscription')
const invoiceModel = require('../../model/invoiceModel')
const withdrawRequestModel = require('../../model/withdrawAmount')
const notification = require('../../model/notification')
const bcrypt = require("bcrypt-nodejs");
const commonFunction = require('../../utility/common')


const { commonResponse: response } = require('../../helper/commonResponseHandler');
const { ErrorMessage } = require('../../helper/message');
const { SuccessMessage } = require('../../helper/message');
// const { ErrorCode } = require('../../helper/statusCode');
// const { SuccessCode } = require('../../helper/statusCode');
const mongoose = require('mongoose')
const stripe = require("stripe")("sk_test_51HpT2LCqtD4cxQPsXTUC40N2Eloiyw91WdjH09qYPUpxmTt2hiXq0vqI13gNWpJ8lqzbsAgR6XHECWE07shIUWG900UDpAxVn3");





module.exports = {

    editProfile: async (req, res) => {
        try {
            let data = await user.findOne({ _id: req.userId })
            if (!data) return res.status(404).send({ responseMessage: ErrorMessage.NOT_FOUND })
            if (req.body.lat && req.body.long) {
                req.body.location = { type: "Point", coordinates: [parseFloat(req.body.long), parseFloat(req.body.lat)], address: req.body.address }
            }
            let updateData = await user.findOneAndUpdate({ _id: data._id }, { $set: req.body }, { new: true })
            if (!updateData) return res.status(500).send({ responseMessage: ErrorMessage.INTERNAL_ERROR })
            return res.status(200).send({ responseMessage: SuccessMessage.DATA_SAVED, updateData })
        }
        catch (e) {
            return res.status(501).send({ responseMessage: ErrorMessage.SOMETHING_WRONG, e })
        }
    },


    /**
* Function Name :changePassword
* Description   :change password
*
* @return response
*/
    changePassword: (req, res) => {
        try {
            let userId = req.userId
            user.findOne({ _id: userId }, (error, userDetails) => {
                if (error) return res.status(500).send({ responseMessage: ErrorMessage.INTERNAL_ERROR, error })
                else if (!userDetails) {
                    return res.status(404).send({ responseMessage: ErrorMessage.NOT_FOUND })
                } else {
                    let check = bcrypt.compareSync(req.body.oldPassword, userDetails.password)
                    if (check) {
                        if (req.body.newPassword == req.body.confirmPassword) {
                            let hashPassword = bcrypt.hashSync(req.body.confirmPassword)
                            user.findOneAndUpdate({ _id: userDetails._id }, { $set: { password: hashPassword } }, { new: true }, (updateErr, passwordUpdate) => {
                                if (updateErr) return res.status(500).send({ responseMessage: ErrorMessage.INTERNAL_ERROR, updateErr })
                                // notify to ownself 
                                let name = userDetails.fullName
                                const pushTitle = "Password Reset"
                                const pushBody = `${name}, your password has been successfully reset`
                                commonFunction.pushNotification(userDetails.deviceToken, pushTitle, pushBody)
                                let notifyToOwn = {
                                    userId: userDetails._id,
                                    title: "Password Reset",
                                    body: `${name}, your password has been successfully reset`,
                                    notificationType: 'NONE'
                                }
                                let notiData = new notification(notifyToOwn)
                                notiData.save()
                                return res.status(200).send({ responseMessage: SuccessMessage.RESET_SUCCESS })
                            })
                        } else {
                            return res.status(400).send({ responseMessage: ErrorMessage.NEW_CONFIRM_INCORRECT })

                        }
                    } else {
                        return res.status(400).send({ responseMessage: ErrorMessage.OLD_PASSWORD_INCORRECT })
                    }
                }
            })
        } catch (e) {
            return res.status(501).send({ responseMessage: ErrorMessage.SOMETHING_WRONG, e })

        }
    },




    viewPrivacyPolicy: async (req, res) => {
        try {
            let data = await cms.findOne({ Type: "PRIVACY_POLICY" })
            if (!data) return res.status(404).send({ responseMessage: ErrorMessage.NOT_FOUND })
            return res.status(200).send({ responseMessage: SuccessMessage.DATA_FOUND, data })
        }
        catch (e) {
            return res.status(501).send({ responseMessage: ErrorMessage.SOMETHING_WRONG, e })
        }
    },

    viewTermsAndCondtion: async (req, res) => {
        try {
            let data = await cms.findOne({ Type: "TERMS" })
            if (!data) return res.status(404).send({ responseMessage: ErrorMessage.NOT_FOUND })
            return res.status(200).send({ responseMessage: SuccessMessage.DATA_FOUND, data })
        }
        catch (e) {
            return res.status(501).send({ responseMessage: ErrorMessage.SOMETHING_WRONG, e })
        }
    },
    aboutUs: async (req, res) => {
        try {
            let data = await cms.findOne({ Type: "ABOUT_US" })
            if (!data) return res.status(404).send({ responseMessage: ErrorMessage.NOT_FOUND })
            return res.status(200).send({ responseMessage: SuccessMessage.DATA_FOUND, data })
        }
        catch (e) {
            return res.status(501).send({ responseMessage: ErrorMessage.SOMETHING_WRONG, e })
        }
    },
    addCard: async (req, res) => {
        try {
            userId = req.userId
            let query = { cardNumber: req.body.cardNumber, status: "ACTIVE", userId: userId }
            let data = await card.findOne(query)
            if (data) return res.status(409).send({ responseMessage: ErrorMessage.ALREADY_EXITS })
            let cardObj = {
                cardType: req.body.cardType,
                cardHolderName: req.body.cardHolderName,
                cardNumber: req.body.cardNumber,
                expMonth: req.body.expMonth,
                expYear: req.body.expYear,
                userId: userId
            }

            let cardData = new card(cardObj);
            cardData.save((error, result) => {
                if (error) return res.status(500).send({ responseMessage: ErrorMessage.INTERNAL_ERROR })
                return res.status(200).send({ responseMessage: SuccessMessage.DATA_SAVED, result })
            })
        }
        catch (e) {
            console.log("======e", e)
            return res.status(501).send({ responseMessage: ErrorMessage.SOMETHING_WRONG, e })
        }
    },

    cardList: async (req, res) => {
        try {
            userId = req.userId
            let documentList;
            let totalList;
            let pageNumber = +req.query.pageNumber
            let limit = +req.query.limit
            let criteria = { userId: userId, status: "ACTIVE" }
            totalList = await card.find(criteria).countDocuments();
            documentList = await card.find(criteria).sort({ createdAt: -1 })
                .skip((limit * pageNumber) - limit).limit(limit).lean()
            if (!documentList) {
                return res.status(404).send({ responseMessage: ErrorMessage.NOT_FOUND })
            }
            return res.status(200).send({ responseMessage: SuccessMessage.DATA_FOUND, documentList, totalList })


        } catch (e) {
            return res.status(501).send({ responseMessage: ErrorMessage.SOMETHING_WRONG, e })
        }
    },

    editCard: async (req, res) => {
        try {
            let data = await card.findOne({ _id: req.body.cardId })
            if (!data) return res.status(404).send({ responseMessage: ErrorMessage.NOT_FOUND })
            let updateData = await card.findOneAndUpdate({ _id: data._id }, { $set: req.body }, { new: true })
            if (!updateData) return res.status(500).send({ responseMessage: ErrorMessage.INTERNAL_ERROR })
            return res.status(200).send({ responseMessage: SuccessMessage.DATA_SAVED, updateData })
        }
        catch (e) {
            return res.status(501).send({ responseMessage: ErrorMessage.SOMETHING_WRONG, e })
        }
    },

    deleteCard: async (req, res) => {
        try {
            let data = await card.findOne({ _id: req.params._id })
            if (!data) return res.status(404).send({ responseMessage: ErrorMessage.NOT_FOUND })
            let updateData = await card.findOneAndUpdate({ _id: data._id }, { $set: { status: "DELETE" } }, { new: true })
            if (!updateData) return res.status(500).send({ responseMessage: ErrorMessage.INTERNAL_ERROR })
            return res.status(200).send({ responseMessage: SuccessMessage.DATA_SAVED, updateData })
        }
        catch (e) {
            return res.status(501).send({ responseMessage: ErrorMessage.SOMETHING_WRONG, e })
        }
    },


    /**
* Function Name :logout
* Description   :logout
*
* @return responses
*/
    logout: async (req, res) => {
        try {
            userId = req.userId
            let userData = await user.findOne({ _id: userId, status: "ACTIVE" })
            if (!userData) return res.status(404).send({ responseMessage: ErrorMessage.NOT_FOUND })
            user.findOneAndUpdate({ _id: userData._id }, { $set: { token: "", deviceToken: "" } }, { new: true }, (updateErr, passwordUpdate) => {
                if (updateErr) return res.status(500).send({ responseMessage: ErrorMessage.INTERNAL_ERROR, updateErr })
                return res.status(200).send({ responseMessage: SuccessMessage.LOGOUT_SUCCESS })
            })
        } catch (e) {
            return res.status(501).send({ responseMessage: ErrorMessage.SOMETHING_WRONG, e })
        }
    },

    myWallet: async (req, res) => {
        let userId = req.userId
        let walletData = await walletModel.findOne({ userId: userId })
        if (!walletData)
            return res.status(404).send({ responseMessage: ErrorMessage.NOT_FOUND })
        else {
            return res.status(200).send({ responseMessage: SuccessMessage.DATA_FOUND, walletData })
        }
    },

    mySubscription: async (req, res) => {
        let userId = req.userId
        let result = await user.findOne({ _id: userId }).select('subscriptionId').populate('subscriptionId')
        if (!result)
            return res.status(404).send({ responseMessage: ErrorMessage.NOT_FOUND })
        else {
            return res.status(200).send({ responseMessage: SuccessMessage.DATA_FOUND, result })
        }
    },

    /**
* Function Name :upgradeSubscription
* Description   :
* @return responses
*/

    upgradeSubscription: async (req, res) => {
        try {
            let userId = req.userId
            let subscriptionData = await subscriptionModel.findOne({ _id: req.body.subscriptionId })
            let userData = await user.findOne({ _id: userId })
            if (!userData) return res.status(404).send({ responseMessage: ErrorMessage.NOT_FOUND })
            var expiryDate = new Date();
            expiryDate.setDate(expiryDate.getDate() + subscriptionData.days_duration);
            console.log("Expiry date==========", expiryDate);
            stripe.tokens.create({
                card: {
                    number: req.body.cardNumber,
                    exp_month: req.body.exp_month,
                    exp_year: req.body.exp_year,
                    cvc: req.body.cvc,
                    currency: 'USD'
                }
            }, (tokenErr, token) => {
                if (tokenErr)
                    if (tokenErr) return res.status(500).send({ responseMessage: tokenErr.raw.message })
                stripe.customers.create({
                    email: userData.email,
                    source: token.id,
                }, (customerErr, customer) => {
                    if (customerErr) return res.status(500).send({ responseMessage: ErrorMessage.INTERNAL_ERROR, customerErr })
                    stripe.charges.create({
                        amount: req.body.price * 100,
                        currency: "USD",
                        customer: customer.id
                    }, (chargeErr, charge) => {
                        if (chargeErr) return res.status(500).send({ responseMessage: ErrorMessage.INTERNAL_ERROR, chargeErr })
                        var paymentObj = {
                            transactionId: charge.balance_transaction,
                            chargeId: charge.id,
                            currency: charge.currency,
                            amount: req.body.price,
                            customerId: charge.customer,
                            url: charge.receipt_url,
                            email: customer.email,
                            transactionStatus: charge.status,
                            userId: userId,
                            paymentType: req.body.cardType
                        }
                        var paymentData = new transactionModel(paymentObj)
                        paymentData.save(async (paymentSaveErr, paymentSaveData) => {
                            if (paymentSaveErr) return res.status(500).send({ responseMessage: ErrorMessage.INTERNAL_ERROR, paymentSaveErr })
                            await user.findOneAndUpdate({ _id: userData._id },
                                { $set: { isSubscribe: true, subscriptionId: req.body.subscriptionId, expiryDate: expiryDate } }, { new: true })
                            let walletData = await walletModel.findOne({ userId: userId })
                            let walletUpdate = await walletModel.findOneAndUpdate({ _id: walletData._id },
                                {
                                    $set: {
                                        subscriptionId: req.body.subscriptionId,
                                        totalBalance: walletData.totalBalance,
                                        sessions: subscriptionData.session_numbers,
                                        minutesOfAudioCalls: subscriptionData.minutesOfAudioCalls,
                                        minutesOfVideoCalls: subscriptionData.minutesOfVideoCalls,
                                        numberOfMessages: subscriptionData.numberOfMessages,
                                        numberOfSecondrySpecialty: subscriptionData.numberOfSecondrySpecialty,
                                        numberOfLeads: subscriptionData.numberOfLeads,
                                        isFeatured: subscriptionData.isFeatured,
                                        sessions: subscriptionData.session_numbers,
                                        expiryDate: expiryDate
                                    }
                                }, { new: true })
                            if (!walletUpdate) return res.status(500).send({ responseMessage: "Wallet data not update" })
                            if (req.body.couponId) {
                                let couponData = await couponModel.findOne({ _id: req.body.couponId })
                                await couponModel.findOneAndUpdate({ _id: couponData._id },
                                    { $set: { numberOfUsed: couponData.numberOfUsed + 1 } }, { new: true })
                            }

                            if (req.body.cardSave == true) {
                                let cardObj = {
                                    cardType: req.body.cardType,
                                    cardHolderName: req.body.cardHolderName,
                                    cardNumber: req.body.cardNumber,
                                    expMonth: req.body.exp_month,
                                    expYear: req.body.exp_year,
                                    userId: userId
                                }

                                let cardData = new cardModel(cardObj);
                                cardData.save()
                            }
                            let prefix = '#'
                            let documentNumber = await invoiceModel.find({}).countDocuments()
                            console.log("=========documentNumber1", documentNumber)

                            var numberCount;
                            if (documentNumber === 0) {
                                numberCount = 1
                            } else {
                                numberCount = documentNumber
                            }
                            let invoiceNumber = prefix + numberCount
                            let invoiceObj = {
                                paymentType: req.body.cardType,
                                cardNumber: req.body.cardNumber,
                                serviceProviderId: userId,
                                invoiceNumber: invoiceNumber,
                                invoiceType: "SUBSCRIPTION",
                                amount: req.body.price,
                                subscriptionId: req.body.subscriptionId,
                                invoiceFrom: userId
                            }
                            let invoiceData = new invoiceModel(invoiceObj);
                            invoiceData.save()

                            // notify to ownself 
                            const pushTitle = "Subscription plan updated"
                            const pushBody = "Congratulations, your account is upgraded successfully"
                            commonFunction.pushNotification(userData.deviceToken, pushTitle, pushBody)
                            let notifyToOwn = {
                                userId: userData._id,
                                title: "Subscription plan updated",
                                body: "Congratulations, your account is upgraded successfully",
                                notificationType: 'SUBSCRIPTION'
                            }
                            let notiData = new notification(notifyToOwn)
                            notiData.save()

                            return res.status(200).send({ responseMessage: "Subscribe successfully" })

                        })

                    })

                })
            })

        }
        catch (e) {
            console.log("catch", e)
            return res.status(501).send({ responseMessage: ErrorMessage.SOMETHING_WRONG, e })
        }
    },


    editAvailability: async (req, res) => {
        try {
            let data = await user.findOne({ _id: req.userId })
            if (!data) return res.status(404).send({ responseMessage: ErrorMessage.NOT_FOUND })
            let updateData = await user.findOneAndUpdate({ _id: data._id }, { $set: req.body }, { new: true })
            if (!updateData) return res.status(500).send({ responseMessage: ErrorMessage.INTERNAL_ERROR })
            return res.status(200).send({ responseMessage: SuccessMessage.DATA_SAVED, updateData })
        }
        catch (e) {
            return res.status(501).send({ responseMessage: ErrorMessage.SOMETHING_WRONG, e })
        }
    },


    invoiceBillList: async (req, res) => {
        try {
            userId = req.userId
            let totalList = 0;
            let pageNumber = +req.query.pageNumber || 1
            let limit = +req.query.limit || 100000
            let query = { serviceProviderId: userId }
            totalList = await invoiceModel.find(query).countDocuments();
            let invoiceData = await invoiceModel.find(query).populate('patientId', 'firstName lastName location')
                .populate('subscriptionId', 'name')
                .sort({ createdAt: -1 })
                .skip((limit * pageNumber) - limit).limit(limit).lean();
            if (!invoiceData) {
                return res.status(404).send({ responseCode: 404, responseMessage: ErrorMessage.NOT_FOUND })
            } else {
                return res.status(200).send({ responseCode: 200, responseMessage: SuccessMessage.DATA_FOUND, invoiceData, totalList })

            }
        } catch (e) {
            return res.status(501).send({ responseCode: 501, responseMessage: ErrorMessage.SOMETHING_WRONG, e })
        }
    },


    /**
     * Function Name :upgradeSubscription_from wallet
     * Description   :
     * @return responses
     */

    upgradeSubscription_fromWallet: async (req, res) => {
        try {
            let userId = req.userId
            let subscriptionData = await subscriptionModel.findOne({
                _id: req.body.subscriptionId
            })
            let userData = await user.findOne({
                _id: userId
            })
            if (!userData) return res.status(404).send({
                responseMessage: ErrorMessage.NOT_FOUND
            })
            var expiryDate = new Date();
            expiryDate.setDate(expiryDate.getDate() + subscriptionData.days_duration);
            console.log("Expiry date==========", expiryDate);
            let walletResult = await walletModel.findOne({
                userId: userId
            })

            console.log("walletResult.totabalance", walletResult.totalBalance)
            console.log("subscription price", subscriptionData.price)
            if (walletResult.totalBalance >= subscriptionData.price) {
                console.log("iam in")
                const balance = walletResult.totalBalance - subscriptionData.price
                console.log("=============type of", typeof balance, balance)
                let walletUpdate = await walletModel.findOneAndUpdate({
                    _id: walletResult._id
                }, {
                    $set: {
                        subscriptionId: req.body.subscriptionId,
                        totalBalance: balance,
                        sessions: subscriptionData.session_numbers,
                        minutesOfAudioCalls: subscriptionData.minutesOfAudioCalls,
                        minutesOfVideoCalls: subscriptionData.minutesOfVideoCalls,
                        numberOfMessages: subscriptionData.numberOfMessages,
                        numberOfSecondrySpecialty: subscriptionData.numberOfSecondrySpecialty,
                        numberOfLeads: subscriptionData.numberOfLeads,
                        isFeatured: subscriptionData.isFeatured,
                        sessions: subscriptionData.session_numbers,
                        expiryDate: expiryDate
                    }
                }, {
                    new: true
                })
                console.log("wallet update", walletUpdate)
                if (walletUpdate) {
                    let updateUser = await user.findOneAndUpdate({
                        _id: userData._id
                    }, {
                        $set: {
                            isSubscribe: true,
                            subscriptionId: req.body.subscriptionId,
                            expiryDate: expiryDate
                        }
                    }, {
                        new: true
                    })
                    if (!updateUser) {
                        return res.status(500).send({
                            responseMessage: "Wallet data not update"
                        })
                    }
                    // notify to ownself 
                    const pushTitle = "Subscription plan updated"
                    const pushBody = "Congratulations, your account is upgraded successfully"
                    commonFunction.pushNotification(userData.deviceToken, pushTitle, pushBody)
                    let notifyToOwn = {
                        userId: userData._id,
                        title: "Subscription plan updated",
                        body: "Congratulations, your account is upgraded successfully",
                        notificationType: 'SUBSCRIPTION'
                    }
                    let notiData = new notification(notifyToOwn)
                    notiData.save()
                    return res.status(200).send({
                        responseMessage: "Subscribe successfully"
                    })
                }
            } else {
                return res.status(500).send({
                    responseMessage: "You don't have sufficient balance in wallet."
                })
            }

        } catch (e) {
            console.log("catch", e)
            return res.status(501).send({
                responseMessage: ErrorMessage.SOMETHING_WRONG,
                e
            })
        }
    },



    /**
 * Function Name :Amount withdraw request from wallet
 * Description   :
 * @return responses
 */

    withdrawRequest: async (req, res) => {
        try {
            let userId = req.userId
            let userData = await user.findOne({
                _id: userId
            })
            if (!userData) return res.status(404).send({
                responseMessage: ErrorMessage.NOT_FOUND
            })

            let walletResult = await walletModel.findOne({
                userId: userId
            })
            if (req.body.amount > 0) {
                if (walletResult.totalBalance >= req.body.amount) {

                    await withdrawRequestModel.findOneAndUpdate({ userId: userId, status: "ACTIVE", paymentStatus: "PENDING" }, { $set: { status: "DELETE" } }, { new: true })

                    let obj = {
                        userId: userId,
                        amount: req.body.amount,
                        bankName: req.body.bankName,
                        ifscCode: req.body.ifscCode,
                        accountHolderName: req.body.accountHolderName,
                        branchName: req.body.branchName,
                        accountNumber: req.body.accountNumber
                    }
                    let requestData = new withdrawRequestModel(obj);
                    requestData.save((error, result) => {
                        if (error) return res.status(500).send({ responseMessage: ErrorMessage.INTERNAL_ERROR })
                        return res.status(200).send({ responseMessage: "Withdraw request sent to admin", result })
                    })

                } else {
                    return res.status(500).send({
                        responseMessage: "You don't have sufficient balance in wallet."
                    })
                }
            } else {
                return res.status(500).send({
                    responseMessage: "You can not withdraw 0 amount"
                })
            }

        } catch (e) {
            console.log("catch", e)
            return res.status(501).send({
                responseMessage: ErrorMessage.SOMETHING_WRONG,
                e
            })
        }
    },


    transactionHistory: async (req, res) => {
        try {
            userId = req.userId
            let totalList = 0;
            let pageNumber = +req.query.pageNumber || 1
            let limit = +req.query.limit || 100000
            let query = { userId: userId }
            totalList = await withdrawRequestModel.find(query).countDocuments();
            let transactionData = await withdrawRequestModel.find(query)
                .sort({ createdAt: -1 })
                .skip((limit * pageNumber) - limit).limit(limit).lean();
            if (!transactionData) {
                return res.status(404).send({ responseCode: 404, responseMessage: ErrorMessage.NOT_FOUND })
            } else {
                return res.status(200).send({ responseCode: 200, responseMessage: SuccessMessage.DATA_FOUND, transactionData, totalList })

            }
        } catch (e) {
            return res.status(501).send({ responseCode: 501, responseMessage: ErrorMessage.SOMETHING_WRONG, e })
        }
    },

}