const user = require('../../model/user')
const notification = require('../../model/notification')



const { commonResponse: response } = require('../../helper/commonResponseHandler');
const { ErrorMessage } = require('../../helper/message');
const { SuccessMessage } = require('../../helper/message');

const mongoose = require('mongoose')

const { findOne, findOneAndUpdate } = require('../../model/user')




module.exports = {


    notificationList: async (req, res) => {
        try {
            userId = req.userId
            let totalList = 0;
            let pageNumber = +req.query.pageNumber || 1
            let limit = +req.query.limit || 100000
            let query = { userId: userId, status: "ACTIVE" }
            totalList = await notification.find(query).countDocuments();
            let notificationData = await notification.find(query,{ status:0}).sort({ createdAt: -1 })
                .skip((limit * pageNumber) - limit).limit(limit).lean();
            if (!notificationData) {
                return res.status(404).send({ responseCode: 404, responseMessage: ErrorMessage.NOT_FOUND })
            } else {
                let updatedata = await notification.update({ userId: userId }, { isRead: true }, { multi: true })
                return res.status(200).send({ responseCode: 200, responseMessage: SuccessMessage.DATA_FOUND, notificationData, totalList })

            }
        } catch (e) {
            return res.status(501).send({ responseCode: 501, responseMessage: ErrorMessage.SOMETHING_WRONG, e })
        }
    },

    deleteNotification: async (req, res) => {
        try {
            let data = await notification.findOne({ _id: req.params._id})
            if (!data) return res.status(404).send({ responseMessage: ErrorMessage.NOT_FOUND })
            let updateData = await notification.findOneAndUpdate({ _id: data._id }, { $set: { status:"DELETE"} }, { new: true })
            if (!updateData) return res.status(500).send({ responseMessage: ErrorMessage.INTERNAL_ERROR })
            return res.status(200).send({ responseMessage: SuccessMessage.DELETE_SUCCESS, updateData })
        }
        catch (e) {
            return res.status(501).send({ responseMessage: ErrorMessage.SOMETHING_WRONG, e })
        }
    },

    viewNotification: async (req, res) => {
        let query = { _id: req.params.id }
        let data = await notification.findOne(query)
        if (!data)
            return res.status(404).send({ responseMessage: ErrorMessage.NOT_FOUND })
        else {
            return res.status(200).send({ responseMessage: SuccessMessage.DATA_FOUND, data })
        }
    },


}