const medicalRecord = require('../../model/medicalRecord')
const notification = require('../../model/notification')
const user = require('../../model/user')
const commonFunction = require('../../utility/common')

const { commonResponse: response } = require('../../helper/commonResponseHandler');
const { ErrorMessage } = require('../../helper/message');
const { SuccessMessage } = require('../../helper/message');

const mongoose = require('mongoose')

const { findOne, findOneAndUpdate } = require('../../model/user')




module.exports = {
    addMedicalRecord: async (req, res) => {
        try {
            if (!req.body.patientId || !req.body.name || !req.body.description || !req.body.medicalRecordFile) {
                return res.status(204).send({ responseMessage: "Parameter missing" })
            }
            let patientData = await user.findOne({ _id: req.body.patientId })
            req.body.serviceProviderId = req.userId
            let medicalData = new medicalRecord(req.body);
            medicalData.save((error, result) => {
                if (error) return res.status(500).send({ responseMessage: ErrorMessage.INTERNAL_ERROR })

                const pushTitle = "Medical records update"
                const pushBody = "Your medical records are updated.Click on Medical History to check the record."
                commonFunction.pushNotification(patientData.deviceToken, pushTitle, pushBody)
                let notify = {
                    userId: patientData._id,
                    title: "Medical records update",
                    body:  "Your medical records are updated.Click on Medical History to check the record.",
                    notificationType: 'MEDICAL_RECORDS'
                }
                let notiData = new notification(notify)
                notiData.save()
                return res.status(200).send({ responseMessage: SuccessMessage.DATA_SAVED, result })
            })
        }
        catch (e) {
            console.log("======e", e)
            return res.status(501).send({ responseMessage: ErrorMessage.SOMETHING_WRONG, e })
        }
    },


    medicalRecordList: async (req, res) => {
        try {
            userId = req.userId
            let totalList = 0;
            let pageNumber = +req.query.pageNumber || 1
            let limit = +req.query.limit || 100000
            let query = { serviceProviderId: userId, patientId:req.query.patientId, status: "ACTIVE" }
            totalList = await medicalRecord.find(query).countDocuments();
            let data = await medicalRecord.find(query,{ status:0}).sort({ createdAt: -1 })
                .skip((limit * pageNumber) - limit).limit(limit).lean();
            if (!data) {
                return res.status(404).send({ responseCode: 404, responseMessage: ErrorMessage.NOT_FOUND })
            } else {
                return res.status(200).send({ responseCode: 200, responseMessage: SuccessMessage.DATA_FOUND, data, totalList })

            }
        } catch (e) {
            return res.status(501).send({ responseCode: 501, responseMessage: ErrorMessage.SOMETHING_WRONG, e })
        }
    },

    viewMedicalRecord: async (req, res) => {
        let query = { _id: req.params._id }
        let data = await medicalRecord.findOne(query)
        if (!data)
            return res.status(404).send({ responseMessage: ErrorMessage.NOT_FOUND })
        else {
            return res.status(200).send({ responseMessage: SuccessMessage.DATA_FOUND, data })
        }
    },

    editMedicalRecord: async (req, res) => {
        try {
            let data = await medicalRecord.findOne({ _id: req.body.medicalrecordId, status: { $ne: "DELETE" } })
            if (!data) return res.status(404).send({ responseMessage: ErrorMessage.NOT_FOUND })
            let updateData = await medicalRecord.findOneAndUpdate({ _id: data._id }, { $set: req.body }, { new: true })
            if (!updateData) return res.status(500).send({ responseMessage: ErrorMessage.INTERNAL_ERROR })
            return res.status(200).send({ responseMessage: SuccessMessage.DATA_SAVED, updateData })
        }
        catch (e) {
            return res.status(501).send({ responseMessage: ErrorMessage.SOMETHING_WRONG, e })
        }
    },


}