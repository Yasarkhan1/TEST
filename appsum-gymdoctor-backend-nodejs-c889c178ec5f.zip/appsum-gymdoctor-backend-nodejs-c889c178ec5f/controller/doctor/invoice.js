const invoiceModel = require('../../model/invoiceModel')
const { commonResponse: response } = require('../../helper/commonResponseHandler');
const { ErrorMessage } = require('../../helper/message');
const { SuccessMessage } = require('../../helper/message');

const mongoose = require('mongoose')

const { findOne, findOneAndUpdate } = require('../../model/user')




module.exports = {
    invoiceList: async (req, res) => {
        try {
            userId = req.userId
            let totalList = 0;
            let pageNumber = +req.query.pageNumber || 1
            let limit = +req.query.limit || 100000
            let query = { serviceProviderId: userId, patientId: req.query.patientId}
            totalList = await invoiceModel.find(query).countDocuments();
            let prescriptionData = await invoiceModel.find(query, { status: 0 }).sort({ createdAt: -1 })
                .skip((limit * pageNumber) - limit).limit(limit).lean();
            if (!prescriptionData) {
                return res.status(404).send({ responseCode: 404, responseMessage: ErrorMessage.NOT_FOUND })
            } else {
                return res.status(200).send({ responseCode: 200, responseMessage: SuccessMessage.DATA_FOUND, prescriptionData, totalList })

            }
        } catch (e) {
            return res.status(501).send({ responseCode: 501, responseMessage: ErrorMessage.SOMETHING_WRONG, e })
        }
    },
 
    viewInvoice: async (req, res) => {
        let query = { _id: req.params._id }
        let data = await invoiceModel.findOne(query).populate('serviceProviderId patientId',"firstName lastName fullName location")
        if (!data)
            return res.status(404).send({ responseMessage: ErrorMessage.NOT_FOUND })
        else {
            return res.status(200).send({ responseMessage: SuccessMessage.DATA_FOUND, data })
        }
    },

}