const user = require('../../model/user')
const ratingModel = require('../../model/rating')

const { commonResponse: response } = require('../../helper/commonResponseHandler');
const { ErrorMessage } = require('../../helper/message');
const { SuccessMessage } = require('../../helper/message');
// const { ErrorCode } = require('../../helper/statusCode');
// const { SuccessCode } = require('../../helper/statusCode');
const mongoose = require('mongoose')




module.exports = {
    reviewsList: async (req, res) => {
        try {
            let userId = req.userId
            let documentList;
            let totalList;
            let pageNumber = +req.query.pageNumber || 1
            let limit = +req.query.limit || 10
            let criteria = { doctorId: userId, status: "ACTIVE" }
            totalList = await ratingModel.find(criteria).countDocuments();
            documentList = await ratingModel.find(criteria, { status: 0}).populate({
                path: 'userId',
                model: 'user',
                select: 'firstName lastName profilePic',
            }).sort({ createdAt: -1 })
                .skip((limit * pageNumber) - limit).limit(limit).lean()
            if (!documentList) {
                return res.status(404).send({ responseMessage: ErrorMessage.NOT_FOUND })
            }
            return res.status(200).send({ responseMessage: SuccessMessage.DATA_FOUND, documentList, totalList })
        } catch (e) {
            console.log(e)
            return res.status(501).send({ responseMessage: ErrorMessage.SOMETHING_WRONG, e })
        }
    },


    challengeReviews: async (req, res) => {
        try {
            let data = await ratingModel.findOne({ _id: req.body.reviewId, status:"ACTIVE" })
            if (!data) return res.status(404).send({ responseMessage: ErrorMessage.NOT_FOUND })
            let updateData = await ratingModel.findOneAndUpdate({ _id: data._id }, { $set: { challenge : req.body.challenge,isChallenged:true} }, { new: true })
            if (!updateData) return res.status(500).send({ responseMessage: ErrorMessage.INTERNAL_ERROR })
            return res.status(200).send({ responseMessage: SuccessMessage.DATA_SAVED, updateData })
        }
        catch (e) {
            return res.status(501).send({ responseMessage: ErrorMessage.SOMETHING_WRONG, e })
        }
    },





}