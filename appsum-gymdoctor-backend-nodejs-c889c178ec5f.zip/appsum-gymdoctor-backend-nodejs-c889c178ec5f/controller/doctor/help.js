const user = require('../../model/user')
const help = require('../../model/help')
const helpMessage = require('../../model/helpMessage')



const { commonResponse: response } = require('../../helper/commonResponseHandler');
const { ErrorMessage } = require('../../helper/message');
const { SuccessMessage } = require('../../helper/message');

const mongoose = require('mongoose')

const { findOne, findOneAndUpdate } = require('../../model/user')




module.exports = {


    submitHelpRequest: async (req, res) => {
        try {
            let userId = req.userId
            let userData = await user.findOne({ _id: userId })
            req.body.userId = userId
            req.body.userType = userData.userType
            let helpData = new help(req.body);
            helpData.save((error, result) => {
                if (error) return res.status(500).send({ responseMessage: ErrorMessage.INTERNAL_ERROR })
                return res.status(200).send({ responseMessage:"Help Request sent successfully", result })
            })
        }
        catch (e) {
            return res.status(501).send({ responseMessage: ErrorMessage.SOMETHING_WRONG, e })
        }
    },

    helpRequestList: async (req, res) => {
        try {
            userId = req.userId
            let totalList = 0;
            let pageNumber = +req.query.pageNumber || 1
            let limit = +req.query.limit || 100000
            let query = { userId: userId, status: "ACTIVE" }
            totalList = await help.find(query).countDocuments();
            let helpData = await help.find(query,{ status:0}).populate('userId','firstName lastName profilePic fullName').sort({ createdAt: -1 })
                .skip((limit * pageNumber) - limit).limit(limit).lean();
            if (!helpData) {
                return res.status(404).send({ responseCode: 404, responseMessage: ErrorMessage.NOT_FOUND })
            } else {
                return res.status(200).send({ responseCode: 200, responseMessage: SuccessMessage.DATA_FOUND, helpData, totalList })
            }
        } catch (e) {
            return res.status(501).send({ responseCode: 501, responseMessage: ErrorMessage.SOMETHING_WRONG, e })
        }
    },

    viewHelpRequest: async (req, res) => {
        let query = { _id: req.params.id }
        let data = await help.findOne(query).populate('userId','fullName profilePic')
        if (!data)
            return res.status(404).send({ responseMessage: ErrorMessage.NOT_FOUND })
        else {
            let documentList;
            let totalList;
            let pageNumber = +req.query.pageNumber || 1
            let limit = +req.query.limit || 10000
            let criteria = { ticketId : data._id,status: { $ne: "DELETE" }}
            totalList = await helpMessage.find(criteria).countDocuments();
            documentList = await helpMessage.find(criteria).populate('userId adminId','firstName lastName fullName profilePic userType').sort({ createdAt: 1 })
                .skip((limit * pageNumber) - limit).limit(limit).lean()
            if (!documentList) {
                return res.status(404).send({ responseMessage: ErrorMessage.NOT_FOUND })
            }
            return res.status(200).send({ responseMessage: SuccessMessage.DATA_FOUND, data,totalList,documentList })
        }
    },

    replyOnRequest: async (req, res) => {
        try {
            let userId = req.userId
            let data = await help.findOne({ _id: req.body._id, status: { $ne: "DELETE" } })
            if (!data) return res.status(404).send({ responseMessage: ErrorMessage.NOT_FOUND })
            let obj = {
                userId : userId,
                ticketId : data._id,
                message : req.body.message,
                replyBy:"USER"
            }
            let helpData = new helpMessage(obj);
            helpData.save((error, result) => {
                if (error) return res.status(500).send({ responseMessage: ErrorMessage.INTERNAL_ERROR ,error})
                return res.status(200).send({ responseMessage: SuccessMessage.DATA_SAVED, result })
            })
        }
        catch (e) {
            console.log(e)
            return res.status(501).send({ responseMessage: ErrorMessage.SOMETHING_WRONG, e })
        }
    },

}