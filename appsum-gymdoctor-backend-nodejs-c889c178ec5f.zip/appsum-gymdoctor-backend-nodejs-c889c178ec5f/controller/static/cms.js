const cms = require('../../model/cms')
const testimonialModel = require('../../model/testimonial')
const contactUsModel = require('../../model/contactUs')
const newsLetter = require('../../model/newsLetter')
const teamMember = require('../../model/teamMember')





const { commonResponse: response } = require('../../helper/commonResponseHandler');
const { ErrorMessage } = require('../../helper/message');
const { SuccessMessage } = require('../../helper/message');

const mongoose = require('mongoose')

// const { ErrorCode } = require('../../helper/statusCode');
// const { SuccessCode } = require('../../helper/statusCode');





module.exports = {

    getStaticPage: async (req, res) => {
        try {
            let data = await cms.findOne({ Type: req.query.Type })
            if (!data) return res.status(404).send({ responseMessage: ErrorMessage.NOT_FOUND })
            return res.status(200).send({ responseMessage: SuccessMessage.DATA_FOUND, data })
        }
        catch (e) {
            return res.status(501).send({ responseMessage: ErrorMessage.SOMETHING_WRONG, e })
        }
    },


    testimonialList: async (req, res) => {
        try {
            let documentList;
            let criteria = { status: "ACTIVE" }
            documentList = await testimonialModel.find(criteria).sort({ createdAt: -1 })
            if (!documentList) {
                return res.status(404).send({ responseMessage: ErrorMessage.NOT_FOUND })
            }
            return res.status(200).send({ responseMessage: SuccessMessage.DATA_FOUND, documentList })


        } catch (e) {
            return res.status(501).send({ responseMessage: ErrorMessage.SOMETHING_WRONG, e })
        }
    },

    contactUs_form: async (req, res) => {
        try {
            let objToSave = {
                name: req.body.name,
                email: req.body.email,
                mobileNumber: req.body.mobileNumber,
                message: req.body.message
            }
            let data = new contactUsModel(objToSave);
            data.save((error, result) => {
                if (error) return res.status(500).send({ responseMessage: ErrorMessage.INTERNAL_ERROR })
                return res.status(200).send({ responseMessage: SuccessMessage.DATA_SAVED, result })
            })
        }
        catch (e) {
            return res.status(501).send({ responseMessage: ErrorMessage.SOMETHING_WRONG, e })
        }
    },

    teamList: async (req, res) => {
        try {
            let documentList;
            let criteria = { status: "ACTIVE" }
            documentList = await teamMember.find(criteria).sort({ createdAt: -1 })
            if (!documentList) {
                return res.status(404).send({ responseMessage: ErrorMessage.NOT_FOUND })
            }
            return res.status(200).send({ responseMessage: SuccessMessage.DATA_FOUND, documentList })


        } catch (e) {
            return res.status(501).send({ responseMessage: ErrorMessage.SOMETHING_WRONG, e })
        }
    },
    

    subscribe_newsLetter: async (req, res) => {
        try {
            let objToSave = {
                name: req.body.name,
                email: req.body.email,
            }
            let data = new newsLetter(objToSave);
            data.save((error, result) => {
                if (error) return res.status(500).send({ responseMessage: ErrorMessage.INTERNAL_ERROR })
                return res.status(200).send({ responseMessage: SuccessMessage.DATA_SAVED, result })
            })
        }
        catch (e) {
            return res.status(501).send({ responseMessage: ErrorMessage.SOMETHING_WRONG, e })
        }
    },
}