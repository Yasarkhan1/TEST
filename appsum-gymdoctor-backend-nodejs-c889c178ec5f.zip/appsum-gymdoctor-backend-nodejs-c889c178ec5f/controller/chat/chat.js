const mongoose = require('mongoose');

const User = require("../../model/user");
const walletModel = require('../../model/wallet')
// const {pageSizes} = require('../liveStatus');
const _ = require("underscore");
var fs = require('fs');
const path = require('path');
const { CHATCONSTANTS, CHATS } = require("../../model/chat");
const USERS = [];
const SOCKETPEOPLE = {};
var pageNovar = 1;
var pageSizevar = 10;

module.exports = (io) => {

    io.on('connection', (socket) => {
        console.log('New connection');


        /**
              * socket connect event.
              * check user is already in socket.
              * to connect user with socket manually.
              * emit to all user is connected user.
              */
        socket.on("connectUser", async (data) => {
            try {
                var userindex = USERS.indexOf(data.senderId);
                //check user index i.e. user id exist in users array or not
                console.log("======userindex", userindex)
                if (userindex > -1) {
                    for (var id in SOCKETPEOPLE) {
                        console.log("Socket people", SOCKETPEOPLE)
                        // user already exist in socket
                        if (SOCKETPEOPLE[id] == data.senderId) {
                            delete SOCKETPEOPLE[id];
                            USERS.splice(userindex, 1);
                            SOCKETPEOPLE[socket.id] = data.senderId;
                            USERS.push(data.senderId);
                        }
                    }
                } else {
                    console.log("==========im in new socketid creation")
                    // create new socket id with senderId
                    SOCKETPEOPLE[socket.id] = data.senderId;
                    USERS.push(data.senderId);
                    let updateUser = await User.findOneAndUpdate(
                        { _id: data.senderId },
                        { socketId: socket.id, isOnline: true },
                        { new: true }
                    );
                }

                // check SOCKETPEOPLE array has id is uinque
                _.uniq(_(SOCKETPEOPLE).toArray());
                // broadcast to all users i.e. user is now online
                socket.broadcast.emit("userOnlineStatus", {
                    senderId: SOCKETPEOPLE[socket.id],
                    status: 1,
                });
                // response send to own user is online or connected with socket
                socket.emit("userOnlineStatus", {
                    senderId: SOCKETPEOPLE[socket.id],
                    status: 1,
                });
                console.log(USERS, SOCKETPEOPLE, "connection");

            } catch (err) {
                socket.emit("userOnlineStatus", err ? err : 'something went wrong');
            }
        });

        //   socket.on('disconnect', async() =>{

        //     let socketId = SOCKETPEOPLE[socket.id];
        //     delete SOCKETPEOPLE[socket.id];
        //     let index = USERS.indexOf(socketId);
        //     USERS.splice(index,1);
        //     let updateUser = await User.findOneAndUpdate(
        //       { _id: socketId },
        //       { socketId: '',isOnline:false },
        //       { new: true }
        //       );
        //       socket.broadcast.emit("userOnlineStatus", {
        //         senderId: socketId,
        //         status: 0,
        //         });
        // });

        /**
         * socket disconnect
         * disconnect manually
         */
        socket.on("disconnectUser", async (data) => {
            try {
                // maually check user is in SOCKETPEOPLE array
                for (var id in SOCKETPEOPLE) {
                    // check if socket.id is exist or not
                    SOCKETPEOPLE[socket.id] = data.senderId
                    if (SOCKETPEOPLE[socket.id] != undefined) {
                        var userindex = USERS.indexOf(SOCKETPEOPLE[socket.id]);
                        if (userindex > -1) {
                            let updateUser = await User.findOneAndUpdate(
                                { _id: data.senderId },
                                { socketId: '', isOnline: false },
                                { new: true }
                            );
                            // remove user from USERS array
                            if (updateUser) {
                                // console.log(USERS.splice(userindex, 1),"USERS.splice(userindex, 1)")
                                USERS.splice(userindex, 1);

                            }
                            // broadcast to all users that is user is now offline.
                            socket.broadcast.emit("userOnlineStatus", {
                                senderId: SOCKETPEOPLE[socket.id],
                                status: 0,
                            });
                            socket.emit("userOnlineStatus", {
                                senderId: SOCKETPEOPLE[socket.id],
                                status: 0,
                            });
                        }
                    }
                }
            } catch (err) {
                socket.emit("userOnlineStatus", err ? err : 'something went wrong');
            }
        });

        /**
         * check other user online status
         */
        socket.on("userOnlineStatus", (data) => {
            if (USERS.includes(data.receiverId)) {
                socket.emit('userOnlineStatus', { status: 1 })
            } else {
                socket.emit('userOnlineStatus', { status: 0 })
            }
        });

        /**
         * send message to other user
         * using join room
         */
        socket.on("sendMessage", async (data) => {
            if (data.senderId != data.receiverId) {
                let userData = await User.findOne({_id:data.senderId})
 
                    let walletData = await walletModel.findOne({userId:data.senderId})
                    let remainingMessage = walletData.numberOfMessages
                    if(remainingMessage > 0){
                        console.log("====================In remaing condition")
                        sendMessage(data,socket)
                        await walletModel.findOneAndUpdate({_id:walletData._id},{$set:{numberOfMessages:remainingMessage-1}},{ new: true})
                        return
 
                    }else{
                        console.log("===============im in zero")
                        socket.emit("msgReceived", 'your message limit is completed , please upgrade your subscription')
                        return
                    }

            } else {
                socket.emit("msgReceived", 'you can not chat with yourself')
            }
        });

        /**
           * get single chat details of user
           */
        socket.on("chatDetails", async (data) => {
            try {
                console.log("chatDetails===========================")
                pageNovar = parseInt(data.pageNo) || 1;
                pageSizevar = parseInt(data.pageSize) || 10;
                if (data.chatId != '') {
                    console.log("================im in chat details === chatId", data.chatId)
                    let chatDetails = await CHATS.aggregate([
                        {
                            $match: {
                                chatId: mongoose.Types.ObjectId(data.chatId),
                            }
                        },
                        {
                            $lookup: {
                                from: "user",
                                localField: "senderId",
                                foreignField: '_id',
                                as: "senderId"
                            }
                        },
                        {
                            $unwind: "$senderId"
                        },
                        {
                            $lookup: {
                                from: "user",
                                localField: "receiverId",
                                foreignField: '_id',
                                as: "receiverId"
                            }
                        },
                        {
                            $unwind: "$receiverId"
                        },
                        {
                            $sort: { createdAt: -1 },
                        },
                        // { $skip: pageSizevar * (pageNovar - 1) },
                        // { $limit: pageSizevar },  
                        {
                            $project: {
                                _id: "$_id",
                                "type": "$type",
                                "message": 1,
                                "updatedAt": "$updatedAt",
                                "isSeen": 1,
                                "chatId": 1,
                                //   files:1,
                                //   fileName:1,
                                //   thumbnail:1,
                                // // "createdAt":1,
                                "senderId._id": "$senderId._id",
                                "senderId.isOnline": "$senderId.isOnline",
                                "senderId.firstName": "$senderId.firstName",
                                "senderId.lastName": "$senderId.lastName",
                                "senderId.fullName": "$senderId.fullName",
                                "senderId.profilePic": "$senderId.profilePic",
                                "senderId.email": "$senderId.email",
                                "senderId.socketId": "$senderId.socketId",
                                "receiverId._id": "$receiverId._id",
                                "receiverId.isOnline": "$receiverId.isOnline",
                                "receiverId.firstName": "$receiverId.firstName",
                                "receiverId.lastName": "$receiverId.lastName",
                                "receiverId.fullName": "$receiverId.fullName",
                                "receiverId.profilePic": "$receiverId.profilePic",
                                "receiverId.email": "$receiverId.email",
                                "receiverId.socketId": "$receiverId.socketId",
                            }
                        }

                    ]);
                    const chatList = await CHATCONSTANTS.aggregate([
                        {
                            $match: {
                                $or: [
                                    {
                                        senderId: mongoose.Types.ObjectId(data.receiverId),
                                    },
                                    {
                                        receiverId: mongoose.Types.ObjectId(data.receiverId),
                                    },
                                ],
                            }
                        },
                        {
                            $lookup: {
                                from: "chats",
                                let: { userId: "$_id" },
                                pipeline: [
                                    { $match: { $expr: { $eq: ["$chatId", "$$userId"] }, isSeen: false, receiverId: mongoose.Types.ObjectId(data.receiverId) } },
                                ],
                                as: "msgsCount",
                            }
                        },
                        {
                            $addFields: {
                                unseenCount: { $size: "$msgsCount" }
                            }
                        },
                        {
                            $lookup: {
                                from: "chats",
                                localField: "lastmsgId",
                                foreignField: '_id',
                                as: "lastmsgId"
                            }
                        },
                        {
                            $unwind: "$lastmsgId"
                        },
                        {
                            $addFields: {
                                receiverId: {
                                    $cond: {
                                        if: {
                                            $eq: [mongoose.Types.ObjectId(data.receiverId), "$lastmsgId.receiverId"]
                                        },
                                        then: "$lastmsgId.senderId",
                                        else: "$lastmsgId.receiverId"
                                    },
                                }
                            }
                        },
                        {
                            $lookup: {
                                from: "user",
                                localField: "receiverId",
                                foreignField: '_id',
                                as: "receiverId"
                            }
                        },
                        {
                            $unwind: "$receiverId"
                        },

                        {
                            $project: {
                                _id: "$_id",
                                "receiverId": "$receiverId",
                                "senderId": "$senderId",
                                "type": "$type",
                                "isTyping": 1,
                                "unseenCount": 1,
                                newDate: 1,
                                "updatedAt": "$updatedAt",
                                "lastmsgId.receiverId._id": "$receiverId._id",
                                "lastmsgId.receiverId.message": "$lastmsgId.message",
                                // "lastmsgId.receiverId.files":"$lastmsgId.files",
                                // "lastmsgId.receiverId.thumbnail":"$lastmsgId.thumbnail",
                                "lastmsgId.receiverId.isOnline": "$receiverId.isOnline",
                                // "lastmsgId.receiverId.userName":"$receiverId.userName",
                                "lastmsgId.receiverId.profilePic": "$receiverId.profilePic",
                                "lastmsgId.receiverId.email": "$receiverId.email",
                                "lastmsgId.receiverId.socketId": "$receiverId.socketId",
                            }
                        },
                        {
                            $project: {
                                "receiverId": 0,
                            }
                        },
                        {
                            $sort: { newDate: -1 },
                        },
                    ]);
                    let otherUserDetails = await User.findOne({ _id: data.receiverId }).select("socketId");
                    socket.emit("msgReceived", chatDetails);
                    socket.broadcast.to(otherUserDetails.socketId).emit("msgReceived", chatDetails);
                    socket.broadcast.to(otherUserDetails.socketId).emit("chatLists", chatList);
                }
            } catch (err) {
                socket.emit("msgReceived", err ? err : 'something went wrong')
            }
        });

        /**
           * get chat history of user 
           * with any user(Helper, Seeker, Admin,Super-admin, other user)
           */
        socket.on("chatList", async (data) => {
            try {

                let pageNo = parseInt(data.pageNo) || 1;
                let pageSize = parseInt(data.pageSize) || 10;
                if (pageNo <= 0) {
                    throw responseMessage.PAGE_INVALID;
                }

                const chatList = await CHATCONSTANTS.aggregate([
                    {
                        $match: {
                            $or: [
                                {
                                    senderId: mongoose.Types.ObjectId(data.senderId),
                                },
                                {
                                    receiverId: mongoose.Types.ObjectId(data.senderId),
                                },
                            ],
                        }
                    },
                    {
                        $lookup: {
                            from: "chats",
                            let: { userId: "$_id" },
                            pipeline: [
                                { $match: { $expr: { $eq: ["$chatId", "$$userId"] }, isSeen: false, receiverId: mongoose.Types.ObjectId(data.senderId) } },
                            ],
                            as: "msgsCount",
                        }
                    },
                    {
                        $addFields: {
                            unseenCount: { $size: "$msgsCount" }
                        }
                    },
                    {
                        $lookup: {
                            from: "chats",
                            localField: "lastmsgId",
                            foreignField: '_id',
                            as: "lastmsgId"
                        }
                    },
                    {
                        $unwind: "$lastmsgId"
                    },
                    {
                        $addFields: {
                            receiverId: {
                                $cond: {
                                    if: {
                                        $eq: [mongoose.Types.ObjectId(data.senderId), "$lastmsgId.receiverId"]
                                    },
                                    then: "$lastmsgId.senderId",
                                    else: "$lastmsgId.receiverId"
                                },
                            }
                        }
                    },
                    {
                        $lookup: {
                            from: "user",
                            localField: "receiverId",
                            foreignField: '_id',
                            as: "receiverId"
                        }
                    },
                    {
                        $unwind: "$receiverId"
                    },

                    {
                        $project: {
                            _id: "$_id",
                            "receiverId": "$receiverId",
                            "senderId": "$senderId",
                            "type": "$type",
                            "isTyping": 1,
                            "unseenCount": 1,
                            newDate: 1,
                            "updatedAt": "$updatedAt",
                            "lastmsgId.receiverId._id": "$receiverId._id",
                            "lastmsgId.receiverId.message": "$lastmsgId.message",
                            "lastmsgId.receiverId.isOnline": "$receiverId.isOnline",
                            "lastmsgId.receiverId.files": "$lastmsgId.files",
                            //   "lastmsgId.receiverId.thumbnail":"$lastmsgId.thumbnail",
                            "lastmsgId.receiverId.firstName": "$receiverId.firstName",
                            "lastmsgId.receiverId.lastName": "$receiverId.lastName",
                            "lastmsgId.receiverId.fullName": "$receiverId.fullName",
                            "lastmsgId.receiverId.profilePic": "$receiverId.profilePic",
                            "lastmsgId.receiverId.email": "$receiverId.email",
                            "lastmsgId.receiverId.socketId": "$receiverId.socketId",
                        }
                    },
                    {
                        $project: {
                            "receiverId": 0,
                        }
                    },
                    {
                        $sort: { newDate: -1 }
                    }
                    //   { $skip: pageSize * (pageNo - 1) },
                    //   { $limit: pageSize }, 
                ]);
                socket.emit("chatLists", chatList);
                // socket.broadcast.to(chatList[0].lastmsgId.receiverId.socketId).emit("chatLists", chatList);
            } catch (err) {
                socket.emit("chatLists", err ? err : 'something went wrong');
            }
        });

        /**
         * seen msgs
         */
        socket.on("seen", async (data) => {
            try {
                // console.log(data,"~~~~~~~~~~~~~~~~~data~~~~~~~~~~~~~~");

                if (data.chatId != '') {
                    let pageNo = parseInt(data.pageNo) || 1;
                    let pageSize = parseInt(data.pageSize) || 10;
                    let otherUserDetails = await User.findOne({ _id: data.receiverId }).select("socketId");
                    let updateChat = await CHATS.updateMany({
                        chatId: data.chatId,
                        receiverId: mongoose.Types.ObjectId(data.senderId)
                    }, {
                        $set: {

                            isSeen: true
                        }
                    },
                        {
                            multi: true,
                            new: true
                        }
                    );
                    let chatDetails = await CHATS.aggregate([
                        {
                            $match: {
                                chatId: mongoose.Types.ObjectId(data.chatId),
                            }
                        },
                        {
                            $lookup: {
                                from: "user",
                                localField: "senderId",
                                foreignField: '_id',
                                as: "senderId"
                            }
                        },
                        {
                            $unwind: "$senderId"
                        },
                        {
                            $lookup: {
                                from: "user",
                                localField: "receiverId",
                                foreignField: '_id',
                                as: "receiverId"
                            }
                        },
                        {
                            $unwind: "$receiverId"
                        },

                        {
                            $sort: { createdAt: -1 },
                        },
                        //  { $skip: pageSize * (pageNo - 1) },
                        // { $limit: pageSize }, 
                        {
                            $project: {
                                _id: "$_id",
                                "type": "$type",
                                "message": 1,
                                "updatedAt": "$updatedAt",
                                "isSeen": 1,
                                "chatId": 1,
                                files: 1,
                                fileName: 1,
                                thumbnail: 1,
                                // // "createdAt":1,
                                "senderId._id": "$senderId._id",
                                "senderId.isOnline": "$senderId.isOnline",
                                "senderId.username": "$senderId.username",
                                "senderId.profileImg": "$senderId.profileImg",
                                "senderId.email": "$senderId.email",
                                "senderId.socketId": "$senderId.socketId",
                                "receiverId._id": "$receiverId._id",
                                "receiverId.isOnline": "$receiverId.isOnline",
                                "receiverId.username": "$receiverId.username",
                                "receiverId.profileImg": "$receiverId.profileImg",
                                "receiverId.email": "$receiverId.email",
                                "receiverId.socketId": "$receiverId.socketId",
                            }
                        }

                    ]);
                    const chatList = await CHATCONSTANTS.aggregate([
                        {
                            $match: {
                                $or: [
                                    {
                                        senderId: mongoose.Types.ObjectId(data.receiverId),
                                    },
                                    {
                                        receiverId: mongoose.Types.ObjectId(data.receiverId),
                                    },
                                ],
                            }
                        },
                        {
                            $lookup: {
                                from: "chats",
                                let: { userId: "$_id" },
                                pipeline: [
                                    { $match: { $expr: { $eq: ["$chatId", "$$userId"] }, isSeen: false, receiverId: mongoose.Types.ObjectId(data.receiverId) } },
                                ],
                                as: "msgsCount",
                            }
                        },
                        {
                            $addFields: {
                                unseenCount: { $size: "$msgsCount" }
                            }
                        },
                        {
                            $lookup: {
                                from: "chats",
                                localField: "lastmsgId",
                                foreignField: '_id',
                                as: "lastmsgId"
                            }
                        },
                        {
                            $unwind: "$lastmsgId"
                        },
                        {
                            $addFields: {
                                receiverId: {
                                    $cond: {
                                        if: {
                                            $eq: [mongoose.Types.ObjectId(data.receiverId), "$lastmsgId.receiverId"]
                                        },
                                        then: "$lastmsgId.senderId",
                                        else: "$lastmsgId.receiverId"
                                    },
                                }
                            }
                        },
                        {
                            $lookup: {
                                from: "user",
                                localField: "receiverId",
                                foreignField: '_id',
                                as: "receiverId"
                            }
                        },
                        {
                            $unwind: "$receiverId"
                        },

                        {
                            $project: {
                                _id: "$_id",
                                "receiverId": "$receiverId",
                                "senderId": "$senderId",
                                "type": "$type",
                                "isTyping": 1,
                                "unseenCount": 1,
                                newDate: 1,
                                "updatedAt": "$updatedAt",
                                "lastmsgId.receiverId._id": "$receiverId._id",
                                "lastmsgId.receiverId.message": "$lastmsgId.message",
                                "lastmsgId.receiverId.files": "$lastmsgId.files",
                                "lastmsgId.receiverId.thumbnail": "$lastmsgId.thumbnail",
                                "lastmsgId.receiverId.isOnline": "$receiverId.isOnline",
                                "lastmsgId.receiverId.userName": "$receiverId.userName",
                                "lastmsgId.receiverId.profileImg": "$receiverId.profileImg",
                                "lastmsgId.receiverId.email": "$receiverId.email",
                                "lastmsgId.receiverId.socketId": "$receiverId.socketId",
                            }
                        },
                        {
                            $project: {
                                "receiverId": 0,
                            }
                        },
                        {
                            $sort: { newDate: -1 },
                        },
                    ]);
                    socket.broadcast.to(otherUserDetails.socketId).emit("chatLists", chatList);
                    socket.broadcast.to(otherUserDetails.socketId).emit("chatHistory", chatDetails);
                    socket.emit("chatHistory", chatDetails);
                }
            } catch (err) {
                console.log("err seen", err)
            }
        });
    });
};
 const sendMessage = (data,socket)=>{
   
    CHATCONSTANTS.findOneAndUpdate(
        {
            // match with sender and receiver id with and, or case
            $or: [
                {
                    $and: [
                        {
                            senderId: data.senderId,
                        },
                        {
                            receiverId: data.receiverId,
                        },
                    ],
                },
                {
                    $and: [
                        {
                            senderId: data.receiverId,
                        },
                        {
                            receiverId: data.senderId,
                        },
                    ],
                },
            ],
        },
        {
            // upsert sender and receiver if record not exist
            senderId: data.senderId,
            receiverId: data.receiverId,
            type: data.type
        },
        {
            // take upsert and new true for record new detail and
            upsert: true,
            new: true,
        },
        async (err, result) => {
            if (err) throw err;
            // join room with room id
            socket.join(result._id);
            // for location save
            if (data.type === 2) {
                data.location = {
                    type: "Point",
                    coordinates: [data.longitude, data.latitude],
                };
            }
            data.chatId = result._id;

            // create chat with chatConstant id
            var userChat = new CHATS(data);
            userChat.save(async (err, results) => {
                if (err) throw err;
                let chatId = result._id;
                CHATCONSTANTS.findByIdAndUpdate(
                    result._id,
                    {
                        $set: {
                            lastmsgId: results._id,
                            updatedAt: Date.now(),
                            newDate: Date.now(),

                        }
                    },
                    (err, result) => {
                        if (err) throw err;
                    }
                );
                let otherUserDetails = await User.findOne({ _id: data.receiverId }).select("socketId");
                console.log("===========otherUserDetails===========>", otherUserDetails)
                let chatDetails = await CHATS.aggregate([
                    {
                        $match: {
                            chatId: mongoose.Types.ObjectId(result._id),
                        }
                    },
                    {
                        $lookup: {
                            from: "user",
                            localField: "senderId",
                            foreignField: '_id',
                            as: "senderId"
                        }
                    },
                    {
                        $unwind: "$senderId"
                    },
                    {
                        $lookup: {
                            from: "user",
                            localField: "receiverId",
                            foreignField: '_id',
                            as: "receiverId"
                        }
                    },
                    {
                        $unwind: "$receiverId"
                    },

                    {
                        $sort: { createdAt: -1 },
                    },
                    //  { $skip: pageSize * (pageNo - 1) },
                    // { $limit: pageSize },
                    {
                        $project: {
                            _id: "$_id",
                            "type": "$type",
                            "message": 1,
                            "isSeen": 1,
                            "chatId": 1,
                            //   files:1,
                            //   fileName:1,
                            //   thumbnail:1,
                            // // "createdAt":1,
                            "updatedAt": "$updatedAt",
                            "senderId._id": "$senderId._id",
                            "senderId.isOnline": "$senderId.isOnline",
                            "senderId.firstName": "$senderId.firstName",
                            "senderId.lastName": "$senderId.lastName",
                            "senderId.fullName": "$senderId.fullName",
                            "senderId.profilePic": "$senderId.profilePic",
                            "senderId.email": "$senderId.email",
                            "senderId.socketId": "$senderId.socketId",
                            "receiverId._id": "$receiverId._id",
                            "receiverId.isOnline": "$receiverId.isOnline",
                            "receiverId.firstName": "$receiverId.firstName",
                            "receiverId.lastName": "$receiverId.lastName",
                            "receiverId.fullName": "$receiverId.fullName",
                            "receiverId.profilePic": "$receiverId.profilePic",
                            "receiverId.email": "$receiverId.email",
                            "receiverId.socketId": "$receiverId.socketId",

                        }
                    }

                ]);
                const chatList = await CHATCONSTANTS.aggregate([
                    {
                        $match: {
                            $or: [
                                {
                                    senderId: mongoose.Types.ObjectId(data.receiverId),
                                },
                                {
                                    receiverId: mongoose.Types.ObjectId(data.receiverId),
                                },
                            ],
                        }
                    },
                    {
                        $lookup: {
                            from: "chats",
                            let: { userId: "$_id" },
                            pipeline: [
                                { $match: { $expr: { $eq: ["$chatId", "$$userId"] }, isSeen: false, receiverId: mongoose.Types.ObjectId(data.receiverId) } },
                            ],
                            as: "msgsCount",
                        }
                    },
                    {
                        $addFields: {
                            unseenCount: { $size: "$msgsCount" }
                        }
                    },
                    {
                        $lookup: {
                            from: "chats",
                            localField: "lastmsgId",
                            foreignField: '_id',
                            as: "lastmsgId"
                        }
                    },
                    {
                        $unwind: "$lastmsgId"
                    },
                    {
                        $addFields: {
                            receiverId: {
                                $cond: {
                                    if: {
                                        $eq: [mongoose.Types.ObjectId(data.receiverId), "$lastmsgId.receiverId"]
                                    },
                                    then: "$lastmsgId.senderId",
                                    else: "$lastmsgId.receiverId"
                                },
                            }
                        }
                    },
                    {
                        $lookup: {
                            from: "user",
                            localField: "receiverId",
                            foreignField: '_id',
                            as: "receiverId"
                        }
                    },
                    {
                        $unwind: "$receiverId"
                    },

                    {
                        $project: {
                            _id: "$_id",
                            "receiverId": "$receiverId",
                            "senderId": "$senderId",
                            "type": "$type",
                            //   "isTyping":1,
                            "unseenCount": 1,
                            newDate: 1,
                            "updatedAt": "$updatedAt",
                            "lastmsgId.receiverId._id": "$receiverId._id",
                            "lastmsgId.receiverId.message": "$lastmsgId.message",
                            "lastmsgId.receiverId.isOnline": "$receiverId.isOnline",
                            //   "lastmsgId.receiverId.files":"$lastmsgId.files",
                            //   "lastmsgId.receiverId.thumbnail":"$lastmsgId.thumbnail",
                            //   "lastmsgId.receiverId.userName":"$receiverId.userName",
                            "lastmsgId.receiverId.firstName": "$receiverId.firstName",
                            "lastmsgId.receiverId.lastName": "$receiverId.lastName",
                            "lastmsgId.receiverId.fullName": "$receiverId.fullName",
                            "lastmsgId.receiverId.profilePic": "$receiverId.profilePic",
                            "lastmsgId.receiverId.email": "$receiverId.email",
                            "lastmsgId.receiverId.socketId": "$receiverId.socketId",
                        }
                    },
                    {
                        $project: {
                            "receiverId": 0,
                        }
                    },
                    {
                        $sort: { newDate: -1 },
                    },
                ]);
                console.log("=============OtherUserDetails", otherUserDetails)
                socket.broadcast.to(otherUserDetails.socketId).emit("chatLists", chatList);
                // broadcast into room
                socket.broadcast.to(otherUserDetails.socketId).emit("msgReceived", chatDetails);
                // receives to user own that msg is sent
                socket.emit("msgReceived", chatDetails);

            });
        }
    );
}