const user = require('../../model/user')
const subscriptionModel = require('../../model/subscription')
const laboratoryModel = require('../../model/laboratory')
const packageModel = require('../../model/package')
const booking = require('../../model/laboratoryBooking')

const specialtyModel = require('../../model/specialties')
const primarySpecialtyModel = require('../../model/primarySpecialties')
const transaction = require('../../model/transaction')
const walletModel = require('../../model/wallet')
const ratingModel = require('../../model/rating')
const invoiceModel = require('../../model/invoiceModel')
const commonFunction = require('../../utility/common')


const { commonResponse: response } = require('../../helper/commonResponseHandler');
const { ErrorMessage } = require('../../helper/message');
const { SuccessMessage } = require('../../helper/message');

const mongoose = require('mongoose')

const { findOne, findOneAndUpdate } = require('../../model/user')
const stripe = require("stripe")("sk_test_51HpT2LCqtD4cxQPsXTUC40N2Eloiyw91WdjH09qYPUpxmTt2hiXq0vqI13gNWpJ8lqzbsAgR6XHECWE07shIUWG900UDpAxVn3");





module.exports = {

    nearByLaboratory: async (req, res) => {
        let userId = req.userId
        let data = await user.findOne({ _id: userId })
        let criteria = { status: "ACTIVE" }
        try {
            var aggregate = laboratoryModel.aggregate([{
                "$geoNear": {
                    "near": {
                        type: "Point",
                        coordinates: [parseFloat(req.body.lat), parseFloat(req.body.long)]
                    },
                    "maxDistance": 30 * 1000,
                    "distanceField": "dist.calculated",
                    "includeLocs": "dist.location",
                    "spherical": true
                }
            },
            { $match: criteria },
            {
                $project: {
                    _id: 1,
                    name: 1,
                    image: 1,
                    serviceType: 1,
                    availability: 1
                }
            }
            ])
            var options = {
                page: req.body.pageNumber || 1,
                limit: req.body.limit || 20
            }
            laboratoryModel.aggregatePaginate(aggregate, options, (err, labData, pageCount, count) => {
                if (err) {
                    console.log("=========userErr", err)
                    return res.status(500).send({ responseMessage: ErrorMessage.INTERNAL_ERROR, err })
                }
                else {
                    return res.status(200).send({ responseMessage: "Data found successfully", labData, pageCount, count })

                }
            })

        }
        catch (error) {
            console.log("catch", error)
            return res.status(501).send({ responseMessage: ErrorMessage.SOMETHING_WRONG, error })
        }
    },



    viewLaboratory: async (req, res) => {
        let query = { _id: req.params.id }
        let laboratoryDetails = await laboratoryModel.findOne(query)
        if (!laboratoryDetails)
            return res.status(404).send({ responseMessage: ErrorMessage.NOT_FOUND })
        else {
            // return res.status(200).send({ responseMessage: SuccessMessage.DATA_FOUND, data })
            let packageList;
            let criteria = { laboratoryId: req.params.id, status: "ACTIVE" }
            packageList = await packageModel.find(criteria).sort({ createdAt: -1 })
            return res.status(200).send({ responseMessage: SuccessMessage.DATA_FOUND, laboratoryDetails, packageList, packageList })
        }
    },


    getSlot: async (req, res) => {
        try {
            userId = req.userId
            let laboratoryId = req.query.laboratoryId
            let availableSlots;
            let selectedDate = req.query.bookingDate
            let day = new Date(req.query.bookingDate).toDateString().split(' ')[0]
            let date = new Date(selectedDate)
            let laboratoryData = await laboratoryModel.findOne({ _id: laboratoryId }, { 'availability': 1 }).lean();
            if (!laboratoryData) return res.status(404).send({ responseMessage: "Lab not found" })
            let slotData = laboratoryData.availability.find(e => e.day == day);
            if (!slotData) {
                return res.status(404).send({ responseMessage: "Not available on this day" })
            }
            availableSlots = slotData.slots
            let query = { laboratoryId: laboratoryId, bookingDate: date, status: 'accepted' }
            booking.find(query, (bookingErr, bookingData) => {
                if (bookingErr) return res.status(500).send({ responseMessage: ErrorMessage.INTERNAL_ERROR })
                let bookedSlots = bookingData.map((e) => e.slotId.toString())
                let slots = availableSlots.map((item) => {
                    if (!bookedSlots.includes(item._id.toString())) {
                        return item;
                    }
                }).filter(e => e)
                delete slotData.slots
                slotData['slots'] = slots
                if (slotData.slots.length == 0) {
                    return res.status(404).send({ responseMessage: "Slot not available" })

                }
                return res.status(200).send({ responseMessage: "ok", slotData })

            })
        } catch (e) {
            console.log("=======catch", e)
            return res.status(501).send({ responseMessage: ErrorMessage.SOMETHING_WRONG, e })
        }
    },


    bookLaboratory_appointment: async (req, res) => {
        try {
            let userId = req.userId
            let userData = await user.findOne({ _id: userId })
            if (!userData) return res.status(404).send({ responseMessage: ErrorMessage.NOT_FOUND })
            let laboratoryData = await laboratoryModel.findOne({ _id: req.body.laboratoryId })
            if (!laboratoryData) return res.status(404).send({ responseMessage: "Lab not found" })
            let date = new Date(req.body.appointmentStartTime)
            let criteria = { laboratoryId: req.body.laboratoryId, appointmentStartTime: date, status: "accepted" }
            let slotExistData = await booking.find(criteria)
            if (slotExistData.length != 0) return res.status(409).send({ responseMessage: "This slot is already booked by someone! please choose another slot." })
            stripe.tokens.create({
                card: {
                    number: req.body.cardNumber,
                    exp_month: req.body.exp_month,
                    exp_year: req.body.exp_year,
                    cvc: req.body.cvc,
                    currency: 'USD'
                }
            }, (tokenErr, token) => {
                if (tokenErr)
                    if (tokenErr) return res.status(500).send({ responseMessage: tokenErr.raw.message })
                stripe.customers.create({
                    email: userData.email,
                    source: token.id,
                }, (customerErr, customer) => {
                    if (customerErr) return res.status(500).send({ responseMessage: ErrorMessage.INTERNAL_ERROR, customerErr })
                    stripe.charges.create({
                        amount: req.body.price * 100,
                        currency: "USD",
                        customer: customer.id
                    }, (chargeErr, charge) => {
                        if (chargeErr) return res.status(500).send({ responseMessage: ErrorMessage.INTERNAL_ERROR, chargeErr })
                        var paymentObj = {
                            transactionId: charge.balance_transaction,
                            chargeId: charge.id,
                            currency: charge.currency,
                            amount: req.body.price,
                            customerId: charge.customer,
                            url: charge.receipt_url,
                            email: customer.email,
                            transactionStatus: charge.status,
                            userId: userId,
                            paymentType: req.body.cardType
                        }
                        var paymentData = new transaction(paymentObj)
                        paymentData.save(async (paymentSaveErr, paymentSaveData) => {
                            console.log("==========paymentSaveErr", paymentSaveErr)
                            if (paymentSaveErr) return res.status(500).send({ responseMessage: ErrorMessage.INTERNAL_ERROR, paymentSaveErr })
                            req.body.serviceProviderId = req.body.serviceProviderId
                            req.body.patientId = userId
                            req.body.paymentStatus = 'paid'
                            req.body.amount = req.body.price
                            req.body.appointmentStartTime = req.body.appointmentStartTime
                            req.body.appointmentEndTime = req.body.appointmentEndTime
                            req.body.bookingDate = new Date(req.body.bookingDate)
                            req.body.location = { type: "Point", coordinates: [parseFloat(req.body.long), parseFloat(req.body.lat)], address: req.body.address }
                            let data = new booking(req.body);
                            let bookingData = data.save()
                            if (bookingData) {
                                let prefix = '#'
                                let documentNumber = await invoiceModel.find({}).countDocuments()
                                console.log("=========documentNumber1",documentNumber)

                                var  numberCount;
                                if(documentNumber === 0){
                                    numberCount = 1
                                }else{
                                    numberCount = documentNumber
                                }
                                let invoiceNumber = prefix + numberCount
                                let invoiceObj = {
                                    paymentType:req.body.cardType,
                                    cardNumber: req.body.cardNumber,
                                    patientId: userId,
                                    invoiceNumber : invoiceNumber,
                                    laboratoryId: req.body.laboratoryId,
                                    amount: req.body.price,
                                    invoiceType :"LABORATORY"
                                }                       
                                let invoiceData = new invoiceModel(invoiceObj);
                                invoiceData.save()
                                return res.status(200).send({ responseMessage: SuccessMessage.BOOKING_SUCCESS })
                            }

                        })

                    })

                })
            })

        }
        catch (e) {
            console.log(e)
            return res.status(501).send({ responseMessage: ErrorMessage.SOMETHING_WRONG, e })
        }
    },


    upcomingLaboratory_appointments: async (req, res) => {
        try {
            userId = req.userId
            let totalList = 0;
            let pageNumber = +req.query.pageNumber || 1
            let limit = +req.query.limit || 100000
            let currentDate = new Date()
            let query = { patientId: userId, status: { $in: ["accepted", "cancelled"] }, appointmentEndTime: { $gt: currentDate } }
            totalList = await booking.find(query).countDocuments();
            let appointmentData = await booking.find(query, { appointmentStartTime: 1, appointmentEndTime: 1, amount: 1, status: 1 }).sort({ appointmentStartTime: 1 })
                .populate('laboratoryId packageId', 'name image description city state location')
                .skip((limit * pageNumber) - limit).limit(limit).lean();
            if (!appointmentData) {
                return res.status(404).send({ responseCode: 404, responseMessage: ErrorMessage.NOT_FOUND })
            } else {
                return res.status(200).send({ responseCode: 200, responseMessage: SuccessMessage.DATA_FOUND, appointmentData, totalList })

            }
        } catch (e) {
            return res.status(501).send({ responseCode: 501, responseMessage: ErrorMessage.SOMETHING_WRONG, e })
        }
    },

    previousLaboratory_appointments: async (req, res) => {
        try {
            userId = req.userId
            let totalList = 0;
            let pageNumber = +req.query.pageNumber || 1
            let limit = +req.query.limit || 100000
            let currentDate = new Date()
            let query = { patientId: userId, status: { $in: ["accepted", "cancelled"] }, appointmentEndTime: { $lt: currentDate } }
            totalList = await booking.find(query).countDocuments();
            let appointmentData = await booking.find(query, { appointmentStartTime: 1, appointmentEndTime: 1, amount: 1, status: 1 }).sort({ appointmentStartTime: 1 })
                .populate('laboratoryId packageId', 'name image description city state location')
                .skip((limit * pageNumber) - limit).limit(limit).lean();
            if (!appointmentData) {
                return res.status(404).send({ responseCode: 404, responseMessage: ErrorMessage.NOT_FOUND })
            } else {
                return res.status(200).send({ responseCode: 200, responseMessage: SuccessMessage.DATA_FOUND, appointmentData, totalList })

            }
        } catch (e) {
            return res.status(501).send({ responseCode: 501, responseMessage: ErrorMessage.SOMETHING_WRONG, e })
        }
    },

    viewLaboratory_appointment: async (req, res) => {
        try {
            let userData = await user.findOne({ _id: req.userId })
            let query = { _id: req.params.id }
            booking.findOne(query, { appointmentStartTime: 1, appointmentEndTime: 1, reason: 1, document: 1, amount: 1, status: 1 })
                .populate('laboratoryId packageId', 'name image description city state location')
                .lean().exec((appointmentErr, appointmentDetails) => {
                    if (appointmentErr)
                        return res.status(500).send({ responseCode: 500, responseMessage: ErrorMessage.INTERNAL_ERROR, appointmentErr })
                    else if (!appointmentDetails) {
                        return res.status(404).send({ responseCode: 404, responseMessage: ErrorMessage.NOT_FOUND })
                    } else {
                        return res.status(200).send({ responseCode: 200, responseMessage: SuccessMessage.DATA_FOUND, appointmentDetails })

                    }
                })
        } catch (e) {
            return res.status(501).send({ responseMessage: ErrorMessage.SOMETHING_WRONG, e })
        }
    },

    cancelLaboratory_appointment: async (req, res) => {
        try {
            let userId = req.userId
            let walletData = await walletModel.findOne({ userId: userId, status: "ACTIVE" })
            let userData = await user.findOne({ _id: userId })
            let query = { _id: req.body.appointmentId }
            let appointmentDetails = await booking.findOne(query).lean()
            if (!appointmentDetails) {
                return res.status(404).send({ responseCode: 404, responseMessage: ErrorMessage.NOT_FOUND })
            } else {
                let currentTime = new Date().getTime()
                let appointmentDate = appointmentDetails.appointmentStartTime
                let appointmentTime = appointmentDate.getTime()
                if (appointmentTime - currentTime >= 3600000) {
                    let updatedAppointmentStatus = await booking.findOneAndUpdate({ _id: req.body.appointmentId }, { $set: { status: 'cancelled' } }, { new: true })
                    if (updatedAppointmentStatus) {
                        const price = appointmentDetails.amount
                        await walletModel.findByIdAndUpdate({ _id: walletData._id}, { $set: { totalBalance: walletData.totalBalance + price } }, { new: true })
                        return res.status(200).send({ responseMessage: "Cancel" })
                    }
                } else {
                    return res.status(200).send({ responseMessage: "Can't cancel now" })
                }
            }
        } catch (e) {
            console.log(e)
            return res.status(501).send({ responseCode: 501, responseMessage: ErrorMessage.SOMETHING_WRONG, e })
        }
    },


    rescheduleLaboratory_appointment: async (req, res) => {
        try {
            let userId = req.userId
            let query = { _id: req.body.appointmentId }
            let appointmentDetails = await booking.findOne(query).lean()
            if (!appointmentDetails) {
                return res.status(404).send({ responseCode: 404, responseMessage: ErrorMessage.NOT_FOUND })
            } else {
                let currentTime = new Date().getTime()
                let appointmentDate = appointmentDetails.appointmentStartTime
                let appointmentTime = appointmentDate.getTime()
                console.log("=========appointmentTime", appointmentTime)
                console.log("=================currentTime", currentTime)
                if (appointmentTime - currentTime >= 3600000) {
                    console.log("difference", appointmentTime - currentTime)
                    let updatedAppointmentStatus = await booking.findOneAndUpdate({ _id: req.body.appointmentId }, { $set: { status: 'rescheduled' } }, { new: true })

                    req.body.laboratoryId = appointmentDetails.laboratoryId
                    req.body.patientId = appointmentDetails.patientId
                    req.body.paymentStatus = 'paid'
                    req.body.status = "accepted"
                    req.body.amount = appointmentDetails.amount
                    req.body.appointmentStartTime = req.body.appointmentStartTime
                    req.body.appointmentEndTime = req.body.appointmentEndTime
                    req.body.bookingDate = new Date(req.body.bookingDate)
                    req.body.location = { type: "Point", coordinates: [parseFloat(req.body.lat), parseFloat(req.body.long)], address: req.body.address }
                    let data = new booking(req.body);
                    let bookingData = data.save()
                    if (bookingData) { 
                        return res.status(200).send({ responseMessage: SuccessMessage.BOOKING_SUCCESS })
                    }
                } else {
                    return res.status(200).send({ responseMessage: "Can't reschedule now" })
                }
            }
        } catch (e) {
            console.log(e)
            return res.status(501).send({ responseCode: 501, responseMessage: ErrorMessage.SOMETHING_WRONG, e })
        }
    },


}