const appointmentModel = require('../../model/laboratoryBooking')



const { commonResponse: response } = require('../../helper/commonResponseHandler');
const { ErrorMessage } = require('../../helper/message');
const { SuccessMessage } = require('../../helper/message');

const mongoose = require('mongoose')

const { findOne, findOneAndUpdate } = require('../../model/user')




module.exports = {

    reportList: async (req, res) => {
        try {
            userId = req.userId
            let totalList = 0;
            let pageNumber = +req.query.pageNumber || 1
            let limit = +req.query.limit || 100000
            let query = { patientId: userId, status: "accepted",reportFile: { $exists: true } }
            totalList = await appointmentModel.find(query).countDocuments();
            let reportData = await appointmentModel.find(query,{name:1,amount:1,reportFile:1,reportDateTime:1,deliveryStatus:1,reportStatus:1 }).populate('patientId','firstName lastName profilePic')
            .populate('packageId','name')
            .sort({ createdAt: -1 })
                .skip((limit * pageNumber) - limit).limit(limit).lean();
            if (!reportData) {
                return res.status(404).send({ responseCode: 404, responseMessage: ErrorMessage.NOT_FOUND })
            } else {
                return res.status(200).send({ responseCode: 200, responseMessage: SuccessMessage.DATA_FOUND, reportData, totalList })
            }
        } catch (e) {
            return res.status(501).send({ responseCode: 501, responseMessage: ErrorMessage.SOMETHING_WRONG, e })
        }
    },

}