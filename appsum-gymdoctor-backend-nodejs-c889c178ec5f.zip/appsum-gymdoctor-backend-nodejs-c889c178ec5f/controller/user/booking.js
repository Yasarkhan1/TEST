const user = require('../../model/user')
const subscriptionModel = require('../../model/subscription')
const laboratoryModel = require('../../model/laboratory')
const specialtyModel = require('../../model/specialties')
const primarySpecialtyModel = require('../../model/primarySpecialties')
const transaction = require('../../model/transaction')
const walletModel = require('../../model/wallet')
const ratingModel = require('../../model/rating')
const booking = require('../../model/appointment')
const notification = require('../../model/notification')
const cardModel = require('../../model/card')
const invoiceModel = require('../../model/invoiceModel')
const commonFunction = require('../../utility/common')
const schedule = require('node-schedule');



const { commonResponse: response } = require('../../helper/commonResponseHandler');
const { ErrorMessage } = require('../../helper/message');
const { SuccessMessage } = require('../../helper/message');

const mongoose = require('mongoose')

const { findOne, findOneAndUpdate } = require('../../model/user')
const stripe = require("stripe")("sk_test_51HpT2LCqtD4cxQPsXTUC40N2Eloiyw91WdjH09qYPUpxmTt2hiXq0vqI13gNWpJ8lqzbsAgR6XHECWE07shIUWG900UDpAxVn3");





module.exports = {



    getSlot: async (req, res) => {
        try {
            userId = req.userId
            let serviceProviderId = req.query.serviceProviderId
            let availableSlots;
            let selectedDate = req.query.bookingDate
            // console.log(">>>>>>>selectDte", selectedDate)
            let day = new Date(req.query.bookingDate).toDateString().split(' ')[0]
            // console.log(">>>>>>>>>day", day)
            let date = new Date(selectedDate)
            // console.log(">>>>>>>>>>>>>>>date", date)
            let serviceProviderData = await user.findOne({ _id: serviceProviderId }, { 'availability': 1 }).lean();
            if (!serviceProviderData) return res.status(404).send({ responseMessage: "Service Provider not found" })
            let slotData = serviceProviderData.availability.find(e => e.day == day);
            if (!slotData) {
                return res.status(404).send({ responseMessage: "Not available on this day" })
            }
            availableSlots = slotData.slots
            let query = { serviceProviderId: serviceProviderId, bookingDate: date, status: 'accepted' }
            booking.find(query, (bookingErr, bookingData) => {
                if (bookingErr) return res.status(500).send({ responseMessage: ErrorMessage.INTERNAL_ERROR })
                let bookedSlots = bookingData.map((e) => e.slotId.toString())
                let slots = availableSlots.map((item) => {
                    if (!bookedSlots.includes(item._id.toString())) {
                        return item;
                    }
                }).filter(e => e)
                delete slotData.slots
                slotData['slots'] = slots
                if (slotData.slots.length == 0) {
                    return res.status(404).send({ responseMessage: "Slot not available" })

                }
                return res.status(200).send({ responseMessage: "ok", slotData })

            })
        } catch (e) {
            console.log("=======catch", e)
            return res.status(501).send({ responseMessage: ErrorMessage.SOMETHING_WRONG, e })
        }
    },

    bookAppointment: async (req, res) => {
        try {
            let userId = req.userId
            let userData = await user.findOne({ _id: userId })
            if (!userData) return res.status(404).send({ responseMessage: ErrorMessage.NOT_FOUND })
            if (userData.isSubscribe == false) {
                return res.status(403).send({ responseMessage: "You are not subscribed user" })
            }
            let serviceProviderData = await user.findOne({ _id: req.body.serviceProviderId })
            if (!serviceProviderData) return res.status(404).send({ responseMessage: "Service Provider not found" })
            let userWalletData = await walletModel.findOne({ userId: userId })
            let serviceProviderWalletData = await walletModel.findOne({ userId: req.body.serviceProviderId })
            console.log("==========serviceProviderWalletData", serviceProviderWalletData)
            let currentTime = Date.now()
            if (userWalletData.expiryDate > currentTime) {
                if (userWalletData.sessions > 0) {
                    let date = new Date(req.body.appointmentStartTime)
                    let criteria = { serviceProviderId: req.body.serviceProviderId, appointmentStartTime: date, status: "accepted" }
                    let slotExistData = await booking.find(criteria)
                    if (slotExistData.length != 0) return res.status(409).send({ responseMessage: "This slot is already booked by someone! please choose another slot." })
                    req.body.serviceProviderId = req.body.serviceProviderId
                    req.body.patientId = userId
                    req.body.paymentStatus = 'paid'
                    req.body.amount = serviceProviderData.serviceCharge
                    req.body.appointmentStartTime = req.body.appointmentStartTime
                    req.body.appointmentEndTime = req.body.appointmentEndTime
                    req.body.bookingDate = new Date(req.body.bookingDate)
                    let data = new booking(req.body);
                    let bookingData = await  data.save()
                    if (bookingData) {
                        let balance = serviceProviderWalletData.totalBalance + req.body.amount
                        console.log("=============balance", balance)
                        await walletModel.findOneAndUpdate({ userId: serviceProviderData._id }, { $set: { totalBalance: balance } }, { new: true })
                        await walletModel.findOneAndUpdate({ userId: userId }, { $set: { sessions: userWalletData.sessions - 1 } }, { new: true })
                        let clientName = userData.firstName + ' ' + userData.lastName

                        // notify to own self
                        const pushTitle1 = "Booking Confirmed"
                        const pushBody1 = "Congratulations, your appointment is confirmed"
                        commonFunction.pushNotification(userData.deviceToken, pushTitle1, pushBody1)

                        let notifyToOwn = {
                            userId: userId,
                            title: "Booking Confirmed",
                            body: "Congratulations, your appointment is confirmed",
                            notificationType: 'BOOKING',
                            appointmentId: bookingData._id
                        }
                        let patientNotifyData = new notification(notifyToOwn)
                        patientNotifyData.save()

                        // Notify to doctor
                        const pushTitle = "New Booking"
                        const pushBody = `${clientName} has booked an appointment with  you.Please check your schedule`
                        commonFunction.pushNotification(serviceProviderData.deviceToken, pushTitle, pushBody)
                        let notify = {
                            userId: req.body.serviceProviderId,
                            title: "New Booking",
                            body: `${clientName} has booked an appointment with  you.Please check your schedule`,
                            notificationType: 'BOOKING',
                            appointmentId: bookingData._id
                        }
                        let notiData = new notification(notify)
                        notiData.save(async (notiErr, notiSaveData) => {
                            if (notiErr) return res.status(500).send({ responseMessage: ErrorMessage.INTERNAL_ERROR, notiErr })

                            // Invoice generation
                            let prefix = '#'
                            let documentNumber = await invoiceModel.find({}).countDocuments()
                            console.log("=========documentNumber1", documentNumber)
                            var numberCount;
                            if (documentNumber === 0) {
                                numberCount = 1
                            } else {
                                numberCount = documentNumber
                            }
                            console.log("======numberCount", numberCount)
                            let invoiceNumber = prefix + numberCount
                            let invoiceObj = {
                                paymentType: "SUBSCRIPTION",
                                patientId: userId,
                                invoiceNumber: invoiceNumber,
                                serviceProviderId: req.body.serviceProviderId,
                                amount: serviceProviderData.serviceCharge,
                                invoiceFrom: userId
                            }
                            let invoiceData = new invoiceModel(invoiceObj);
                            invoiceData.save()

                            // Setup cron jobs
                            let appointmentId =bookingData._id
                            let appointmentTime = req.body.appointmentStartTime
                            let year = new Date(appointmentTime).getFullYear()
                            let month = new Date(appointmentTime).getMonth()
                            let day = new Date(appointmentTime).getDate()
                            let hours = new Date(appointmentTime).getHours()
                            let minutes = new Date(appointmentTime).getMinutes()
                            var date1 = new Date(year, month, day, hours, minutes - 15, 0);
                            let title = "Reminder"
                            let body = `You have an appointment in the next 15 minutes with ${serviceProviderData.fullName}.`
                            var j = schedule.scheduleJob(JSON.stringify(appointmentId), date1, function () {
                                console.log('The world is going to end today.');
                                commonFunction.pushNotification(userData.deviceToken, title, body)
                            });
                            console.log(">>>>>>>>>>jonId", j)
                            return res.status(200).send({ responseMessage: SuccessMessage.BOOKING_SUCCESS })

                        })
                    }
                } else {
                    return res.status(402).send({ responseMessage: "Please upgrade your subscription now." })
                }
            } else {
                return res.status(402).send({ responseMessage: "Please upgrade your subscription now." })
            }
        }
        catch (e) {
            console.log(e)
            return res.status(501).send({ responseMessage: ErrorMessage.SOMETHING_WRONG, e })
        }
    },

    upcomingAppointments: async (req, res) => {
        try {
            userId = req.userId
            let totalList = 0;
            let pageNumber = +req.query.pageNumber || 1
            let limit = +req.query.limit || 100000
            let currentDate = new Date()
            let query = { patientId: userId, status: { $in: ["accepted", "cancelled"] }, appointmentEndTime: { $gt: currentDate } }
            totalList = await booking.find(query).countDocuments();
            let appointmentData = await booking.find(query, { appointmentStartTime: 1, appointmentEndTime: 1, amount: 1, status: 1 }).sort({ appointmentStartTime: 1 }).populate({
                path: 'serviceProviderId',
                model: 'user',
                select: 'fullName experience_in_years experience_in_months primary_specialty profilePic rating',
                // populate: {
                //     path: 'secondry_specialty',
                //     model: 'specialty',
                //     select: 'secondry_specialty'
                // }
                populate: [{
                    path: 'secondry_specialty',
                    model: 'specialty',
                    select: 'secondry_specialty'
                },
                {
                    path: 'primary_specialtyId',
                    model: 'primary_specialty',
                    select: 'primary_specialty',

                }]
            })
                .skip((limit * pageNumber) - limit).limit(limit).lean();
            if (!appointmentData) {
                return res.status(404).send({ responseCode: 404, responseMessage: ErrorMessage.NOT_FOUND })
            } else {
                return res.status(200).send({ responseCode: 200, responseMessage: SuccessMessage.DATA_FOUND, appointmentData, totalList })

            }
        } catch (e) {
            return res.status(501).send({ responseCode: 501, responseMessage: ErrorMessage.SOMETHING_WRONG, e })
        }
    },

    previousAppointments: async (req, res) => {
        try {
            userId = req.userId
            let totalList = 0;
            let pageNumber = +req.query.pageNumber || 1
            let limit = +req.query.limit || 100000
            let currentDate = new Date()
            let query = { patientId: userId, status: { $in: ["accepted", "cancelled"] }, appointmentEndTime: { $lt: currentDate } }
            totalList = await booking.find(query).countDocuments();
            let appointmentData = await booking.find(query, { appointmentStartTime: 1, appointmentEndTime: 1, amount: 1, status: 1 }).sort({ appointmentStartTime: 1 }).populate({
                path: 'serviceProviderId',
                model: 'user',
                select: 'fullName experience_in_years experience_in_months primary_specialty profilePic rating',
                // populate: {
                //     path: 'secondry_specialty',
                //     model: 'specialty',
                //     select: 'secondry_specialty'
                // }
                populate: [{
                    path: 'secondry_specialty',
                    model: 'specialty',
                    select: 'secondry_specialty'
                },
                {
                    path: 'primary_specialtyId',
                    model: 'primary_specialty',
                    select: 'primary_specialty',

                }]
            })
                .skip((limit * pageNumber) - limit).limit(limit).lean();
            if (!appointmentData) {
                return res.status(404).send({ responseCode: 404, responseMessage: ErrorMessage.NOT_FOUND })
            } else {
                return res.status(200).send({ responseCode: 200, responseMessage: SuccessMessage.DATA_FOUND, appointmentData, totalList })

            }
        } catch (e) {
            return res.status(501).send({ responseCode: 501, responseMessage: ErrorMessage.SOMETHING_WRONG, e })
        }
    },

    viewAppointment: async (req, res) => {
        try {
            let userData = await user.findOne({ _id: req.userId })
            console.log("=========userData", userData)
            let query = { _id: req.params.id }
            booking.findOne(query, { appointmentStartTime: 1, appointmentEndTime: 1, reason: 1, document: 1, amount: 1, status: 1 }).populate({
                path: 'serviceProviderId',
                model: 'user',
                select: 'fullName experience_in_years experience_in_months primary_specialty profilePic rating',
                populate: {
                    path: 'secondry_specialty',
                    model: 'specialty',
                    select: 'secondry_specialty'
                }
            }).lean().exec((appointmentErr, appointmentDetails) => {
                if (appointmentErr) return res.status(500).send({ responseCode: 500, responseMessage: ErrorMessage.INTERNAL_ERROR, appointmentErr })
                else if (!appointmentDetails) {
                    return res.status(404).send({ responseCode: 404, responseMessage: ErrorMessage.NOT_FOUND })
                } else {
                    let doctorId = appointmentDetails.serviceProviderId._id
                    console.log("========doctorId", doctorId)
                    var isFavourite;
                    var isRatingGiven;
                    if (userData.favourites.includes(doctorId)) {
                        isFavourite = true;
                    }
                    else {
                        isFavourite = false
                    }
                    if (userData.ratingArray.includes(doctorId)) {
                        isRatingGiven = true;
                    }
                    else {
                        isRatingGiven = false
                    }
                    appointmentDetails.isFavourite = isFavourite;
                    appointmentDetails.isRatingGiven = isRatingGiven;


                    return res.status(200).send({ responseCode: 200, responseMessage: SuccessMessage.DATA_FOUND, appointmentDetails })

                }
            })
        } catch (e) {
            return res.status(501).send({ responseMessage: ErrorMessage.SOMETHING_WRONG, e })
        }
    },


    rescheduleRequestList: async (req, res) => {
        try {
            userId = req.userId
            let totalList = 0;
            let pageNumber = +req.query.pageNumber || 1
            let limit = +req.query.limit || 100000
            let currentDate = new Date()
            let query = { patientId: userId, status: "pending", appointmentStartTime: { $gt: currentDate } }
            totalList = await booking.find(query).countDocuments();
            let appointmentData = await booking.find(query, { appointmentStartTime: 1, appointmentEndTime: 1, amount: 1, status: 1 }).sort({ appointmentStartTime: 1 }).populate('oldAppointmentId', 'appointmentStartTime appointmentEndTime').populate({
                path: 'serviceProviderId',
                model: 'user',
                select: 'fullName experience_in_years experience_in_months primary_specialtyId profilePic rating serviceCharge',
                populate: [{
                    path: 'secondry_specialty',
                    model: 'specialty',
                    select: 'secondry_specialty'
                },
                {
                    path: 'primary_specialtyId',
                    model: 'primary_specialty',
                    select: 'primary_specialty',

                }]
            })
                .skip((limit * pageNumber) - limit).limit(limit).lean();
            if (!appointmentData) {
                return res.status(404).send({ responseCode: 404, responseMessage: ErrorMessage.NOT_FOUND })
            } else {
                return res.status(200).send({ responseCode: 200, responseMessage: SuccessMessage.DATA_FOUND, appointmentData, totalList })

            }
        } catch (e) {
            return res.status(501).send({ responseCode: 501, responseMessage: ErrorMessage.SOMETHING_WRONG, e })
        }
    },

    acceptRescheduleRequest: async (req, res) => {
        try {
            let userId = req.userId
            let userData = await user.findOne({ _id: userId })
            let query = { _id: req.body.appointmentId }
            let appointmentDetails = await booking.findOne(query).lean()
            if (!appointmentDetails) {
                return res.status(404).send({ responseCode: 404, responseMessage: ErrorMessage.NOT_FOUND })
            } else {
                let serviceProviderData = await user.findOne({ _id: appointmentDetails.serviceProviderId })
                let updatedAppointmentStatus = await booking.findOneAndUpdate({ _id: req.body.appointmentId }, { $set: { status: 'accepted' } }, { new: true })
                let patientName = userData.firstName + ' ' + userData.lastName
                const pushTitle = "Reschedule Time Acceptance"
                const pushBody = `${patientName} has accepted your  new purposed appointment time.`
                commonFunction.pushNotification(serviceProviderData.deviceToken, pushTitle, pushBody)
                let notify = {
                    userId: serviceProviderData._id,
                    title: "Reschedule Time Acceptance",
                    body: `${patientName} has accepted your new purposed appointment time.`,
                    notificationType: 'ACCEPTED',
                    appointmentId: appointmentDetails._id
                }
                let notiData = new notification(notify)
                notiData.save((notiErr, notiSaveData) => {
                    if (notiErr) return res.status(500).send({ responseMessage: ErrorMessage.INTERNAL_ERROR, notiErr })
                    return res.status(200).send({ responseMessage: "Accepted" })

                })
            }
        } catch (e) {
            console.log(e)
            return res.status(501).send({ responseCode: 501, responseMessage: ErrorMessage.SOMETHING_WRONG, e })
        }
    },

    rejectRescheduleRequest: async (req, res) => {
        try {
            let userId = req.userId
            let userData = await user.findOne({ _id: userId })
            let query = { _id: req.body.appointmentId }
            let appointmentDetails = await booking.findOne(query).lean()
            if (!appointmentDetails) {
                return res.status(404).send({ responseCode: 404, responseMessage: ErrorMessage.NOT_FOUND })
            } else {
                let serviceProviderData = await user.findOne({ _id: appointmentDetails.serviceProviderId })
                let updatedAppointmentStatus = await booking.findOneAndUpdate({ _id: req.body.appointmentId }, { $set: { status: 'rejected' } }, { new: true })

                let serviceProviderWalletData = await walletModel.findOne({ userId: serviceProviderData._id })
                let balance = serviceProviderWalletData.totalBalance - appointmentDetails.amount
                await walletModel.findOneAndUpdate({ userId: serviceProviderData._id }, { $set: { totalBalance: balance } }, { new: true })
                if (appointmentDetails.appointmentType == "BANK_CARD") {
                    let userWalletData = await walletModel.findOne({ userId: userData._id })
                    let walletBalance = userWalletData.totalBalance + appointmentDetails.amount
                    await walletModel.findOneAndUpdate({ userId: userData._id }, { $set: { totalBalance: walletBalance } }, { new: true })
                }
                if (appointmentDetails.appointmentType == "SUBSCRIPTION") {
                    let userWalletData = await walletModel.findOne({ userId: userData._id })
                    let totalSession = userWalletData.sessions + 1
                    await walletModel.findOneAndUpdate({ userId: userData._id }, { $set: { sessions: totalSession } }, { new: true })
                }

                let patientName = userData.firstName + ' ' + userData.lastName
                const pushTitle = "Reschedule Time Rejected"
                const pushBody = `${patientName} has rejected your  new purposed appointment time.`
                commonFunction.pushNotification(serviceProviderData.deviceToken, pushTitle, pushBody)
                let notify = {
                    userId: serviceProviderData._id,
                    title: "Reschedule Time Rejected",
                    body: `${patientName} has rejected your new purposed appointment time.`,
                    notificationType: 'REJECTED',
                    appointmentId: appointmentDetails._id
                }
                let notiData = new notification(notify)
                notiData.save((notiErr, notiSaveData) => {
                    if (notiErr) return res.status(500).send({ responseMessage: ErrorMessage.INTERNAL_ERROR, notiErr })
                    return res.status(200).send({ responseMessage: "Accepted" })

                })
            }
        } catch (e) {
            console.log(e)
            return res.status(501).send({ responseCode: 501, responseMessage: ErrorMessage.SOMETHING_WRONG, e })
        }
    },

    cancelAppointment: async (req, res) => {
        try {
            let userId = req.userId
            let userData = await user.findOne({ _id: userId })
            let query = { _id: req.body.appointmentId }
            let appointmentDetails = await booking.findOne(query).lean()
            if (!appointmentDetails) {
                return res.status(404).send({ responseCode: 404, responseMessage: ErrorMessage.NOT_FOUND })
            } else {
                console.log("=============AppointmentDetails", appointmentDetails)
                let doctorData = await user.findOne({ _id: appointmentDetails.serviceProviderId })
                let currentTime = new Date().getTime()
                let appointmentDate = appointmentDetails.appointmentStartTime
                let appointmentTime = appointmentDate.getTime()
                if (appointmentTime - currentTime >= 3600000) {
                    let updatedAppointmentStatus = await booking.findOneAndUpdate({ _id: req.body.appointmentId }, { $set: { status: 'cancelled', cancelReason: req.body.reason } }, { new: true })
                    if (updatedAppointmentStatus) {
                        let serviceProviderWalletData = await walletModel.findOne({ userId: doctorData._id })
                        let balance = serviceProviderWalletData.totalBalance - appointmentDetails.amount
                        await walletModel.findOneAndUpdate({ userId: doctorData._id }, { $set: { totalBalance: balance } }, { new: true })
                        if (appointmentDetails.appointmentType == "BANK_CARD") {
                            let userWalletData = await walletModel.findOne({ userId: userData._id })
                            let walletBalance = userWalletData.totalBalance + appointmentDetails.amount
                            await walletModel.findOneAndUpdate({ userId: userData._id }, { $set: { totalBalance: walletBalance } }, { new: true })
                        }
                        if (appointmentDetails.appointmentType == "SUBSCRIPTION") {
                            let userWalletData = await walletModel.findOne({ userId: userData._id })
                            let totalSession = userWalletData.sessions + 1
                            await walletModel.findOneAndUpdate({ userId: userData._id }, { $set: { sessions: totalSession } }, { new: true })
                        }
                        let patientName = userData.firstName
                        const pushTitle = "Cancel"
                        const pushBody = `${patientName} has cancel a appointment with you.`
                        const userPushBody = "You have successfully canceled the appointment"
                        commonFunction.pushNotification(doctorData.deviceToken, pushTitle, pushBody)
                        commonFunction.pushNotification(userData.deviceToken, pushTitle, userPushBody)
                        let notifyDoctor = {
                            userId: doctorData._id,
                            title: "Cancel",
                            body: `${patientName} has cancel a appointment  with you.`,
                            notificationType: 'CANCEL',
                            appointmentId: appointmentDetails._id
                        }
                        let notifyUser = {
                            userId: userData._id,
                            title: "Cancel",
                            body: "You have successfully canceled the appointment",
                            notificationType: 'CANCEL',
                            appointmentId: appointmentDetails._id
                        }
                        let notiData = new notification(notifyDoctor)
                        let notiData1 = new notification(notifyUser)
                        notiData.save()
                        notiData1.save()

                        var my_job = schedule.scheduledJobs[JSON.stringify(req.body.appointmentId)];
                        if (my_job) {
                            my_job.cancel();
                        }
                        return res.status(200).send({ responseMessage: "You have successfully canceled the appointment" })
                    }
                } else {
                    return res.status(200).send({ responseMessage: "Can't cancel now" })
                }
            }
        } catch (e) {
            console.log(e)
            return res.status(501).send({ responseCode: 501, responseMessage: ErrorMessage.SOMETHING_WRONG, e })
        }
    },

    rescheduleAppointment: async (req, res) => {
        try {
            let userId = req.userId
            let userData = await user.findOne({ _id: userId })
            let query = { _id: req.body.appointmentId }
            let appointmentDetails = await booking.findOne(query).lean()
            if (!appointmentDetails) {
                return res.status(404).send({ responseCode: 404, responseMessage: ErrorMessage.NOT_FOUND })
            } else {
                let doctorData = await user.findOne({ _id: appointmentDetails.serviceProviderId })
                let currentTime = new Date().getTime()
                let appointmentDate = appointmentDetails.appointmentStartTime
                let appointmentTime = appointmentDate.getTime()
                console.log("=========appointmentTime", appointmentTime)
                console.log("=================currentTime", currentTime)
                if (appointmentTime - currentTime >= 3600000) {
                    console.log("difference", appointmentTime - currentTime)
                    let updatedAppointmentStatus = await booking.findOneAndUpdate({ _id: req.body.appointmentId }, { $set: { status: 'rescheduled' } }, { new: true })

                    req.body.serviceProviderId = appointmentDetails.serviceProviderId
                    req.body.patientId = appointmentDetails.patientId
                    req.body.reason = appointmentDetails.reason
                    req.body.document = appointmentDetails.document
                    req.body.paymentStatus = 'paid'
                    req.body.status = "accepted"
                    req.body.oldAppointmentId = appointmentDetails._id
                    req.body.amount = userData.serviceCharge
                    req.body.appointmentStartTime = req.body.appointmentStartTime
                    req.body.appointmentEndTime = req.body.appointmentEndTime
                    req.body.bookingDate = new Date(req.body.bookingDate)
                    let data = new booking(req.body);
                    let bookingData = await data.save()
                    if (bookingData) {
                        let appointmentId = bookingData._id
                        let patientName = userData.firstName + ' ' + userData.lastName
                        // notify to ownself 
                        const pushTitle1 = "Reschedule Confirmed"
                        const pushBody1 = "you have successfully rescheduled the appointment"
                        commonFunction.pushNotification(userData.deviceToken, pushTitle1, pushBody1)
                        let notifyToOwn = {
                            userId: userData._id,
                            title: "Reschedule Confimed",
                            body: "you have successfully rescheduled the appointment",
                            notificationType: 'RESCHEDULE',
                            appointmentId: bookingData._id
                        }
                        let patientNotiData = new notification(notifyToOwn)
                        patientNotiData.save()

                        // Notify to doctor
                        const pushTitle = "Reschedule"
                        const pushBody = `${patientName} has reschedule  appointment with new time.`
                        commonFunction.pushNotification(doctorData.deviceToken, pushTitle, pushBody)
                        let notify = {
                            userId: doctorData._id,
                            title: "Reschedule",
                            body: `${patientName} has reschedule  appointment with new time.`,
                            notificationType: 'RESCHEDULE',
                            appointmentId: bookingData._id
                        }
                        let notiData = new notification(notify)
                        notiData.save((notiErr, notiSaveData) => {
                            if (notiErr) return res.status(500).send({ responseMessage: ErrorMessage.INTERNAL_ERROR, notiErr })
                            let appointmentTime = req.body.appointmentStartTime
                            let year = new Date(appointmentTime).getFullYear()
                            let month = new Date(appointmentTime).getMonth()
                            let day = new Date(appointmentTime).getDate()
                            let hours = new Date(appointmentTime).getHours()
                            let minutes = new Date(appointmentTime).getMinutes()
                            var date1 = new Date(year, month, day, hours, minutes - 15, 0)
                            var my_job = schedule.scheduledJobs[JSON.stringify(req.body.appointmentId)];
                            if (my_job) {
                                my_job.cancel();
                            }
                            let title = "Reminder"
                            let body = `You have an appointment in the next 15 minutes with ${doctorData.fullName}.`
                            var j = schedule.scheduleJob(JSON.stringify(appointmentId), date1, function () {
                                console.log('The world is going to end today.');
                                commonFunction.pushNotification(userData.deviceToken, title, body)
                            });
       
                            return res.status(200).send({ responseMessage: SuccessMessage.BOOKING_SUCCESS })

                        })
                    }
                } else {
                    return res.status(200).send({ responseMessage: "Can't reschedule now" })
                }
            }
        } catch (e) {
            console.log(e)
            return res.status(501).send({ responseCode: 501, responseMessage: ErrorMessage.SOMETHING_WRONG, e })
        }
    },


    bookAppointment_fromCard: async (req, res) => {
        try {
            let userId = req.userId
            let userData = await user.findOne({ _id: userId })
            if (!userData) return res.status(404).send({ responseMessage: ErrorMessage.NOT_FOUND })
            let serviceProviderData = await user.findOne({ _id: req.body.serviceProviderId })
            if (!serviceProviderData) return res.status(404).send({ responseMessage: "Service Provider not found" })
            let date = new Date(req.body.appointmentStartTime)
            let criteria = { serviceProviderId: req.body.serviceProviderId, appointmentStartTime: date, status: "accepted" }
            let slotExistData = await booking.find(criteria)
            if (slotExistData.length != 0) return res.status(409).send({ responseMessage: "This slot is already booked by someone! please choose another slot." })
            stripe.tokens.create({
                card: {
                    number: req.body.cardNumber,
                    exp_month: req.body.exp_month,
                    exp_year: req.body.exp_year,
                    cvc: req.body.cvc,
                    currency: 'USD'
                }
            }, (tokenErr, token) => {
                if (tokenErr)
                    if (tokenErr) return res.status(500).send({ responseMessage: tokenErr.raw.message })
                stripe.customers.create({
                    email: userData.email,
                    source: token.id,
                }, (customerErr, customer) => {
                    if (customerErr) return res.status(500).send({ responseMessage: ErrorMessage.INTERNAL_ERROR, customerErr })
                    stripe.charges.create({
                        amount: req.body.price * 100,
                        currency: "USD",
                        customer: customer.id
                    }, (chargeErr, charge) => {
                        if (chargeErr) return res.status(500).send({ responseMessage: ErrorMessage.INTERNAL_ERROR, chargeErr })
                        var paymentObj = {
                            transactionId: charge.balance_transaction,
                            chargeId: charge.id,
                            currency: charge.currency,
                            amount: req.body.price,
                            customerId: charge.customer,
                            url: charge.receipt_url,
                            email: customer.email,
                            transactionStatus: charge.status,
                            userId: userId,
                            paymentType: req.body.cardType
                        }
                        var paymentData = new transaction(paymentObj)
                        paymentData.save(async (paymentSaveErr, paymentSaveData) => {
                            console.log("==========paymentSaveErr", paymentSaveErr)
                            if (paymentSaveErr) return res.status(500).send({ responseMessage: ErrorMessage.INTERNAL_ERROR, paymentSaveErr })
                            req.body.serviceProviderId = req.body.serviceProviderId
                            req.body.patientId = userId
                            req.body.paymentStatus = 'paid'
                            req.body.appointmentType = 'BANK_CARD'
                            req.body.amount = req.body.price
                            req.body.appointmentStartTime = req.body.appointmentStartTime
                            req.body.appointmentEndTime = req.body.appointmentEndTime
                            req.body.bookingDate = new Date(req.body.bookingDate)
                            let data = new booking(req.body);
                            let bookingData = await  data.save()
                            console.log("=============bookingData",bookingData)
                            if (bookingData) {
                                let serviceProviderWalletData = await walletModel.findOne({ userId: req.body.serviceProviderId })
                                let balance = serviceProviderWalletData.totalBalance + req.body.amount
                                await walletModel.findOneAndUpdate({ userId: serviceProviderData._id }, { $set: { totalBalance: balance } }, { new: true })
                                let clientName = userData.firstName + ' ' + userData.lastName

                                // notify to own self
                                const pushTitle1 = "Booking Confirmed"
                                const pushBody1 = "Congratulations, your appointment is confirmed"
                                commonFunction.pushNotification(userData.deviceToken, pushTitle1, pushBody1)

                                let notifyToOwn = {
                                    userId: userId,
                                    title: "Booking Confirmed",
                                    body: "Congratulations, your appointment is confirmed",
                                    notificationType: 'BOOKING',
                                    appointmentId: bookingData._id
                                }
                                let patientNotifyData = new notification(notifyToOwn)
                                patientNotifyData.save()

                                // Notify to doctor
                                const pushTitle = "New Booking"
                                const pushBody = `${clientName} has booked an appointment with you.Please check your schedule`
                                commonFunction.pushNotification(serviceProviderData.deviceToken, pushTitle, pushBody)
                                let notify = {
                                    userId: req.body.serviceProviderId,
                                    title: "New Booking",
                                    body: `${clientName} has booked an appointment with  you.Please check your schedule`,
                                    notificationType: 'BOOKING',
                                    appointmentId: bookingData._id
                                }
                                let notiData = new notification(notify)
                                notiData.save(async (notiErr, notiSaveData) => {
                                    if (notiErr) return res.status(500).send({ responseMessage: ErrorMessage.INTERNAL_ERROR, notiErr })
                                    if (req.body.cardSave == true) {
                                        let cardObj = {
                                            cardType: req.body.cardType,
                                            cardHolderName: req.body.cardHolderName,
                                            cardNumber: req.body.cardNumber,
                                            expMonth: req.body.exp_month,
                                            expYear: req.body.exp_year,
                                            userId: userId
                                        }
                                        let cardData = new cardModel(cardObj);
                                        cardData.save()
                                    }
                                    let prefix = '#'
                                    let documentNumber = await invoiceModel.find({}).countDocuments()
                                    console.log("=========documentNumber1", documentNumber)

                                    var numberCount;
                                    if (documentNumber === 0) {
                                        numberCount = 1
                                    } else {
                                        numberCount = documentNumber
                                    }
                                    let invoiceNumber = prefix + numberCount
                                    let invoiceObj = {
                                        paymentType: req.body.cardType,
                                        cardNumber: req.body.cardNumber,
                                        patientId: userId,
                                        invoiceNumber: invoiceNumber,
                                        serviceProviderId: req.body.serviceProviderId,
                                        amount: req.body.price,
                                        invoiceFrom: userId
                                    }
                                    let invoiceData = new invoiceModel(invoiceObj);
                                    invoiceData.save()

                                    // Setup cron jobs
                                    let appointmentId =bookingData._id
                                    let appointmentTime = req.body.appointmentStartTime
                                    let year = new Date(appointmentTime).getFullYear()
                                    let month = new Date(appointmentTime).getMonth()
                                    let day = new Date(appointmentTime).getDate()
                                    let hours = new Date(appointmentTime).getHours()
                                    let minutes = new Date(appointmentTime).getMinutes()
                                    var date1 = new Date(year, month, day, hours, minutes - 15, 0);
                                    let title = "Reminder"
                                    let body = `You have an appointment in the next 15 minutes with ${serviceProviderData.fullName}.`
                                    var j = schedule.scheduleJob(JSON.stringify(appointmentId), date1, function () {
                                        console.log('The world is going to end today.');
                                        commonFunction.pushNotification(userData.deviceToken, title, body)
                                    });
                                    console.log(">>>>>>>>>>jonId", j)

                                    return res.status(200).send({ responseMessage: SuccessMessage.BOOKING_SUCCESS })

                                })
                            }

                        })

                    })

                })
            })

        }
        catch (e) {
            console.log(e)
            return res.status(501).send({ responseMessage: ErrorMessage.SOMETHING_WRONG, e })
        }
    },


}