const user = require('../../model/user')
const laboratoryModel = require('../../model/laboratory')
const ratingModel = require('../../model/rating')

const { commonResponse: response } = require('../../helper/commonResponseHandler');
const { ErrorMessage } = require('../../helper/message');
const { SuccessMessage } = require('../../helper/message');
// const { ErrorCode } = require('../../helper/statusCode');
// const { SuccessCode } = require('../../helper/statusCode');
const mongoose = require('mongoose')




module.exports = {
    rating: async (req, res) => {
        try {
            let userId = req.userId
            let userData = await user.findOne({ _id: req.body.userId })
            if (!userData) return res.status(404).send({ responseMessage: ErrorMessage.NOT_FOUND })
            let ratingExistData = await ratingModel.findOne({ doctorId: req.body.userId, userId: userId, status: "ACTIVE" })
            if (ratingExistData) {
               // return res.status(403).send({ responseCode: 403, responseMessage: "Already given" })
               console.log("===========herein existing rating")
               console.log("=============req.body",req.body)

               let totalSum = req.body.overAllServices + req.body.attentiveness + req.body.supportive + req.body.serviceQuality
               var averageRating = Math.round((totalSum / 4).toFixed(1))
               console.log("=============totalsummmmmmmm",totalSum,averageRating)
               req.body.rating = averageRating
               req.body.userId = userId
               console.log("===========req.body",req.body)
               let updateRating = await ratingModel.findOneAndUpdate({ _id: ratingExistData._id }, { $set: req.body }, { new: true })
               if (updateRating) {
                   let totalList = await ratingModel.find({ doctorId: ratingExistData.doctorId, status: "ACTIVE" })
                   const totalRatingCount = totalList.map((x) => x.rating).reduce((acc, score) => acc + score, 0);
                   let totalDocumentCount = await ratingModel.find({ doctorId: ratingExistData.doctorId, status: "ACTIVE" }).countDocuments();
                   if (totalDocumentCount != 0) {
                       let userAverageRating = Math.round((totalRatingCount / totalDocumentCount).toFixed(1))
                       await user.findOneAndUpdate({ _id: ratingExistData.doctorId }, { $set: { rating: userAverageRating } }, { new: true })
                   }
               }
               await user.findOneAndUpdate({ _id: userId }, { $addToSet: { ratingArray: ratingExistData.doctorId } }, { new: true })
               return res.status(200).send({ responseMessage: SuccessMessage.RATING_SAVED })


            }
            let totalSum = req.body.overAllServices + req.body.attentiveness + req.body.supportive + req.body.serviceQuality
            var averageRating = Math.round((totalSum / 4).toFixed(1))
            let ratingObject = {
                rating: averageRating,
                review: req.body.review,
                overAllServices: req.body.overAllServices,
                attentiveness: req.body.attentiveness,
                supportive: req.body.supportive,
                serviceQuality: req.body.serviceQuality,
                userId: userId,
                doctorId: req.body.userId

            }
            let ratingData = new ratingModel(ratingObject);
            let savedData = ratingData.save()
            if (savedData) {
                let totalList = await ratingModel.find({ doctorId: req.body.userId, status: "ACTIVE" })
                const totalRatingCount = totalList.map((x) => x.rating).reduce((acc, score) => acc + score, 0);
                let totalDocumentCount = await ratingModel.find({ doctorId: req.body.userId, status: "ACTIVE" }).countDocuments();
                if (totalDocumentCount != 0) {
                    let userAverageRating = Math.round((totalRatingCount / totalDocumentCount).toFixed(1))
                    await user.findOneAndUpdate({ _id: req.body.userId }, { $set: { rating: userAverageRating } }, { new: true })
                }
            }
            await user.findOneAndUpdate({ _id: req.body.userId }, { $set: { rating: averageRating } }, { new: true })
            await user.findOneAndUpdate({ _id: userId }, { $addToSet: { ratingArray: req.body.userId } }, { new: true })
            return res.status(200).send({responseMessage: SuccessMessage.RATING_SAVED })

        } catch (e) {
            console.log(e)
            return res.status(501).send({ responseMessage: ErrorMessage.SOMETHING_WRONG, e })
        }
    },
    reviewsList: async (req, res) => {
        try {
            let userId = req.userId
            let documentList;
            let totalList;
            let pageNumber = +req.query.pageNumber || 1
            let limit = +req.query.limit || 10
            let criteria = { userId: userId, status: "ACTIVE" }
            totalList = await ratingModel.find(criteria).countDocuments();
            documentList = await ratingModel.find(criteria, { status: 0}).populate({
                path: 'doctorId',
                model: 'user',
                select: 'fullName experience_in_years experience_in_months primary_specialty profilePic serviceCharge',
                populate: {
                    path: 'secondry_specialty',
                    model: 'specialty',
                    select: 'secondry_specialty'
                }
            }).sort({ createdAt: -1 })
                .skip((limit * pageNumber) - limit).limit(limit).lean()
            if (!documentList) {
                return res.status(404).send({ responseMessage: ErrorMessage.NOT_FOUND })
            }
            return res.status(200).send({ responseMessage: SuccessMessage.DATA_FOUND, documentList, totalList })
        } catch (e) {
            console.log(e)
            return res.status(501).send({ responseMessage: ErrorMessage.SOMETHING_WRONG, e })
        }
    },

    editRating: async (req, res) => {
        try {
            let ratingData = await ratingModel.findOne({ _id: req.body.reviewId })
            if (!ratingData) return res.status(404).send({ responseMessage: ErrorMessage.NOT_FOUND })

            let totalSum = req.body.overAllServices + req.body.attentiveness + req.body.supportive + req.body.serviceQuality
            var averageRating = Math.round((totalSum / 4).toFixed(1))
            req.body.rating = averageRating
            let updateRating = await ratingModel.findOneAndUpdate({ _id: ratingData._id }, { $set: req.body }, { new: true })
            if (updateRating) {
                let totalList = await ratingModel.find({ doctorId: ratingData.doctorId, status: "ACTIVE" })
                const totalRatingCount = totalList.map((x) => x.rating).reduce((acc, score) => acc + score, 0);
                let totalDocumentCount = await ratingModel.find({ doctorId: ratingData.doctorId, status: "ACTIVE" }).countDocuments();
                if (totalDocumentCount != 0) {
                    let userAverageRating = Math.round((totalRatingCount / totalDocumentCount).toFixed(1))
                    await user.findOneAndUpdate({ _id: ratingData.doctorId }, { $set: { rating: userAverageRating } }, { new: true })
                }
            }
            return res.status(200).send({ responseMessage: SuccessMessage.RATING_SAVED })

        } catch (e) {
            console.log(e)
            return res.status(501).send({ responseMessage: ErrorMessage.SOMETHING_WRONG, e })
        }
    },






}