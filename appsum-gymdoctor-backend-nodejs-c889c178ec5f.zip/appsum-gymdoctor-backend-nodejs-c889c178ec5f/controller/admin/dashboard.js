const userModel = require('../../model/user')
const appointmentModel = require('../../model/appointment')
const transactionModel = require('../../model/transaction')
const {
    commonResponse: response
} = require('../../helper/commonResponseHandler');
const {
    ErrorMessage
} = require('../../helper/message');
const {
    SuccessMessage
} = require('../../helper/message');
const {
    ErrorCode
} = require('../../helper/statusCode');
const {
    SuccessCode
} = require('../../helper/statusCode');
const commonFunction = require('../../utility/common')


module.exports = {

    dashboard: async (req, res) => {
        try {
            let patientData = await userModel.find({
                status: "ACTIVE",
                userType: "PATIENT",
                isSubscribe: true
            }).countDocuments()
            let doctorData = await userModel.find({
                status: "ACTIVE",
                userType: "DOCTOR",
                isSubscribe: true
            }).countDocuments()
            let appointmentData = await appointmentModel.find({
                status: {
                    $in: ["accepted", "cancelled"]
                }
            }).countDocuments()
            let earningData = await transactionModel.aggregate([{
                    $match: {
                        transactionStatus: "succeeded"
                    }
                },
                {
                    $group: {
                        _id: null,
                        totalAmount: {
                            $sum: "$amount"
                        }
                    }
                }
            ])
            let revenue = earningData[0].totalAmount
            return res.status(200).send({
                responseMessage: "Data",
                patientData,
                doctorData,
                appointmentData,
                revenue
            })
        } catch (e) {
            return res.status(501).send({
                responseMessage: ErrorMessage.SOMETHING_WRONG,
                e
            })
        }
    },


    revenueGraph: async (req, res) => {
        var aggregate = transactionModel.aggregate();
        if (req.query.type == "Yearly") {
            // get yearly wise data
            var data = await aggregate
                .project({
                    amount: 1,
                    year: {
                        $year: "$createdAt"
                    }
                })
                .group({
                    _id: "$year",
                    totalAmount: {
                        "$sum": "$amount"
                    }
                });
            console.log("=========data", data)
            var result = {};
            // assign year wise amount
            data.forEach((d) => result[d._id] = d.totalAmount);
            // send response
            // res.send(result);
            return res.status(200).send({
                responseMessage: "Ok",
                result
            })

        } else if (req.query.type == "Monthly") {
            // get monthly wise data
            var months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
            var result = {};
            // assign default value
            months.forEach((m) => result[m] = 0);
            console.log("=========44", months)
            // current year
            var year = new Date().getFullYear();
            var data = await aggregate
                .project({
                    amount: 1,
                    year: {
                        $year: "$createdAt"
                    },
                    month: {
                        $month: "$createdAt"
                    }
                })
                .match({
                    year
                })
                .group({
                    _id: "$month",
                    totalAmount: {
                        "$sum": "$amount"
                    }
                });
            // assign month wise amount
            console.log("======data", data)
            data.forEach((d) => result[months[d._id - 1]] = d.totalAmount);
            // send response
            // res.send(result);
            return res.status(200).send({
                responseMessage: "Ok",
                result
            })
        } else if (req.query.type == "Weekly") {
            // get weekly wise data
            // get current week count - start
            var currentdate = new Date();
            var oneJan = new Date(currentdate.getFullYear(), 0, 1);
            var numberOfDays = Math.floor((currentdate - oneJan) / (24 * 60 * 60 * 1000));
            var weekNumber = Math.ceil((currentdate.getDay() + 1 + numberOfDays) / 7);
            // -- end
            // current year
            var year = new Date().getFullYear();
            var result = {};
            var days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
            // assing default value
            days.forEach((d) => result[d] = 0);
            console.log("===========days", days)
            var year = new Date().getFullYear();
            var data = await aggregate
                .project({
                    amount: 1,
                    year: {
                        $year: "$createdAt"
                    },
                    dayOfWeek: {
                        $dayOfWeek: "$createdAt"
                    },
                    week: {
                        $week: "$createdAt"
                    }
                })
                .match({
                    year,
                    week: weekNumber
                })
                .group({
                    _id: "$dayOfWeek",
                    totalAmount: {
                        "$sum": "$amount"
                    }
                });
            // assign day wise amount
            console.log("=======result obj", result)
            console.log("========data", data)
            data.forEach((d) => result[days[d._id - 1]] = d.totalAmount);
            // send response
            // res.send(result);
            return res.status(200).send({
                responseMessage: "Ok",
                result
            })
        } else if (req.query.type == "Daily") {
            // get daily wise data
            let query = [{
                $group: {
                    _id: {
                        month: {
                            $month: "$createdAt"
                        },
                        day: {
                            $dayOfMonth: "$createdAt"
                        },
                        year: {
                            $year: "$createdAt"
                        }
                    },
                    totalAmount: {
                        $sum: "$amount"
                    }
                }
            }];
            let data = await transactionModel.aggregate(query).exec();


            // var formattedDate = `${date.getFullYear()}/${(date.getMonth() + 1)}/${date.getDate()}`;

            // let key1=(data.map(item=>(`${item._id.year}/${item._id.month}/${item._id.day}`)))
            // console.log(key1)
            // let key2=data.map(item=>item.totalAmount)
            // console.log(key2)
            // var arrayOfObject = key1.map(function (value, index){
            //    return [value, key2[index]]
            // });
            // let result = Object.fromEntries(arrayOfObject)

            var obj = {}
            let arr1 = data.map((item) => {
                let obj1 = {
                    [`${item._id.year}/${item._id.month}/${item._id.day}`]: item.totalAmount
                };
                obj = {
                    ...obj,
                    ...obj1
                }
                return obj
            });

            arr1[arr1.length - 1];
            let obj1 = {}
            let updatedArray = Object.keys(obj).map((item, i) => {
                Object.values(obj).map((val, j) => {
                    if (i === j) {
                        obj1 = {
                            'amount': val
                        }
                    }

                })
                return {
                    ...obj1,
                    'date': new Date(item).toISOString()
                }
            })

            let sortedData = updatedArray.sort((a, b) => {
                let c = new Date(a.date).getTime();
                let d = new Date(b.date).getTime();
                console.log('c', c, 'd ', d);
                return c - d
            });
            let sortObj = {};
            let afterSort = sortedData.map(item => {

                sortObj = {
                    ...sortObj,
                    [item.date]: item.amount
                }
                return sortObj
            })
            let result = afterSort[afterSort.length - 1];
            console.log('result', result);

            // // res.send(result);
            return res.status(200).send({
                responseCode: 200,
                responseMessage: "Ok",
                result
            })

        } else {
            // invalid type
            // res.send({ });
            return res.status(500).send({
                responseCode: 500,
                responseMessage: "Please select valid type"
            })
        }
    },

    appointmentGraph: async (req, res) => {
        var aggregate = appointmentModel.aggregate();
        if (req.query.type == "Yearly") {
            // get yearly wise data
            var data = await aggregate
                .project({
                    _id: 1,
                    year: {
                        $year: "$createdAt"
                    }
                })
                .group({
                    _id: "$year",
                    totalAppointment: {
                        "$sum": 1
                    }
                });
            console.log("=========data", data)
            var result = {};
            // assign year wise amount
            data.forEach((d) => result[d._id] = d.totalAppointment);
            // send response
            // res.send(result);
            return res.status(200).send({
                responseMessage: "Ok",
                result
            })

        } else if (req.query.type == "Monthly") {
            // get monthly wise data
            var months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
            var result = {};
            // assign default value
            months.forEach((m) => result[m] = 0);
            console.log("=========44", months)
            // current year
            var year = new Date().getFullYear();
            var data = await aggregate
                .project({
                    _id: 1,
                    year: {
                        $year: "$createdAt"
                    },
                    month: {
                        $month: "$createdAt"
                    }
                })
                .match({
                    year
                })
                .group({
                    _id: "$month",
                    totalAppointment: {
                        "$sum": 1
                    }
                });
            // assign month wise amount
            console.log("======data", data)
            data.forEach((d) => result[months[d._id - 1]] = d.totalAppointment);
            // send response
            // res.send(result);
            return res.status(200).send({
                responseMessage: "Ok",
                result
            })
        } else if (req.query.type == "Weekly") {
            // get weekly wise data
            // get current week count - start
            var currentdate = new Date();
            var oneJan = new Date(currentdate.getFullYear(), 0, 1);
            var numberOfDays = Math.floor((currentdate - oneJan) / (24 * 60 * 60 * 1000));
            var weekNumber = Math.ceil((currentdate.getDay() + 1 + numberOfDays) / 7);
            // -- end
            // current year
            var year = new Date().getFullYear();
            var result = {};
            var days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
            // assing default value
            days.forEach((d) => result[d] = 0);
            var year = new Date().getFullYear();
            var data = await aggregate
                .project({
                    _id: 1,
                    year: {
                        $year: "$createdAt"
                    },
                    dayOfWeek: {
                        $dayOfWeek: "$createdAt"
                    },
                    week: {
                        $week: "$createdAt"
                    }
                })
                .match({
                    year,
                    week: weekNumber
                })
                .group({
                    _id: "$dayOfWeek",
                    totalAppointment: {
                        $sum: 1
                    }
                });
            // assign day wise amount
            data.forEach((d) => result[days[d._id - 1]] = d.totalAppointment);
            // send response
            // res.send(result);
            return res.status(200).send({
                responseMessage: "Ok",
                result
            })
        } else if (req.query.type == "Daily") {
            // get daily wise data
            let query = [{
                $group: {
                    _id: {
                        month: {
                            $month: "$createdAt"
                        },
                        day: {
                            $dayOfMonth: "$createdAt"
                        },
                        year: {
                            $year: "$createdAt"
                        }
                    },
                    totalAppointment: {
                        "$sum": 1
                    }
                }
            }];
            let data = await appointmentModel.aggregate(query).exec();

            var obj = {}
            let arr1 = data.map((item) => {
                let obj1 = {
                    [`${item._id.year}/${item._id.month}/${item._id.day}`]: item.totalAmount
                };
                obj = {
                    ...obj,
                    ...obj1
                }
                return obj
            });

            arr1[arr1.length - 1];
            let obj1 = {}
            let updatedArray = Object.keys(obj).map((item, i) => {
                Object.values(obj).map((val, j) => {
                    if (i === j) {
                        obj1 = {
                            'totalAppointment': val
                        }
                    }

                })
                return {
                    ...obj1,
                    'date': new Date(item).toISOString()
                }
            })

            let sortedData = updatedArray.sort((a, b) => {
                let c = new Date(a.date).getTime();
                let d = new Date(b.date).getTime();
                console.log('c', c, 'd ', d);
                return c - d
            });
            let sortObj = {};
            let afterSort = sortedData.map(item => {

                sortObj = {
                    ...sortObj,
                    [item.date]: item.totalAppointment
                }
                return sortObj
            })
            let result = afterSort[afterSort.length - 1];
            console.log('result', result);

            // // res.send(result);
            return res.status(200).send({
                responseMessage: "Ok",
                result
            })

        } else {
            // invalid type
            // res.send({ });
            return res.status(500).send({
                responseMessage: "Please select valid type"
            })
        }
    },

    patientGraph: async (req, res) => {
        var aggregate = userModel.aggregate();
        if (req.query.type == "Yearly") {
            // get yearly wise data
            var data = await aggregate
                .match({
                    userType: "PATIENT",
                    isVerified: true
                })
                .project({
                    _id: 1,
                    year: {
                        $year: "$createdAt"
                    }
                })
                .group({
                    _id: "$year",
                    totalUser: {
                        "$sum": 1
                    }
                });
            console.log("=========data", data)
            var patient = {};
            // assign year wise amount
            data.forEach((d) => patient[d._id] = d.totalUser);
            // send response
            // res.send(result);
            return res.status(200).send({
                responseMessage: "Ok",
                patient
            })

        } else if (req.query.type == "Monthly") {
            // get monthly wise data
            var months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
            var patient = {};
            // assign default value
            months.forEach((m) => patient[m] = 0);
            console.log("=========44", months)
            console.log("========45", patient)
            // current year
            var year = new Date().getFullYear();
            console.log("yearrrrrrrrrrrr======", year)
            var data = await aggregate
                .match({
                    userType: "PATIENT",
                    isVerified: true
                })
                .project({
                    _id: 1,
                    year: {
                        $year: "$createdAt"
                    },
                    month: {
                        $month: "$createdAt"
                    }
                })
                .match({
                    year
                })
                .group({
                    _id: "$month",
                    totalUser: {
                        "$sum": 1
                    }
                });
            // assign month wise amount
            console.log("======data", data)
            data.forEach((d) => patient[months[d._id - 1]] = d.totalUser);
            // send response
            // res.send(result);
            return res.status(200).send({
                responseMessage: "Ok",
                patient
            })
        } else if (req.query.type == "Weekly") {
            // get weekly wise data
            // get current week count - start
            var currentdate = new Date();
            var oneJan = new Date(currentdate.getFullYear(), 0, 1);
            var numberOfDays = Math.floor((currentdate - oneJan) / (24 * 60 * 60 * 1000));
            var weekNumber = Math.ceil((currentdate.getDay() + 1 + numberOfDays) / 7);
            console.log("week number", weekNumber)
            // -- end
            // current year
            var year = new Date().getFullYear();
            var patient = {};
            var days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
            // assing default value
            days.forEach((d) => patient[d] = 0);
            console.log("==========patient obj", patient)
            var year = new Date().getFullYear();
            var data = await aggregate
                .match({
                    userType: "PATIENT",
                    isVerified: true
                })
                .project({
                    _id: 1,
                    year: {
                        $year: "$createdAt"
                    },
                    dayOfWeek: {
                        $dayOfWeek: "$createdAt"
                    },
                    week: {
                        $week: "$createdAt"
                    }
                })
                .match({
                    year,
                    week: weekNumber
                })
                .group({
                    _id: "$dayOfWeek",
                    totalUser: {
                        $sum: 1
                    }
                });

            console.log("=======data", data)
            // assign day wise amount
            data.forEach((d) => patient[days[d._id - 1]] = d.totalUser);
            // send response
            // res.send(result);
            return res.status(200).send({
                responseMessage: "Ok",
                patient
            })
        } else if (req.query.type == "Daily") {
            // get daily wise data
            let query = [{
                $group: {
                    _id: {
                        month: {
                            $month: "$createdAt"
                        },
                        day: {
                            $dayOfMonth: "$createdAt"
                        },
                        year: {
                            $year: "$createdAt"
                        }
                    },
                    totalUser: {
                        "$sum": 1
                    }
                }
            }];
            let data = await appointmentModel.aggregate(query).exec();

            var obj = {}
            let arr1 = data.map((item) => {
                let obj1 = {
                    [`${item._id.year}/${item._id.month}/${item._id.day}`]: item.totalUser
                };
                obj = {
                    ...obj,
                    ...obj1
                }
                return obj
            });

            arr1[arr1.length - 1];
            let obj1 = {}
            let updatedArray = Object.keys(obj).map((item, i) => {
                Object.values(obj).map((val, j) => {
                    if (i === j) {
                        obj1 = {
                            'totaluser': val
                        }
                    }

                })
                return {
                    ...obj1,
                    'date': new Date(item).toISOString()
                }
            })

            let sortedData = updatedArray.sort((a, b) => {
                let c = new Date(a.date).getTime();
                let d = new Date(b.date).getTime();
                console.log('c', c, 'd ', d);
                return c - d
            });
            let sortObj = {};
            let afterSort = sortedData.map(item => {

                sortObj = {
                    ...sortObj,
                    [item.date]: item.totalUser
                }
                return sortObj
            })
            let patient = afterSort[afterSort.length - 1];

            // // res.send(result);
            return res.status(200).send({
                responseMessage: "Ok",
                patient
            })

        } else {
            // invalid type
            // res.send({ });
            return res.status(500).send({
                responseMessage: "Please select valid type"
            })
        }
    },

    doctorGraph: async (req, res) => {
        var aggregate = userModel.aggregate();
        if (req.query.type == "Yearly") {
            // get yearly wise data
            var data = await aggregate
                .match({
                    userType: "DOCTOR",
                    isVerified: true
                })
                .project({
                    _id: 1,
                    year: {
                        $year: "$createdAt"
                    }
                })
                .group({
                    _id: "$year",
                    totalUser: {
                        "$sum": 1
                    }
                });
            console.log("=========data", data)
            var doctor = {};
            // assign year wise amount
            data.forEach((d) => doctor[d._id] = d.totalUser);
            // send response
            // res.send(result);
            return res.status(200).send({
                responseMessage: "Ok",
                doctor
            })

        } else if (req.query.type == "Monthly") {
            // get monthly wise data
            var months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
            var doctor = {};
            // assign default value
            months.forEach((m) => doctor[m] = 0);
            console.log("=========44", months)
            // current year
            var year = new Date().getFullYear();
            var data = await aggregate
                .match({
                    userType: "DOCTOR",
                    isVerified: true
                })
                .project({
                    _id: 1,
                    year: {
                        $year: "$createdAt"
                    },
                    month: {
                        $month: "$createdAt"
                    }
                })
                .match({
                    year
                })
                .group({
                    _id: "$month",
                    totalUser: {
                        "$sum": 1
                    }
                });
            // assign month wise amount
            console.log("======data", data)
            data.forEach((d) => doctor[months[d._id - 1]] = d.totalUser);
            // send response
            // res.send(result);
            return res.status(200).send({
                responseMessage: "Ok",
                doctor
            })
        } else if (req.query.type == "Weekly") {
            // get weekly wise data
            // get current week count - start
            var currentdate = new Date();
            var oneJan = new Date(currentdate.getFullYear(), 0, 1);
            var numberOfDays = Math.floor((currentdate - oneJan) / (24 * 60 * 60 * 1000));
            var weekNumber = Math.ceil((currentdate.getDay() + 1 + numberOfDays) / 7);
            console.log("week number", weekNumber)
            // -- end
            // current year
            var year = new Date().getFullYear();
            var doctor = {};
            var days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
            // assing default value
            days.forEach((d) => doctor[d] = 0);
            var year = new Date().getFullYear();
            var data = await aggregate
                .match({
                    userType: "DOCTOR",
                    isVerified: true
                })
                .project({
                    _id: 1,
                    year: {
                        $year: "$createdAt"
                    },
                    dayOfWeek: {
                        $dayOfWeek: "$createdAt"
                    },
                    week: {
                        $week: "$createdAt"
                    }
                })
                .match({
                    year,
                    week: weekNumber
                })
                .group({
                    _id: "$dayOfWeek",
                    totalUser: {
                        $sum: 1
                    }
                });

            console.log("=======data", data)
            // assign day wise amount
            data.forEach((d) => doctor[days[d._id - 1]] = d.totalUser);
            // send response
            // res.send(result);
            return res.status(200).send({
                responseMessage: "Ok",
                doctor
            })
        } else if (req.query.type == "Daily") {
            // get daily wise data
            let query = [{
                $group: {
                    _id: {
                        month: {
                            $month: "$createdAt"
                        },
                        day: {
                            $dayOfMonth: "$createdAt"
                        },
                        year: {
                            $year: "$createdAt"
                        }
                    },
                    totalUser: {
                        "$sum": 1
                    }
                }
            }];
            let data = await appointmentModel.aggregate(query).exec();

            var obj = {}
            let arr1 = data.map((item) => {
                let obj1 = {
                    [`${item._id.year}/${item._id.month}/${item._id.day}`]: item.totalUser
                };
                obj = {
                    ...obj,
                    ...obj1
                }
                return obj
            });

            arr1[arr1.length - 1];
            let obj1 = {}
            let updatedArray = Object.keys(obj).map((item, i) => {
                Object.values(obj).map((val, j) => {
                    if (i === j) {
                        obj1 = {
                            'totaluser': val
                        }
                    }

                })
                return {
                    ...obj1,
                    'date': new Date(item).toISOString()
                }
            })

            let sortedData = updatedArray.sort((a, b) => {
                let c = new Date(a.date).getTime();
                let d = new Date(b.date).getTime();
                console.log('c', c, 'd ', d);
                return c - d
            });
            let sortObj = {};
            let afterSort = sortedData.map(item => {

                sortObj = {
                    ...sortObj,
                    [item.date]: item.totalUser
                }
                return sortObj
            })
            let doctor = afterSort[afterSort.length - 1];

            // // res.send(result);
            return res.status(200).send({
                responseMessage: "Ok",
                doctor
            })

        } else {
            // invalid type
            // res.send({ });
            return res.status(500).send({
                responseMessage: "Please select valid type"
            })
        }
    },




}