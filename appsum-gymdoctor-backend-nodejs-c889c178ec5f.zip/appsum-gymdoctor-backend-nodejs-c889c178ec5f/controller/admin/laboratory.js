const laboratoryModel = require('../../model/laboratory')
const appointmentModel = require('../../model/laboratoryBooking')
const packageModel = require('../../model/package')
const userModel = require('../../model/user')
const notification = require('../../model/notification')

const { commonResponse: response } = require('../../helper/commonResponseHandler');
const { ErrorMessage } = require('../../helper/message');
const { SuccessMessage } = require('../../helper/message');
const { ErrorCode } = require('../../helper/statusCode');
const { SuccessCode } = require('../../helper/statusCode');
const commonFunction = require('../../utility/common')



module.exports = {

    /**
 * Function Name :addLaboratory
 * Description   : add lab by admin
 *
 * @return response
*/
    addLaboratory: async (req, res) => {
        try {
            let query = { name: req.body.name, status: { $ne: "DELETE" } }
            let data = await laboratoryModel.findOne(query)
            if (data) return res.status(409).send({ responseMessage: ErrorMessage.ALREADY_EXITS })
            req.body.location = { coordinates: [parseFloat(req.body.long), parseFloat(req.body.lat)], address: req.body.address }
            let labData = new laboratoryModel(req.body);
            labData.save((error, result) => {
                if (error) return res.status(500).send({ responseMessage: ErrorMessage.INTERNAL_ERROR })
                return res.status(200).send({ responseMessage: SuccessMessage.DATA_SAVED, result })
            })
        }
        catch (e) {
            return res.status(501).send({ responseMessage: ErrorMessage.SOMETHING_WRONG, e })
        }
    },

    /**
    * Function Name :editLab
    * Description   :edit lab  by admin
    *
    * @return response
    */

    editLaboratory: async (req, res) => {
        try {
            let data = await laboratoryModel.findOne({ _id: req.query._id, status: { $ne: "DELETE" } })
            if (!data) return res.status(404).send({ responseMessage: ErrorMessage.NOT_FOUND })
            let updateData = await laboratoryModel.findOneAndUpdate({ _id: data._id }, { $set: req.body }, { new: true })
            if (!updateData) return res.status(500).send({ responseMessage: ErrorMessage.INTERNAL_ERROR })
            return res.status(200).send({ responseMessage: SuccessMessage.DATA_SAVED, updateData })
        }
        catch (e) {
            return res.status(501).send({ responseMessage: ErrorMessage.SOMETHING_WRONG, e })
        }
    },



    /**
    * Function Name :actionPerform API
    * Description : actionPerform   API  
    * @return  response
    */

    actionPerform: async (req, res) => {
        try {
            let data = await laboratoryModel.findOne({ _id: req.query._id })
            if (!data) return res.status(404).send({ responseMessage: ErrorMessage.NOT_FOUND })
            let updateData = await laboratoryModel.findOneAndUpdate({ _id: data._id }, { $set: req.query }, { new: true })
            if (!updateData) { return res.status(500).send({ responseMessage: ErrorMessage.INTERNAL_ERROR }) }
            return res.status(200).send({ responseMessage: "Action performed" })

        }
        catch (e) {
            return res.status(501).send({ responseMessage: ErrorMessage.SOMETHING_WRONG, e })
        }
    },


    laboratoryList: async (req, res) => {
        try {
            let documentList;
            let totalList;
            let pageNumber = +req.query.pageNumber
            let limit = +req.query.limit
            let criteria = { status: { $ne: "DELETE" } }
            if (req.query.search) {
                criteria.$or = [{ name: { $regex: req.query.search, $options: 'i' } },
                { name: { $regex: req.query.search, $options: 'i' } }]
            }
            if (req.query.status) {
                criteria.status = +req.query.status
            }
            totalList = await laboratoryModel.find(criteria).countDocuments();
            documentList = await laboratoryModel.find(criteria).sort({ createdAt: -1 })
                .skip((limit * pageNumber) - limit).limit(limit).lean()
            if (!documentList) {
                return res.status(404).send({ responseMessage: ErrorMessage.NOT_FOUND })
            }
            return res.status(200).send({ responseMessage: SuccessMessage.DATA_FOUND, documentList, totalList })


        } catch (e) {
            return res.status(501).send({ responseMessage: ErrorMessage.SOMETHING_WRONG, e })
        }
    },

    viewLaboratory: async (req, res) => {
        let query = { _id: req.params._id }
        let data = await laboratoryModel.findOne(query)
        if (!data)
            return res.status(404).send({ responseMessage: ErrorMessage.NOT_FOUND })
        else {
            return res.status(200).send({ responseMessage: SuccessMessage.DATA_FOUND, data })
        }
    },

    //*********************************PACKGE MANAGEMENT************************************ */

    addPackage: async (req, res) => {
        try {
            let query = { name: req.body.name, status: { $ne: "DELETE" } }
            let data = await packageModel.findOne(query)
            if (data) return res.status(409).send({ responseMessage: ErrorMessage.ALREADY_EXITS })
            let packageData = new packageModel(req.body);
            packageData.save((error, result) => {
                if (error) return res.status(500).send({ responseMessage: ErrorMessage.INTERNAL_ERROR })
                return res.status(200).send({ responseMessage: SuccessMessage.DATA_SAVED, result })
            })
        }
        catch (e) {
            return res.status(501).send({ responseMessage: ErrorMessage.SOMETHING_WRONG, e })
        }
    },


    editPackage: async (req, res) => {
        try {
            let data = await packageModel.findOne({ _id: req.query._id, status: { $ne: "DELETE" } })
            if (!data) return res.status(404).send({ responseMessage: ErrorMessage.NOT_FOUND })
            let updateData = await packageModel.findOneAndUpdate({ _id: data._id }, { $set: req.body }, { new: true })
            if (!updateData) return res.status(500).send({ responseMessage: ErrorMessage.INTERNAL_ERROR })
            return res.status(200).send({ responseMessage: SuccessMessage.DATA_SAVED, updateData })
        }
        catch (e) {
            return res.status(501).send({ responseMessage: ErrorMessage.SOMETHING_WRONG, e })
        }
    },


    actionPerform_package: async (req, res) => {
        try {
            let data = await packageModel.findOne({ _id: req.query._id })
            if (!data) return res.status(404).send({ responseMessage: ErrorMessage.NOT_FOUND })
            let updateData = await packageModel.findOneAndUpdate({ _id: data._id }, { $set: req.query }, { new: true })
            if (!updateData) { return res.status(500).send({ responseMessage: ErrorMessage.INTERNAL_ERROR }) }
            return res.status(200).send({ responseMessage: "Action performed" })

        }
        catch (e) {
            return res.status(501).send({ responseMessage: ErrorMessage.SOMETHING_WRONG, e })
        }
    },

    viewPackage: async (req, res) => {
        let query = { _id: req.params._id }
        let data = await packageModel.findOne(query)
        if (!data)
            return res.status(404).send({ responseMessage: ErrorMessage.NOT_FOUND })
        else {
            return res.status(200).send({ responseMessage: SuccessMessage.DATA_FOUND, data })
        }
    },

    packageList: async (req, res) => {
        try {
            let documentList;
            let totalList;
            let pageNumber = +req.query.pageNumber
            let limit = +req.query.limit
            let criteria = { laboratoryId: req.query.laboratoryId, status: { $ne: "DELETE" } }
            if (req.query.search) {
                criteria.$or = [{ name: { $regex: req.query.search, $options: 'i' } },
                { name: { $regex: req.query.search, $options: 'i' } }]
            }
            if (req.query.status) {
                criteria.status = +req.query.status
            }
            totalList = await packageModel.find(criteria).countDocuments();
            documentList = await packageModel.find(criteria).sort({ createdAt: -1 })
                .skip((limit * pageNumber) - limit).limit(limit).lean()
            if (!documentList) {
                return res.status(404).send({ responseMessage: ErrorMessage.NOT_FOUND })
            }
            return res.status(200).send({ responseMessage: SuccessMessage.DATA_FOUND, documentList, totalList })


        } catch (e) {
            return res.status(501).send({ responseMessage: ErrorMessage.SOMETHING_WRONG, e })
        }
    },
    //  REPORT MANAGEMENT 

    appointmentList: async (req, res) => {
        try {
            let documentList;
            let totalList;
            let pageNumber = +req.query.pageNumber
            let limit = +req.query.limit
            let criteria = { status: { $in: ["pending", "accepted"] } }
            totalList = await appointmentModel.find(criteria).countDocuments();
            documentList = await appointmentModel.find(criteria)
                .populate('patientId', 'firstName lastName profilePic')
                .populate('packageId', 'name')
                .populate('laboratoryId', 'name')
                .sort({ createdAt: -1 })
                .skip((limit * pageNumber) - limit).limit(limit).lean()
            if (!documentList) {
                return res.status(404).send({ responseMessage: ErrorMessage.NOT_FOUND })
            }
            return res.status(200).send({ responseMessage: SuccessMessage.DATA_FOUND, documentList, totalList })
        } catch (e) {
            console.log(e)
            return res.status(501).send({ responseMessage: ErrorMessage.SOMETHING_WRONG, e })
        }
    },


    viewReport: async (req, res) => {
        try {
            let query = { _id: req.params.id }
            appointmentModel.findOne(query, {
                name: 1, date_of_birth: 1, mobileNumber: 1, email: 1, gender: 1,
                reportStatus: 1, reportFile: 1, deliveryStatus: 1
            }).populate('patientId', 'firstName lastName profilePic')
                .populate('packageId', 'name')
                .lean().exec((appointmentErr, appointmentDetails) => {
                    if (appointmentErr) return res.status(500).send({ responseCode: 500, responseMessage: ErrorMessage.INTERNAL_ERROR, appointmentErr })
                    else if (!appointmentDetails) {
                        return res.status(404).send({ responseCode: 404, responseMessage: ErrorMessage.NOT_FOUND })
                    } else {
                        return res.status(200).send({ responseCode: 200, responseMessage: SuccessMessage.DATA_FOUND, appointmentDetails })
                    }
                })
        } catch (e) {
            return res.status(501).send({ responseMessage: ErrorMessage.SOMETHING_WRONG, e })
        }
    },

    uploadReport: async (req, res) => {
        try {
            let data = await appointmentModel.findOne({ _id: req.body.appointmentId })
            if (!data) return res.status(404).send({ responseMessage: ErrorMessage.NOT_FOUND })
            let obj = {
                reportFile: req.body.reportFile,
                deliveryStatus: req.body.deliveryStatus,
                reportStatus: "delivered",
                reportDateTime: Date.now()
            }
            let updateData = await appointmentModel.findOneAndUpdate({ _id: data._id }, { $set: obj }, { new: true })
            let userData = await userModel.findOne({ _id: data.patientId})
            if (!updateData) return res.status(500).send({ responseMessage: ErrorMessage.INTERNAL_ERROR })
            // let clientName = userData.firstName + ' ' + userData.lastName
            const pushTitle = "TEST REPORT"
            const pushBody = "Your Laboratory report is updated. Click on My Reports to download your lab report"
            commonFunction.pushNotification(userData.deviceToken, pushTitle, pushBody)
            let notify = {
                userId: userData._id,
                title: "TEST REPORT",
                body: "Your Laboratory report is updated. Click on My Reports to download your lab report" ,
                notificationType: 'REPORT',
                appointmentId: data._id
            }
            let notiData = new notification(notify)
            notiData.save() 
            return res.status(200).send({ responseMessage: "Report uploaded", updateData })
        }
        catch (e) {
            return res.status(501).send({ responseMessage: ErrorMessage.SOMETHING_WRONG, e })
        }
    },

    updateReport: async (req, res) => {
        try {
            let data = await appointmentModel.findOne({ _id: req.params.id })
            if (!data) return res.status(404).send({ responseMessage: ErrorMessage.NOT_FOUND })
            let updateData = await appointmentModel.findOneAndUpdate({ _id: data._id }, { $set: req.body }, { new: true })
            if (!updateData) return res.status(500).send({ responseMessage: ErrorMessage.INTERNAL_ERROR })
            return res.status(200).send({ responseMessage: "Report uploaded", updateData })
        }
        catch (e) {
            return res.status(501).send({ responseMessage: ErrorMessage.SOMETHING_WRONG, e })
        }
    },

}