const userModel = require('../../model/user')
const acceptMail = require('../../utility/admin/acceptRequest')
const rejectMail = require('../../utility/admin/rejectRequest')
const { ErrorMessage } = require('../../helper/message');
const { SuccessMessage } = require('../../helper/message');




module.exports = {

    serviceProviderList: async (req, res) => {
        try {
            let documentList;
            let totalList;
            let pageNumber = +req.query.pageNumber
            let limit = +req.query.limit
            let criteria = { status: { $ne: "DELETE" }, userType: "DOCTOR" }
            if (req.query.search) {
                criteria.$or = [{ fullName: { $regex: req.query.search, $options: 'i' } },
                { email: { $regex: req.query.search, $options: 'i' } },
                { mobileNumber: { $regex: req.query.search, $options: 'i' } }]
            }
            totalList = await userModel.find(criteria).countDocuments();
            documentList = await userModel.find(criteria)
                .populate('subscriptionId primary_specialtyId', 'name primary_specialty')
                .populate({ path: 'secondry_specialty', model: 'specialty', select: 'secondry_specialty' })
                .sort({ createdAt: -1 })
                .skip((limit * pageNumber) - limit).limit(limit).lean()
            if (!documentList) {
                return res.status(404).send({ responseMessage: ErrorMessage.NOT_FOUND })
            }
            return res.status(200).send({ responseMessage: SuccessMessage.DATA_FOUND, documentList, totalList })


        } catch (e) {
            console.log(e)
            return res.status(501).send({ responseMessage: ErrorMessage.SOMETHING_WRONG, e })
        }
    },

    viewServiceProvider: async (req, res) => {
        let query = { _id: req.params._id }
        let userData = await userModel.findOne(query)
            .populate('subscriptionId primary_specialtyId', 'name primary_specialty')
            .populate({ path: 'secondry_specialty', model: 'specialty', select: 'secondry_specialty' })
        if (!userData)
            return res.status(404).send({ responseMessage: ErrorMessage.NOT_FOUND })
        else {
            return res.status(200).send({ responseMessage: SuccessMessage.DATA_FOUND, userData })
        }
    },



    /**
* Function Name :actionPerform API
* Description : actionPerform   API 
* @return  response
*/

    actionPerform: async (req, res) => {
        try {
            let data = await userModel.findOne({ _id: req.query._id })
            if (!data) return res.status(404).send({ responseMessage: ErrorMessage.NOT_FOUND })
            let updateData = await userModel.findOneAndUpdate({ _id: data._id }, { $set: req.query }, { new: true })
            if (!updateData) { return res.status(404).send({ responseMessage: ErrorMessage.NOT_FOUND }) }
            return res.status(200).send({ responseMessage: "Action performed" })
        }
        catch (e) {
            return res.status(501).send({ responseMessage: ErrorMessage.SOMETHING_WRONG, e })
        }
    },

    
    acceptRejectDeleteRequest: async (req, res) => {
        try {
            let serviceProviderData = await userModel.findOne({ _id: req.query.userId, joinStatus: "Pending" })
            if (!serviceProviderData) return res.status(404).send({responseMessage: ErrorMessage.NOT_FOUND })
            if (req.query.joinStatus == 'Approve') {
                let updateData = await userModel.findOneAndUpdate({ _id: serviceProviderData._id }, { $set: { joinStatus: "Approved" } }, { new: true })
                if (!updateData) return res.status(404).send({responseMessage: ErrorMessage.NOT_FOUND })
                let subject = 'Request Approved'
                let name = serviceProviderData.fullName
                acceptMail.acceptRequest(serviceProviderData.email, subject, name)
                return res.status(200).send({responseMessage: "Accepted successfully" })
            } else if (req.query.joinStatus == 'Reject') {
                let updateData = await userModel.findOneAndUpdate({ _id: serviceProviderData._id }, { $set: { joinStatus:"Rejected"} }, { new: true })
                if (!updateData) return res.status(404).send({responseMessage: ErrorMessage.NOT_FOUND })
                let subject = 'Request Rejected'
                let name = serviceProviderData.fullName
                rejectMail.rejectRequest(serviceProviderData.email, subject, name)
                return res.status(200).send({ responseMessage: "Rejected successfully" })
            } else if (req.query.joinStatus == 'Delete') {
                let updateData = await userModel.findOneAndUpdate({ _id: serviceProviderData._id }, { $set: { status: "DELETE" } }, { new: true })
                if (!updateData) { return res.status(404).send({ responseMessage: ErrorMessage.NOT_FOUND }) }
                return res.status(200).send({ responseMessage: "Deleted successfully" })
            }
        } catch (e) {
            console.log(e)
            return res.status(501).send({responseMessage: ErrorMessage.SOMETHING_WRONG, e })
        }
    },

}