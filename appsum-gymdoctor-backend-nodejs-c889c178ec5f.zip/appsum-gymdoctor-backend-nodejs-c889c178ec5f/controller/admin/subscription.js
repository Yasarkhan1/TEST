const subscriptionModel = require('../../model/subscription')
const userModel = require('../../model/user')

const { commonResponse: response } = require('../../helper/commonResponseHandler');
const { ErrorMessage } = require('../../helper/message');
const { SuccessMessage } = require('../../helper/message');
const { ErrorCode } = require('../../helper/statusCode');
const { SuccessCode } = require('../../helper/statusCode');
const commonFunction = require('../../utility/common');
const { default: mongoose } = require('mongoose');
const { AuthCallsIpAccessControlListMappingContext } = require('twilio/lib/rest/api/v2010/account/sip/domain/authTypes/authCallsMapping/authCallsIpAccessControlListMapping');



module.exports = {

    /**
 * Function Name :addSubscription
 * Description   : add subscription by admin
 *
 * @return response
*/
addSubscription: async (req, res) => {
    try {
        let query = { name: req.body.name, status: { $ne: "DELETE" } }
        let data = await subscriptionModel.findOne(query)
        if (data) return res.status(409).send({ responseMessage: ErrorMessage.ALREADY_EXITS })
        let subscriptionData = new subscriptionModel(req.body);
        subscriptionData.save((error, result) => {
            if (error) return res.status(500).send({ responseMessage: ErrorMessage.INTERNAL_ERROR })
            return res.status(200).send({ responseMessage: SuccessMessage.DATA_SAVED, result })
        })
    }
    catch (e) {
        return res.status(501).send({ responseMessage: ErrorMessage.SOMETHING_WRONG, e })
    }
},

/**
* Function Name :editSubscription
* Description   :edit subscription  by admin
*
* @return response
*/

editSubscription: async (req, res) => {
    try {
        let data = await subscriptionModel.findOne({ _id: req.query._id, status: { $ne: "DELETE" } })
        if (!data) return res.status(404).send({ responseMessage: ErrorMessage.NOT_FOUND })
        let updateData = await subscriptionModel.findOneAndUpdate({ _id: data._id }, { $set: req.body }, { new: true })
        if (!updateData) return res.status(500).send({ responseMessage: ErrorMessage.INTERNAL_ERROR })
        return res.status(200).send({ responseMessage: SuccessMessage.DATA_SAVED, updateData })
    }
    catch (e) {
        return res.status(501).send({ responseMessage: ErrorMessage.SOMETHING_WRONG, e })
    }
},



/**
* Function Name :actionPerform API
* Description : actionPerform   API  
* @return  response
*/

actionPerform: async (req, res) => {
    try {
        let data = await subscriptionModel.findOne({ _id: req.query._id })
        if (!data) return res.status(404).send({ responseMessage: ErrorMessage.NOT_FOUND })
        let updateData = await subscriptionModel.findOneAndUpdate({ _id: data._id }, { $set: req.query }, { new: true })
        if (!updateData) { return res.status(500).send({ responseMessage: ErrorMessage.INTERNAL_ERROR }) }
        return res.status(200).send({ responseMessage: "Action performed" })

    }
    catch (e) {
        return res.status(501).send({ responseMessage: ErrorMessage.SOMETHING_WRONG, e })
    }
},


subscriptionList: async (req, res) => {
    try {  
        let totalList;
        let pageNumber = +req.query.pageNumber
        let limit = +req.query.limit
        let criteria = { status: { $ne: "DELETE" }}
        if (req.query.search) {
            criteria.$or = [{ name: { $regex: req.query.search, $options: 'i' } },
            { name: { $regex: req.query.search, $options: 'i' } }]
        }
        if (req.query.status) {
            criteria.status = +req.query.status
        }
        totalList = await subscriptionModel.find(criteria).countDocuments();
        result = await subscriptionModel.find(criteria).sort({ createdAt: -1 })
            .skip((limit * pageNumber) - limit).limit(limit).lean()
        if (!result) {
            return res.status(404).send({ responseMessage: ErrorMessage.NOT_FOUND })
        }
        console.log("========documentList",result)
    var documentList = [];
    for (item of result) {
        var totalSubscribeUser = await userModel.countDocuments({
            subscriptionId:item._id
        });
        console.log("=======totalSubscribeUser",totalSubscribeUser)
        documentList.push({
            _id: item["_id"],
            status: item["status"],
            name: item["name"],
            price: item["price"],
            status: item["status"],
            applicability: item["applicability"],
            minutesOfAudioCalls: item["minutesOfAudioCalls"],
            minutesOfVideoCalls: item["minutesOfVideoCalls"],
            numberOfSecondrySpecialty: item["numberOfSecondrySpecialty"],
            numberOfLeads: item["numberOfLeads"],
            numberOfMessages: item["numberOfMessages"],
            days_duration: item["days_duration"],
            session_numbers: item["session_numbers"],
            subscribeUserCount : totalSubscribeUser,
            isFeatured: item["isFeatured"],
            createdAt: item["createdAt"],
            updatedAt: item["updatedAt"],
        });
    }
console.log("====result",documentList)
         return res.status(200).send({ responseMessage: SuccessMessage.DATA_FOUND,documentList, totalList})


    } catch (e) {
        console.log("======e",e)
        return res.status(501).send({ responseMessage: ErrorMessage.SOMETHING_WRONG, e })
    }
},

viewSubscription: async (req, res) => {
    let query = { _id: req.params._id }
    let data = await subscriptionModel.findOne(query)
    if (!data)
        return res.status(404).send({ responseMessage: ErrorMessage.NOT_FOUND })
    else {
        return res.status(200).send({ responseMessage: SuccessMessage.DATA_FOUND, data })
    }
},



}




// storeData.map((e) => {
//     e["categoryName"] = e.category[0].categoryName
//     return e
// })