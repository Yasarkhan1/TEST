const ratingModel = require('../../model/rating')
const { ErrorMessage } = require('../../helper/message');
const { SuccessMessage } = require('../../helper/message');



module.exports = {


/**
* Function Name :actionPerform API
* Description : actionPerform   API 
* @return  response
*/

actionPerform: async (req, res) => {
    try {
        let data = await ratingModel.findOne({ _id: req.query._id })
        if (!data) return res.status(404).send({ responseMessage: ErrorMessage.NOT_FOUND })
        let updateData = await ratingModel.findOneAndUpdate({ _id: data._id }, { $set: { status:"DELETE"} }, { new: true })
        if (!updateData) { return res.status(500).send({ responseMessage: ErrorMessage.INTERNAL_ERROR }) }
        return res.status(200).send({ responseMessage: "Action performed" })
    }
    catch (e) {
        return res.status(501).send({ responseMessage: ErrorMessage.SOMETHING_WRONG, e })
    }
},


reviewList: async (req, res) => {
    try {
        console.log("============")
        let documentList;
        let totalList;
        let pageNumber = +req.query.pageNumber
        let limit = +req.query.limit
        let criteria = { status: "ACTIVE"}
        totalList = await ratingModel.find(criteria).countDocuments();
        documentList = await ratingModel.find(criteria).populate('userId doctorId',"firstName lastName profilePic fullName").sort({ createdAt: -1 })
            .skip((limit * pageNumber) - limit).limit(limit).lean()
        if (!documentList) {
            return res.status(404).send({ responseMessage: ErrorMessage.NOT_FOUND })
        }
        return res.status(200).send({ responseMessage: SuccessMessage.DATA_FOUND, documentList, totalList})


    } catch (e) {
        return res.status(501).send({ responseMessage: ErrorMessage.SOMETHING_WRONG, e })
    }
},

viewReview: async (req, res) => {
    let query = { _id: req.params._id }
    let data = await ratingModel.findOne(query).populate('userId','firstNmae lastName  profilePic createdAt email location')
    .populate({
        path: 'doctorId',
        model: 'user',
        select: 'fullName experience_in_years experience_in_months primary_specialtyId profilePic createdAt ',
        populate: [{
            path: 'secondry_specialty',
            model: 'specialty',
            select: 'secondry_specialty'
        },
        {
            path: 'primary_specialtyId',
            model: 'primary_specialty',
            select: 'primary_specialty',

        }]
    })
    if (!data)
        return res.status(404).send({ responseMessage: ErrorMessage.NOT_FOUND })
    else {
        return res.status(200).send({ responseMessage: SuccessMessage.DATA_FOUND, data })
    }
},


}