const notification = require('../../model/notification')
const user = require('../../model/user')
const commonFunction = require('../../utility/common')
const { ErrorMessage } = require('../../helper/message');
const { SuccessMessage } = require('../../helper/message');



module.exports = {

    sendNotification: async (req, res) => {
        let userId = req.userId
        let notificationDataList = [];
        var query;
        if(req.body.userType =="PATIENT" || req.body.userType == "DOCTOR"){
         query = { status: "ACTIVE", userType: req.body.userType }
        }else{
            query = { status: "ACTIVE", userType: { $in: ["PATIENT", "DOCTOR"] } }
        }
        let userData = await user.find(query)
        let tokenData = userData.map((e) => e.deviceToken)
        let userIds = userData.map((e) => e._id)
        let pushTitle = `${req.body.subject}`
        let pushBody = `${req.body.message}`
        tokenData.forEach(x => {
            commonFunction.pushNotification(x, pushTitle, pushBody)
        })
        userIds.forEach((e, index) => {
            console.log(e);
            let notify = new notification({
                userId: e,
                title: req.body.subject,
                body: req.body.message,
                senderId: userId,
                notificationType:"BROADCAST",
                isAdminInvolved: true
            })
            notify.save(async (notifficationErr, notificationData) => {
                if (notifficationErr) return res.status(500).send({responseMessage: ErrorMessage.INTERNAL_ERROR, notifficationErr })
                else {
                    notificationDataList.push(notificationData);
                    if (index === userIds.length - 1) {
                        return res.status(200).send({responseMessage: "Message send successfully" })
                    }
                }
            })
        })


    },

    sentNotificationList: async (req, res) => {
        let documentList;
        let totalNotification = 0;
        let query = { isAdminInvolved: true ,status:"ACTIVE" }
        let pageNumber = +req.query.pageNumber || 1
        let limit = +req.query.limit || 1000000
        totalNotification = await notification.find(query).countDocuments();
        documentList = await notification.find(query).populate('userId', "firstName lastName fullName email profilePic userType").sort({ createdAt: -1 })
            .skip((limit * pageNumber) - limit).limit(limit).lean()
        if (!documentList.length) {
            return res.status(404).send({ responseCode: 404, responseMessage: ErrorMessage.NOT_FOUND })
        }
        return res.status(200).send({ responseCode: 200, responseMessage: SuccessMessage.DATA_FOUND, documentList, totalNotification })
    },

    viewNotification: async (req, res) => {
        let query = { _id: req.params._id }
        notificationData = await notification.findOne(query).populate('userId senderId', "firstName lastName fullName email profilePic userType")
        if (!notificationData) {
            return res.status(404).send({ responseCode: 404, responseMessage: ErrorMessage.NOT_FOUND })
        }
        return res.status(200).send({ responseCode: 200, responseMessage: SuccessMessage.DATA_FOUND, notificationData })
    },

    deleteNotification: async (req, res) => {
        try {
            let data = await notification.findOne({ _id: req.params._id })
            if (!data) return res.status(404).send({responseMessage: ErrorMessage.NOT_FOUND })
            let updateData = await notification.findOneAndUpdate({ _id: data._id }, { $set: { status: "DELETE"} }, { new: true })
            if (!updateData) return res.status(500).send({responseMessage: ErrorMessage.INTERNAL_ERROR })
            return res.status(200).send({responseMessage: "Deleted Successfully" })

        }
        catch (e) {
            return res.status(501).send({ responseMessage: ErrorMessage.SOMETHING_WRONG, e })
        }
    },
}
