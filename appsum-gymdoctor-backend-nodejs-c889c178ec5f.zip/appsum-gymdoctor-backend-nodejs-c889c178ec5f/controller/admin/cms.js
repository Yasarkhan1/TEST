
const cms = require('../../model/cms')
const { ErrorMessage } = require('../../helper/message');
const { SuccessMessage } = require('../../helper/message');

module.exports = {


    viewContent: async (req, res) => {
        try {
            let data = await cms.findOne({ _id: req.params._id })
            if (!data) return res.status(404).send({ responseMessage: ErrorMessage.NOT_FOUND })
            return res.status(200).send({ responseMessage: SuccessMessage.DATA_FOUND, data })
        }
        catch (e) {
            return res.status(501).send({ responseMessage: ErrorMessage.SOMETHING_WRONG, e })
        }
    },
    
    
    contentList: async (req, res) => {
        try {
            let documentList;
            let criteria = { status: { $ne: "DELETE" } }
            documentList = await cms.find(criteria)
            if (!documentList) {
                return res.status(404).send({ responseMessage: ErrorMessage.NOT_FOUND })
            }
            return res.status(200).send({ responseMessage: SuccessMessage.DATA_FOUND, documentList })
        } catch (e) {
            return res.status(501).send({ responseMessage: ErrorMessage.SOMETHING_WRONG, e })
        }
    },
    
    editContent: async (req, res) => {
        try {
            let data = await cms.findOne({ _id: req.query._id, status: { $ne: "DELETE" } })
            if (!data) return res.status(404).send({ responseMessage: ErrorMessage.NOT_FOUND })
            let updateData = await cms.findOneAndUpdate({ _id: data._id }, { $set: req.body }, { new: true })
            if (!updateData) return res.status(500).send({ responseMessage: ErrorMessage.INTERNAL_ERROR })
            return res.status(200).send({ responseMessage: SuccessMessage.DATA_SAVED, updateData })
        }
        catch (e) {
            return res.status(501).send({ responseMessage: ErrorMessage.SOMETHING_WRONG, e })
        }
    },


}