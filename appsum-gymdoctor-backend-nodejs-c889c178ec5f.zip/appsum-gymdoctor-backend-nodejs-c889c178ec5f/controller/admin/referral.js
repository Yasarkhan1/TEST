const referralAmountModel = require('../../model/referralAmount')
const referralModel = require('../../model/referral')



const { commonResponse: response } = require('../../helper/commonResponseHandler');
const { ErrorMessage } = require('../../helper/message');
const { SuccessMessage } = require('../../helper/message');
const { ErrorCode } = require('../../helper/statusCode');
const { SuccessCode } = require('../../helper/statusCode');
const referral = require('../../model/referral');


module.exports = {

    referralList: async (req, res) => {
        try {
            let documentList;
            let totalList;
            let pageNumber = +req.query.pageNumber
            let limit = +req.query.limit
            let criteria = {status:{ $ne:"Pending"}}
            totalList = await referralModel.find(criteria).countDocuments();
            documentList = await referralModel.find(criteria).populate('userId joinerId', 'firstName lastName fullName profilePic email userType').sort({ createdAt: -1 })
                .skip((limit * pageNumber) - limit).limit(limit).lean()
            if (!documentList) {
                return res.status(404).send({ responseMessage: ErrorMessage.NOT_FOUND })
            }
            return res.status(200).send({ responseMessage: SuccessMessage.DATA_FOUND, documentList, totalList })


        } catch (e) {
            return res.status(501).send({ responseMessage: ErrorMessage.SOMETHING_WRONG, e })
        }
    },

    viewReferral: async (req, res) => {
        let query = { _id: req.params._id }
        let data = await referral.findOne(query).populate('userId', 'firstName lastName fullName profilePic userType')
        if (!data)
            return res.status(404).send({ responseMessage: ErrorMessage.NOT_FOUND })
        else {
            return res.status(200).send({ responseMessage: SuccessMessage.DATA_FOUND, data })
        }
    },

    getInvitationAmount: async (req, res) => {
        let query = {}
        let data = await referralAmountModel.findOne(query)
        if (!data)
            return res.status(404).send({ responseMessage: ErrorMessage.NOT_FOUND })
        else {
            return res.status(200).send({ responseMessage: SuccessMessage.DATA_FOUND, data })
        }
    },

    updateInvitationAmount: async (req, res) => {
        try {
            let data = await referralAmountModel.findOne({ _id: req.body._id })
            if (!data) return res.status(404).send({ responseMessage: ErrorMessage.NOT_FOUND })
            let updateData = await referralAmountModel.findOneAndUpdate({ _id: data._id }, { $set: { amount: req.body.amount } }, { new: true })
            if (!updateData) return res.status(500).send({ responseMessage: ErrorMessage.INTERNAL_ERROR })
            return res.status(200).send({ responseMessage: SuccessMessage.DATA_SAVED, updateData })
        }
        catch (e) {
            return res.status(501).send({ responseMessage: ErrorMessage.SOMETHING_WRONG, e })
        }
    },


}