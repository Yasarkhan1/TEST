const specialtyModel = require('../../model/primarySpecialties')


const { commonResponse: response } = require('../../helper/commonResponseHandler');
const { ErrorMessage } = require('../../helper/message');
const { SuccessMessage } = require('../../helper/message');
const { ErrorCode } = require('../../helper/statusCode');
const { SuccessCode } = require('../../helper/statusCode');
const commonFunction = require('../../utility/common')




module.exports = {

    /**
 * Function Name :addSpecialty
 * Description   : add specialty by admin
 *
 * @return response
*/
addSpecialty: async (req, res) => {
    try {
        let query = { primary_specialty: req.body.primary_specialty, status: { $ne: "DELETE" } }
        let data = await specialtyModel.findOne(query)
        if (data) return res.status(409).send({ responseMessage: ErrorMessage.ALREADY_EXITS })
        let specialtyData = new specialtyModel(req.body);
        specialtyData.save((error, result) => {
            if (error) return res.status(500).send({ responseMessage: ErrorMessage.INTERNAL_ERROR })
            return res.status(200).send({ responseMessage: SuccessMessage.DATA_SAVED, result })
        })
    }
    catch (e) {
        return res.status(501).send({ responseMessage: ErrorMessage.SOMETHING_WRONG, e })
    }
},

/**
* Function Name :editSpecialty
* Description   :edit specialty  by admin
*
* @return response
*/

editSpecialty: async (req, res) => {
    try {
        let data = await specialtyModel.findOne({ _id: req.query._id, status: { $ne: "DELETE" } })
        if (!data) return res.status(404).send({ responseMessage: ErrorMessage.NOT_FOUND })
        let updateData = await specialtyModel.findOneAndUpdate({ _id: data._id }, { $set: req.body }, { new: true })
        if (!updateData) return res.status(500).send({ responseMessage: ErrorMessage.INTERNAL_ERROR })
        return res.status(200).send({ responseMessage: SuccessMessage.DATA_SAVED, updateData })
    }
    catch (e) {
        return res.status(501).send({ responseMessage: ErrorMessage.SOMETHING_WRONG, e })
    }
},



/**
* Function Name :actionPerform API
* Description : actionPerform   API 
* @return  response
*/

actionPerform: async (req, res) => {
    try {
        let data = await specialtyModel.findOne({ _id: req.query._id })
        if (!data) return res.status(404).send({ responseMessage: ErrorMessage.NOT_FOUND })
        let updateData = await specialtyModel.findOneAndUpdate({ _id: data._id }, { $set: req.query }, { new: true })
        if (!updateData) { return res.status(500).send({ responseMessage: ErrorMessage.INTERNAL_ERROR }) }
        return res.status(200).send({ responseMessage: "Action performed" })

    }
    catch (e) {
        return res.status(501).send({ responseMessage: ErrorMessage.SOMETHING_WRONG, e })
    }
},


specialtyList: async (req, res) => {
    try {
        let documentList;
        let totalList;
        let pageNumber = +req.query.pageNumber
        let limit = +req.query.limit
        let criteria = { status: { $ne: "DELETE" }}
        if (req.query.search) {
            criteria.$or = [{ primary_specialty: { $regex: req.query.search, $options: 'i' } },
            { image: { $regex: req.query.search, $options: 'i' } }]
        }
        if (req.query.status) {
            criteria.status = +req.query.status
        }
        totalList = await specialtyModel.find(criteria).countDocuments();
        documentList = await specialtyModel.find(criteria).sort({ createdAt: -1 })
            .skip((limit * pageNumber) - limit).limit(limit).lean()
        if (!documentList) {
            return res.status(404).send({ responseMessage: ErrorMessage.NOT_FOUND })
        }
        return res.status(200).send({ responseMessage: SuccessMessage.DATA_FOUND, documentList, totalList})


    } catch (e) {
        return res.status(501).send({ responseMessage: ErrorMessage.SOMETHING_WRONG, e })
    }
},

viewSpecialty: async (req, res) => {
    let query = { _id: req.params._id }
    let data = await specialtyModel.findOne(query)
    if (!data)
        return res.status(404).send({ responseMessage: ErrorMessage.NOT_FOUND })
    else {
        return res.status(200).send({ responseMessage: SuccessMessage.DATA_FOUND, data })
    }
},





}