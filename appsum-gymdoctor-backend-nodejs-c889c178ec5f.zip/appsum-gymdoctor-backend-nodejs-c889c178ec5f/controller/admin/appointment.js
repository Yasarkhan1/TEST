const appointmentModel = require('../../model/appointment')
const { ErrorMessage } = require('../../helper/message');
const { SuccessMessage } = require('../../helper/message');




module.exports = {

    appointmentList: async (req, res) => {
        try {
            let documentList;
            let totalList;
            let pageNumber = +req.query.pageNumber
            let limit = +req.query.limit
            let criteria = {  status: { $in: [ "pending", "cancelled","accepted"] } }
            totalList = await appointmentModel.find(criteria).countDocuments();
            documentList = await appointmentModel.find(criteria,{ appointmentStartTime:1,appointmentEndTime:1,status:1})
                .populate('patientId', 'firstName lastName profilePic')
                .populate({
                    path: 'serviceProviderId',
                    model: 'user',
                    select: 'fullName profilePic primary_specialtyId',
                    populate: {
                        path: 'primary_specialtyId',
                        model: 'primary_specialty',
                        select: 'primary_specialty'
                    }
                })
                .sort({ createdAt: -1 })
                .skip((limit * pageNumber) - limit).limit(limit).lean()
            if (!documentList) {
                return res.status(404).send({ responseMessage: ErrorMessage.NOT_FOUND })
            }
            return res.status(200).send({ responseMessage: SuccessMessage.DATA_FOUND, documentList, totalList })
        } catch (e) {
            console.log(e)
            return res.status(501).send({ responseMessage: ErrorMessage.SOMETHING_WRONG, e })
        }
    },



}