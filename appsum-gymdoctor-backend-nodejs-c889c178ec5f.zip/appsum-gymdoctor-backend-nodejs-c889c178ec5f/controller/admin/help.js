const helpModel = require('../../model/help')
const helpMessage = require('../../model/helpMessage')
const user = require('../../model/user')
const notification = require('../../model/notification')
const commonFunction = require('../../utility/common')
const { ErrorMessage } = require('../../helper/message');
const { SuccessMessage } = require('../../helper/message');



module.exports = {


/**
* Function Name :actionPerform API
* Description : actionPerform   API 
* @return  response
*/

actionPerform: async (req, res) => {
    try {
        let data = await helpModel.findOne({ _id: req.query._id })
        if (!data) return res.status(404).send({ responseMessage: ErrorMessage.NOT_FOUND })
        let updateData = await helpModel.findOneAndUpdate({ _id: data._id }, { $set: { status:"DELETE"} }, { new: true })
        if (!updateData) { return res.status(500).send({ responseMessage: ErrorMessage.INTERNAL_ERROR }) }
        return res.status(200).send({ responseMessage: "Action performed" })

    }
    catch (e) {
        return res.status(501).send({ responseMessage: ErrorMessage.SOMETHING_WRONG, e })
    }
},


helpRequestList: async (req, res) => {
    try {
        let documentList;
        let totalList;
        let pageNumber = +req.query.pageNumber
        let limit = +req.query.limit
        let criteria = { status: { $ne: "DELETE" }}
        if (req.query.search) {
            criteria.$or = [{ subject: { $regex: req.query.search, $options: 'i' } },
            { userType: { $regex: req.query.search, $options: 'i' } }]
        }
        if (req.query.status) {
            criteria.status = +req.query.status
        }
        totalList = await helpModel.find(criteria).countDocuments();
        documentList = await helpModel.find(criteria).populate('userId').sort({ createdAt: -1 })
            .skip((limit * pageNumber) - limit).limit(limit).lean()
        if (!documentList) {
            return res.status(404).send({ responseMessage: ErrorMessage.NOT_FOUND })
        }
        return res.status(200).send({ responseMessage: SuccessMessage.DATA_FOUND, documentList, totalList})


    } catch (e) {
        return res.status(501).send({ responseMessage: ErrorMessage.SOMETHING_WRONG, e })
    }
},

viewHelpRequest: async (req, res) => {
    let query = { _id: req.params._id }
    let data = await helpModel.findOne(query).populate('userId')
    if (!data)
        return res.status(404).send({ responseMessage: ErrorMessage.NOT_FOUND })
    else {
        await helpModel.findOneAndUpdate({ _id: data._id }, { $set: { isRead : true} }, { new: true })
        let documentList;
        let totalList;
        let pageNumber = +req.query.pageNumber || 1
        let limit = +req.query.limit || 10000
        let criteria = { ticketId : data._id,status: { $ne: "DELETE" }}
        totalList = await helpMessage.find(criteria).countDocuments();
        documentList = await helpMessage.find(criteria).populate('userId adminId','firstName lastName fullName profilePic userType').sort({ createdAt:1 })
            .skip((limit * pageNumber) - limit).limit(limit).lean()
        if (!documentList) {
            return res.status(404).send({ responseMessage: ErrorMessage.NOT_FOUND })
        }
        return res.status(200).send({ responseMessage: SuccessMessage.DATA_FOUND,data, documentList, totalList})
    }
},


replyOnRequest: async (req, res) => {
    try {
        let userId = req.userId
        let data = await helpModel.findOne({ _id: req.body._id, status: { $ne: "DELETE" } })
        let userData = await user.findOne({ _id: data.userId, status: "ACTIVE" })
        if (!data) return res.status(404).send({ responseMessage: ErrorMessage.NOT_FOUND })
        let obj = {
            adminId : userId,
            ticketId : data._id,
            message : req.body.message,
            replyBy:"ADMIN"
        }
        let helpData = new helpMessage(obj);
        helpData.save((error, result) => {
            console.log(error)
            if (error) return res.status(500).send({ responseMessage: ErrorMessage.INTERNAL_ERROR })
            const pushTitle = "Acknowledge Help Ticket"
            const pushBody = "You have a new unread message. Please check your help box"
            commonFunction.pushNotification(userData.deviceToken, pushTitle, pushBody)
            let notify = {
                userId: userData._id,
                title: "Acknowledge Help Ticket",
                body:  "You have a new unread message. Please check your help box",
                notificationType: 'HELP_MESSAGE'
            }
            let notiData = new notification(notify)
            notiData.save()
            return res.status(200).send({ responseMessage: SuccessMessage.DATA_SAVED, result })
        })
    }
    catch (e) {
        console.log(e)
        return res.status(501).send({ responseMessage: ErrorMessage.SOMETHING_WRONG, e })
    }
},


}