const userModel = require('../../model/user')
const { commonResponse: response } = require('../../helper/commonResponseHandler');
const { ErrorMessage } = require('../../helper/message');
const { SuccessMessage } = require('../../helper/message');




module.exports = {

    patientList: async (req, res) => {
        try {
            let documentList;
            let totalList;
            let pageNumber = +req.query.pageNumber
            let limit = +req.query.limit
            let criteria = { status: { $ne: "DELETE" }, userType: "PATIENT" }
            if (req.query.search) {
                criteria.$or = [{ firstName: { $regex: req.query.search, $options: 'i' } },
                { lastName: { $regex: req.query.search, $options: 'i' } },
                { email: { $regex: req.query.search, $options: 'i' } },
                { mobileNumber: { $regex: req.query.search, $options: 'i' } }]
            }
            totalList = await userModel.find(criteria).countDocuments();
            documentList = await userModel.find(criteria,
                {
                    firstName: 1, lastName: 1, profilePic: 1,
                    expiryDate:1, countryCode: 1, mobileNumber: 1, email: 1, location: 1,date_of_birth:1,
                    status:1
                })
                .populate('subscriptionId', 'name').sort({ createdAt: -1 })
                .skip((limit * pageNumber) - limit).limit(limit).lean()
            if (!documentList) {
                return res.status(404).send({ responseMessage: ErrorMessage.NOT_FOUND })
            }
            return res.status(200).send({ responseMessage: SuccessMessage.DATA_FOUND, documentList, totalList })


        } catch (e) {
            console.log(e)
            return res.status(501).send({ responseMessage: ErrorMessage.SOMETHING_WRONG, e })
        }
    },

    viewPatient: async (req, res) => {
        let query = { _id: req.params._id }
        let userData = await userModel.findOne(query).populate('subscriptionId', 'name')
        if (!userData)
            return res.status(404).send({ responseMessage: ErrorMessage.NOT_FOUND })
        else {
            return res.status(200).send({ responseMessage: SuccessMessage.DATA_FOUND, userData })
        }
    },



    /**
* Function Name :actionPerform API
* Description : actionPerform   API 
* @return  response
*/

    actionPerform: async (req, res) => {
        try {
            let data = await userModel.findOne({ _id: req.query._id })
            if (!data) return res.status(404).send({ responseMessage: ErrorMessage.NOT_FOUND })
            let updateData = await userModel.findOneAndUpdate({ _id: data._id }, { $set: req.query }, { new: true })
            if (!updateData) { return res.status(404).send({ responseMessage: ErrorMessage.NOT_FOUND }) }
            return res.status(200).send({ responseMessage: "Action performed" })
        }
        catch (e) {
            return res.status(501).send({ responseMessage: ErrorMessage.SOMETHING_WRONG, e })
        }
    },

}