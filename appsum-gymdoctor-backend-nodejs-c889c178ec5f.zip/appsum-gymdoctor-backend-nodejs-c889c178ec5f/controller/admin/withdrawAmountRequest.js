const withdrawRequestModel = require('../../model/withdrawAmount')
const walletModel = require('../../model/wallet')
const notification = require('../../model/notification')
const userModel = require('../../model/user')
const user = require('../../model/user')
const commonFunction = require('../../utility/common')
const { ErrorMessage } = require('../../helper/message');
const { SuccessMessage } = require('../../helper/message');



module.exports = {


    list: async (req, res) => {
        try {
            let totalList = 0;
            let pageNumber = +req.query.pageNumber || 1
            let limit = +req.query.limit || 100000
            let query = {status:"ACTIVE"}
            totalList = await withdrawRequestModel.find(query).countDocuments();
            let data = await withdrawRequestModel.find(query).populate('userId', 'fullName email profilePic')
                .sort({ createdAt: -1 })
                .skip((limit * pageNumber) - limit).limit(limit).lean();
            if (!data) {
                return res.status(404).send({ responseCode: 404, responseMessage: ErrorMessage.NOT_FOUND })
            } else {
                return res.status(200).send({ responseCode: 200, responseMessage: SuccessMessage.DATA_FOUND, data, totalList })

            }
        } catch (e) {
            return res.status(501).send({ responseCode: 501, responseMessage: ErrorMessage.SOMETHING_WRONG, e })
        }
    },


    view: async (req, res) => {
        let query = { _id: req.params._id }
        let data = await withdrawRequestModel.findOne(query).populate('userId', 'fullName profilePic email userType').lean()
        if (!data)
            return res.status(404).send({ responseMessage: ErrorMessage.NOT_FOUND })
        else {
            let walletData = await walletModel.findOne({ userId: data.userId })
            console.log("===========walletData",walletData)
            let balanceAmount = walletData.totalBalance
            console.log("======balanceAmount",balanceAmount)
            data['balanceAmount'] = balanceAmount
            return res.status(200).send({ responseMessage: SuccessMessage.DATA_FOUND, data })
        }
    },


    /**
* Function Name :Payment paid and update wallet amount
* Description   :
* @return responses
*/

    paymentDone: async (req, res) => {
        try {
            let query = { _id: req.params._id }
            let requestData = await withdrawRequestModel.findOne(query)
            let walletResult = await walletModel.findOne({
                userId: requestData.userId
            })

            if (walletResult.totalBalance >= requestData.amount) {
                let balance = walletResult.totalBalance - requestData.amount
                let updateData = await walletModel.findOneAndUpdate({ _id: walletResult._id }, { $set: { totalBalance: balance } }, { new: true })
                let paymentUpdate = await withdrawRequestModel.findOneAndUpdate({ _id: requestData._id }, { $set: { paymentStatus: "PAID" } }, { new: true })
                if (paymentUpdate) {
                    let userData = await userModel.findOne({
                        _id: requestData.userId
                    })
                    const pushTitle = "PAYMENT APPROVED"
                    const pushBody = "Admin approved your withdraw amount request"
                    commonFunction.pushNotification(userData.deviceToken, pushTitle, pushBody)
                    let notify = {
                        userId: requestData.userId,
                        title: "payment approved",
                        body: "Admin approved your withdraw amount request",
                        notificationType: 'PAYMENT_WITHDRAW'
                    }
                    let notiData = new notification(notify)
                    notiData.save((notiErr, notiSaveData) => {
                        if (notiErr) return res.status(500).send({ responseMessage: ErrorMessage.INTERNAL_ERROR, notiErr })
                        return res.status(200).send({ responseMessage: "Paid successfully" })

                    })

                }
            } else {
                return res.status(500).send({
                    responseMessage: "User does not have  sufficient balance in wallet."
                })
            }
        } catch (e) {
            console.log("catch", e)
            return res.status(501).send({
                responseMessage: ErrorMessage.SOMETHING_WRONG,
                e
            })
        }
    },


    /**
* Function Name :Reject withdraw request
* Description   :
* @return responses
*/

    rejectRequest: async (req, res) => {
        try {
            let query = { _id: req.params._id }
            let requestData = await withdrawRequestModel.findOne(query)

            let update = await withdrawRequestModel.findOneAndUpdate({ _id: requestData._id }, { $set: { paymentStatus: "REJECTED" } }, { new: true })
            if (update) {
                let userData = await userModel.findOne({
                    _id: requestData.userId
                })
                const pushTitle = "PAYMENT REJECTED"
                const pushBody = "Admin rejected your withdraw amount request"
                commonFunction.pushNotification(userData.deviceToken, pushTitle, pushBody)
                let notify = {
                    userId: requestData.userId,
                    title: "payment approved",
                    body: "Admin rejected your withdraw amount request",
                    notificationType: 'PAYMENT_WITHDRAW'
                }
                let notiData = new notification(notify)
                notiData.save((notiErr, notiSaveData) => {
                    if (notiErr) return res.status(500).send({ responseMessage: ErrorMessage.INTERNAL_ERROR, notiErr })
                    return res.status(200).send({ responseMessage: "Rejected successfully" })

                })

            }
        } catch (e) {
            console.log("catch", e)
            return res.status(501).send({
                responseMessage: ErrorMessage.SOMETHING_WRONG,
                e
            })
        }
    },
}
