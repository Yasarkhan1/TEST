const invoiceModel = require('../../model/invoiceModel')
const { ErrorMessage } = require('../../helper/message');
const { SuccessMessage } = require('../../helper/message');



module.exports = {

invoiceList: async (req, res) => {
    try {
        let documentList;
        let totalList;
        let pageNumber = +req.query.pageNumber
        let limit = +req.query.limit
        let criteria = { status: { $ne: "DELETE" }}
        totalList = await invoiceModel.find(criteria).countDocuments();
        documentList = await invoiceModel.find(criteria).populate('invoiceFrom','firstName lastName fullName profilePic userType').sort({ createdAt: -1 })
            .skip((limit * pageNumber) - limit).limit(limit).lean()
        if (!documentList) {
            return res.status(404).send({ responseMessage: ErrorMessage.NOT_FOUND })
        }
        return res.status(200).send({ responseMessage: SuccessMessage.DATA_FOUND, documentList, totalList})


    } catch (e) {
        return res.status(501).send({ responseMessage: ErrorMessage.SOMETHING_WRONG, e })
    }
},


viewInvoice: async (req, res) => {
    let query = { _id: req.params.id }
    let data = await invoiceModel.findOne(query).populate('invoiceFrom',' firstName lastName fullName location')
    .populate('subscriptionId','name')
    .populate('laboratoryId','name')
    if (!data)
        return res.status(404).send({ responseMessage: ErrorMessage.NOT_FOUND })
    else {
        return res.status(200).send({ responseMessage: SuccessMessage.DATA_FOUND, data })
    }
},

}