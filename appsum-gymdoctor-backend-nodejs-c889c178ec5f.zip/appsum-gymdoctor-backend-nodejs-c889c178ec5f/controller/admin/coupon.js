// const user = require('../../model/user')
const adminModel = require('../../model/admin')
const couponModel = require('../../model/coupon')

const { commonResponse: response } = require('../../helper/commonResponseHandler');
const { ErrorMessage } = require('../../helper/message');
const { SuccessMessage } = require('../../helper/message');
const { ErrorCode } = require('../../helper/statusCode');
const { SuccessCode } = require('../../helper/statusCode');
const commonFunction = require('../../utility/common')


module.exports = {

    /**
 * Function Name :create coupon
 * Description   : add coupon by admin
 *
 * @return response
*/
addCoupon: async (req, res) => {
    try {
        let query = { code: req.body.code, status: { $ne: "DELETE" } }
        let data = await couponModel.findOne(query)
        if (data) return res.status(409).send({ responseMessage: ErrorMessage.ALREADY_EXITS })
        let dataObj = new couponModel(req.body);
        dataObj.save((error, result) => {
            if (error) return res.status(500).send({ responseMessage: ErrorMessage.INTERNAL_ERROR })
            return res.status(200).send({ responseMessage: SuccessMessage.DATA_SAVED, result })
        })
    }
    catch (e) {
        return res.status(501).send({ responseMessage: ErrorMessage.SOMETHING_WRONG, e })
    }
},

/**
* Function Name :editCoupon
* Description   :edit coupon  by admin
*
* @return response
*/

editCoupon: async (req, res) => {
    try {
        let data = await couponModel.findOne({ _id: req.query._id, status: { $ne: "DELETE" } })
        if (!data) return res.status(404).send({ responseMessage: ErrorMessage.NOT_FOUND })
        let updateData = await couponModel.findOneAndUpdate({ _id: data._id }, { $set: req.body }, { new: true })
        if (!updateData) return res.status(500).send({ responseMessage: ErrorMessage.INTERNAL_ERROR })
        return res.status(200).send({ responseMessage: SuccessMessage.DATA_SAVED, updateData })
    }
    catch (e) {
        return res.status(501).send({ responseMessage: ErrorMessage.SOMETHING_WRONG, e })
    }
},



/**
* Function Name :actionPerform API
* Description : actionPerform   API 
* @return  response
*/

actionPerform: async (req, res) => {
    try {
        let data = await couponModel.findOne({ _id: req.query._id })
        if (!data) return res.status(404).send({ responseMessage: ErrorMessage.NOT_FOUND })
        let updateData = await couponModel.findOneAndUpdate({ _id: data._id }, { $set: req.query }, { new: true })
        if (!updateData) { return res.status(500).send({ responseMessage: ErrorMessage.INTERNAL_ERROR }) }
        return res.status(200).send({ responseMessage: "Action performed" })

    }
    catch (e) {
        return res.status(501).send({ responseMessage: ErrorMessage.SOMETHING_WRONG, e })
    }
},


couponList: async (req, res) => {
    try {
        let documentList;
        let totalList;
        let pageNumber = +req.query.pageNumber
        let limit = +req.query.limit
        let criteria = { status: { $ne: "DELETE" }}
        if (req.query.search) {
            criteria.$or = [{ code: { $regex: req.query.search, $options: 'i' } },
            { couponType: { $regex: req.query.search, $options: 'i' } }]
        }
        if (req.query.status) {
            criteria.status = +req.query.status
        }
        totalList = await couponModel.find(criteria).countDocuments();
        documentList = await couponModel.find(criteria).sort({ createdAt: -1 })
            .skip((limit * pageNumber) - limit).limit(limit).lean()
        if (!documentList) {
            return res.status(404).send({ responseMessage: ErrorMessage.NOT_FOUND })
        }
        return res.status(200).send({ responseMessage: SuccessMessage.DATA_FOUND, documentList, totalList})


    } catch (e) {
        return res.status(501).send({ responseMessage: ErrorMessage.SOMETHING_WRONG, e })
    }
},

viewcoupon: async (req, res) => {
    let query = { _id: req.params._id }
    let data = await couponModel.findOne(query)
    if (!data)
        return res.status(404).send({ responseMessage: ErrorMessage.NOT_FOUND })
    else {
        return res.status(200).send({ responseMessage: SuccessMessage.DATA_FOUND, data })
    }
},



}