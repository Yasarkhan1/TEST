// const user = require('../../model/user')
const adminModel = require('../../model/admin')
const { commonResponse: response } = require('../../helper/commonResponseHandler');
const { ErrorMessage } = require('../../helper/message');
const { SuccessMessage } = require('../../helper/message');
const { ErrorCode } = require('../../helper/statusCode');
const { SuccessCode } = require('../../helper/statusCode');
const commonFunction = require('../../utility/common')
const welcomeEmail = require('../../utility/admin/subadminRegistrationEmail')
const bcrypt = require("bcrypt-nodejs");
const salt = bcrypt.genSaltSync(10);
var jwt = require('jsonwebtoken');




module.exports = {


    addSubadmin: async (req, res) => {
        let query = { $and: [{ $or: [{ email: req.body.email }, { mobileNumber: req.body.mobileNumber }] }, { status: { $ne: "DELETE" } }] }
        let userData = await adminModel.findOne(query)
        if (userData) {
            if (req.body.email == userData.email)
                return res.status(409).send({ responseMessage: ErrorMessage.EMAIL_EXIST })
            else {
                return res.status(409).send({ responseMessage: ErrorMessage.MOBILE_EXIST })
            }
        } else {
            var temPassword = commonFunction.generateString(10).trim()
            let bcryptData = bcrypt.hashSync(temPassword)
            req.body.password = bcryptData
            req.body.userType = "SUBADMIN"
            let subject = "Congratulations"
            let name = req.body.firstName
            let subadmin = new adminModel(req.body);
            subadmin.save((error, data) => {
                if (error) return res.status(500).send({ responseMessage: ErrorMessage.INTERNAL_ERROR, error })
                else {
                   welcomeEmail.subadminWelcomeEmail(req.body.email, subject, name,temPassword)
                    return res.status(200).send({ responseMessage: "Subadmin added successfully", data })

                }
            })

        }
    },
    subadminList: async (req, res) => {
        try {
            let documentList;
            let totalList;
            let totalSubadmin;
            let totalActive;
            let totalInactive;
            let pageNumber = +req.query.pageNumber
            let limit = +req.query.limit
            let criteria = { status: { $ne: "DELETE" }, userType: "SUBADMIN" }
            if (req.query.search) {
                criteria.$or = [{ firstName: { $regex: req.query.search, $options: 'i' } },
                { lastName: { $regex: req.query.search, $options: 'i' } },
                { email: { $regex: req.query.search, $options: 'i' } },
                { designation: { $regex: req.query.search, $options: 'i' } },
                { mobileNumber: { $regex: req.query.search, $options: 'i' } }]
            }
            if (req.query.status) {
                criteria.status = +req.query.status
            }
            totalSubadmin = await adminModel.find({ status: { $ne: "DELETE" }, userType: "SUBADMIN" }).countDocuments();
            totalActive = await adminModel.find({ status: "ACTIVE", userType: "SUBADMIN" }).countDocuments();
            totalInactive = await adminModel.find({ status: "BLOCK", userType: "SUBADMIN" }).countDocuments();
            totalList = await adminModel.find(criteria).countDocuments();
            documentList = await adminModel.find(criteria).sort({ createdAt: -1 })
                .skip((limit * pageNumber) - limit).limit(limit).lean()
            if (!documentList) {
                return res.status(404).send({ responseMessage: ErrorMessage.NOT_FOUND })
            }
            return res.status(200).send({ responseMessage: SuccessMessage.DATA_FOUND, documentList, totalList,totalSubadmin,totalActive,totalInactive})


        } catch (e) {
            return res.status(501).send({ responseMessage: ErrorMessage.SOMETHING_WRONG, e })
        }
    },

    viewSubadmin: async (req, res) => {
        let query = { _id: req.params._id }
        let userData = await adminModel.findOne(query)
        if (!userData)
            return res.status(404).send({ responseMessage: ErrorMessage.NOT_FOUND })
        else {
            return res.status(200).send({ responseMessage: SuccessMessage.DATA_FOUND, userData })
        }
    },

    /**
* Function Name :updateSubadmin
* Description   :edit updateSubadmin  by admin
*s
* @return response
*/

    updateSubadmin: async (req, res) => {
        try {
            let data = await adminModel.findOne({ _id: req.query._id, status: { $ne: "DELETE" } })
            if (!data) return res.status(404).send({ responseMessage: ErrorMessage.NOT_FOUND })
            let updateData = await adminModel.findOneAndUpdate({ _id: data._id }, { $set: req.body }, { new: true })
            if (!updateData)  return res.status(500).send({ responseMessage: ErrorMessage.INTERNAL_ERROR })
            return res.status(200).send({ responseMessage: SuccessMessage.DATA_SAVED })

        }
        catch (e) {
            return res.status(501).send({ responseMessage: ErrorMessage.SOMETHING_WRONG, e })
        }
    },

    /**
* Function Name :actionPerform API
* Description : actionPerform   API 
* @return  response
*/

    actionPerform: async (req, res) => {
        try {
            let data = await adminModel.findOne({ _id: req.query._id })
            if (!data) return res.status(404).send({ responseMessage: ErrorMessage.NOT_FOUND })
            let updateData = await adminModel.findOneAndUpdate({ _id: data._id }, { $set: req.query }, { new: true })
            if (!updateData) { return res.status(404).send({ responseMessage: ErrorMessage.NOT_FOUND }) }
            return res.status(200).send({ responseMessage: "Action performed" })
        }
        catch (e) {
            return res.status(501).send({ responseMessage: ErrorMessage.SOMETHING_WRONG, e })
        }
    },

}