const adminModel = require('../../model/admin')
const { commonResponse: response } = require('../../helper/commonResponseHandler');
const { ErrorMessage } = require('../../helper/message');
const { SuccessMessage } = require('../../helper/message');
// const { ErrorCode } = require('../../helper/statusCode');
// const { SuccessCode } = require('../../helper/statusCode');
const commonFunction = require('../../utility/common')
const forgotEmail = require('../../utility/admin/forgotEmail')
const bcrypt = require("bcrypt-nodejs");
const salt = bcrypt.genSaltSync(10);
var jwt = require('jsonwebtoken');




module.exports = {

    /**
     * Function Name :adminLogin
     * Description   : login for admin
     *
     * @return response
   */
    adminLogin: async (req, res) => {
        try {
            adminModel.findOne({ email: req.body.email, status: "ACTIVE", userType: { $in: ["ADMIN", "SUBADMIN"] } }, (error, adminData) => {
                if (!adminData) {
                    return res.status(402).send({ responseMessage: ErrorMessage.INVALID_CREDENTIAL })
                }
                const check = bcrypt.compareSync(req.body.password, adminData.password)
                if (check) {
                    var token = jwt.sign({ id: adminData._id, iat: Math.floor(Date.now() / 1000) - 30 }, 'gymdoctor', { expiresIn: '24h' });
                    var result = {
                        _id: adminData._id,
                        token: token,
                        firstName: adminData.firstName,
                        lastName: adminData.lastName,
                        email: adminData.email,
                        profilePic: adminData.profilePic,
                        userType: adminData.userType,
                        permissions: adminData.permissions
                    };
                    return res.status(200).send({ responseMessage: SuccessMessage.LOGIN_SUCCESS, result })

                }
                else {
                    return res.status(402).send({ responseMessage: ErrorMessage.INVALID_CREDENTIAL })
                }
            })
        }
        catch (error) { 
            return res.status(501).send({ responseMessage: ErrorMessage.SOMETHING_WRONG, error })
        }
    },

            /**
* Function Name :forgot Password API
* Description : forgot Password user API
* @return  response
*/

forgotPassword: (req, res) => {
    try {
        var query = { email: req.body.email, status: "ACTIVE" }
        adminModel.findOne(query, (error, userDetails) => {
            if (error) return res.status(500).send({ responseMessage: ErrorMessage.INTERNAL_ERROR, error })
            else if (!userDetails) {
                return res.status(404).send({ responseMessage: ErrorMessage.NOT_FOUND })
            } else {
                req.body.otp = commonFunction.getOTP()
                req.body.otpTime = Date.now()
                let subject = "OTP"
                let name = userDetails.firstName + ' ' + userDetails.lastName
                forgotEmail.forgot(userDetails.email, subject, name, req.body.otp) 
                adminModel.findByIdAndUpdate({ _id: userDetails._id }, req.body, { new: true }).lean().exec((err1, result) => {
                    if (err1) return res.status(500).send({ responseMessage: ErrorMessage.INTERNAL_ERROR, err1 })
                    return res.status(200).send({ responseMessage: "We have emailed instructions to reset your password", result })
                })
            }
        })
    } catch (e) {
        return res.status(501).send({ responseMessage: ErrorMessage.SOMETHING_WRONG, e })
    }
},

    /**
* Function Name :resetPassword
* Description   :Updated password
*
* @return response
*/
    resetPassword: async (req, res) => {
        try {
            let userData = await adminModel.findOne({ _id: req.body._id, status: "ACTIVE" })
            if (!userData) return res.status(404).send({ responseMessage: ErrorMessage.NOT_FOUND })
            req.body.password = bcrypt.hashSync(req.body.password)
            adminModel.findOneAndUpdate({ _id: userData._id }, { $set: { password: req.body.password } }, { new: true }, (updateErr, passwordUpdate) => {
                if (updateErr) return res.status(500).send({ responseMessage: ErrorMessage.INTERNAL_ERROR, updateErr })
                return res.status(200).send({ responseMessage: SuccessMessage.RESET_SUCCESS, passwordUpdate })

            })
        } catch (e) {
            return res.status(501).send({ responseMessage: ErrorMessage.SOMETHING_WRONG, e })
        }

    },

    /**
* Function Name :changePassword
* Description   :change password
*
* @return response
*/
    changePassword: (req, res) => {
        try {
            let userId = req.userId
            adminModel.findOne({ _id: userId }, (error, userDetails) => {
                if (error) return res.status(500).send({ responseMessage: ErrorMessage.INTERNAL_ERROR, error })
                else if (!userDetails) {
                    return res.status(404).send({ responseMessage: ErrorMessage.NOT_FOUND })
                } else {
                    let check = bcrypt.compareSync(req.body.oldPassword, userDetails.password)
                    if (check) {
                        if (req.body.newPassword == req.body.confirmPassword) {
                            let hashPassword = bcrypt.hashSync(req.body.confirmPassword)
                            adminModel.findOneAndUpdate({ _id: userDetails._id }, { $set: { password: hashPassword } }, { new: true }, (updateErr, passwordUpdate) => {
                                if (updateErr) return res.status(500).send({ responseMessage: ErrorMessage.INTERNAL_ERROR, updateErr })
                                return res.status(200).send({ responseMessage: SuccessMessage.RESET_SUCCESS })
                            })
                        } else {
                            return res.status(400).send({ responseMessage: ErrorMessage.NEW_CONFIRM_INCORRECT })

                        }
                    } else {
                        return res.status(400).send({ responseMessage: ErrorMessage.OLD_PASSWORD_INCORRECT })
                    }
                }
            })
        } catch (e) {
            return res.status(501).send({ responseMessage: ErrorMessage.SOMETHING_WRONG, e })

        }
    },

    myProfile: async (req, res) => {
        let userId = req.userId
        let userData = await adminModel.findOne({ _id: userId })
        if (!userData)
            return res.status(404).send({ responseMessage: ErrorMessage.NOT_FOUND })
        else {
            return res.status(200).send({ responseMessage: SuccessMessage.DATA_FOUND, userData })
        }
    },

    /**
* Function Name :logout
* Description   :logout
*
* @return response
*/
    logout: async (req, res) => {
        try {
            userId = req.userId
            let userData = await adminModel.findOne({ _id: userId, status: "ACTIVE" })
            if (!userData) return res.status(404).send({ responseMessage: ErrorMessage.NOT_FOUND })
            adminModel.findOneAndUpdate({ _id: userData._id }, { $set: { token: "", deviceToken: "" } }, { new: true }, (updateErr, passwordUpdate) => {
                if (updateErr) return res.status(500).send({ responseMessage: ErrorMessage.INTERNAL_ERROR, updateErr })
                return res.status(200).send({ responseMessage: SuccessMessage.LOGOUT_SUCCESS })
            })
        } catch (e) {
            return res.status(501).send({ responseMessage: ErrorMessage.SOMETHING_WRONG, e })
        }
    },


    /**
* Function Name :otp verify API
* Description : otp verify vendor API
* @return  response
*/
    verifyOtp: (req, res) => {
        try {
            adminModel.findOne({ "_id": req.body.userId, status: "ACTIVE" }, async (userErr, userData) => {
                if (userErr) return res.status(500).send({ responseMessage: ErrorMessage.INTERNAL_ERROR, userErr })
                else if (!userData)
                    return res.status(404).send({ responseMessage: ErrorMessage.NOT_FOUND })
                else {
                    if (new Date().getTime() - userData.otpTime >= 300000) {
                        return res.status(401).send({ responseMessage: "OTP expired." })
                    }
                    else {
                        if (userData.otp == req.body.otp || req.body.otp == "123456") {
                            req.body.isEmailVerified = true;
                            let userData = await adminModel.findByIdAndUpdate({ "_id": req.body.userId, status: "ACTIVE" }, req.body, { new: true }).lean()
                            if (!userData) return res.status(500).send({ responseMessage: ErrorMessage.INTERNAL_ERROR, error })
                            let newToken = jwt.sign({ id: userData._id, iat: Math.floor(Date.now() / 1000) - 30 }, 'oneApp');
                            var result = userData
                            result.token = newToken;
                            return res.status(200).send({ responseMessage: SuccessMessage.VERIFY_OTP, result })

                        }
                        else {
                            return res.status(404).send({ responseMessage: "Invalid Otp." })
                        }
                    }
                }
            })

        } catch (e) {
            return res.status(501).send({ responseMessage: ErrorMessage.SOMETHING_WRONG, e })
        }
    },


        /**
* Function Name :resendOtp API
* Description : resendOtp user API
* @return  response
*/
resendOtp: (req, res) => {
    try {
        adminModel.findOne({ _id: req.body.userId, status: "ACTIVE" }, async (userErr, userDetails) => {
            if (userErr) return res.status(500).send({responseMessage: ErrorMessage.INTERNAL_ERROR, userErr })
            else if (!userDetails) {
                return res.status(404).send({ responseCode: 404, responseMessage: ErrorMessage.NOT_FOUND })
            }
            else {
                req.body.otp = commonFunction.getOTP()
                req.body.otpTime = Date.now()
                let subject = "OTP"
                let name = userDetails.firstName + ' ' + userDetails.lastName
                forgotEmail.forgot(userDetails.email, subject, name, req.body.otp) 
                adminModel.findByIdAndUpdate({ _id: req.body.userId }, req.body, { new: true }, (updateErr, result) => {
                    if (updateErr) return res.status(500).send({responseMessage: ErrorMessage.INTERNAL_ERROR, updateErr })
                    return res.status(200).send({responseMessage: "Otp send Successfully" })

                })
            }
        })
    }
    catch (e) {
        return res.status(501).send({ responseCode: 501, responseMessage: ErrorMessage.SOMETHING_WRONG, e })
    }

},


}