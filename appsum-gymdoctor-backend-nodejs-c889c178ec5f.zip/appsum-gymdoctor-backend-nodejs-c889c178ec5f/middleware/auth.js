const { commonResponse: response } = require('../helper/commonResponseHandler')
const { ErrorMessage } = require('../helper/message')
const { ErrorCode } = require('../helper/statusCode')
const userModel = require('../model/user')
const adminModel = require('../model/admin')
const jwt = require('jsonwebtoken')


exports.verifyToken = (req, res, next) => {
    if (req.headers.token) {
        jwt.verify(req.headers.token, 'gymdoctor', (err, result) => {
            if (err) {
                return res.status(401).send({responseMessage: ErrorMessage.INCORRECT_JWT })
            }
            else {
                userModel.findOne({ _id: result.id }, (error, result2) => {
                    if (error) return res.status(500).send({responseMessage: ErrorMessage.INTERNAL_ERROR, error })
                    else if (!result2) {
                        console.log("=======user not found in middleware")
                        return res.status(404).send({responseMessage: ErrorMessage.NOT_FOUND })
                    }
                    else {
                        if (result2.status == "BLOCK") {
                            return res.status(403).send({responseMessage: ErrorMessage.BLOCKED_BY_ADMIN })
                        }
                        else if (result2.status == "DELETE") {
                            return res.status(401).send({responseMessage: ErrorMessage.DELETED_BY_ADMIN })

                        }
                        else {                     
                            req.userId=result2.id
                            next(); 
                        }
                    }
                })
            }
        })
    } else {
        return res.status(400).send({responseMessage: ErrorMessage.NO_TOKEN })

    }

}

exports.verifyAdminToken = (req, res, next) => {
    if (req.headers.token) {
        jwt.verify(req.headers.token, 'gymdoctor', (err, result) => {
            if (err) {
                return res.status(401).send({responseMessage: ErrorMessage.INCORRECT_JWT })
            }
            else {
                adminModel.findOne({ _id: result.id }, (error, result2) => {
                    if (error) return res.status(500).send({responseMessage: ErrorMessage.INTERNAL_ERROR, error })
                    else if (!result2) {
                        console.log("=========admin token")
                        return res.status(404).send({responseMessage: ErrorMessage.NOT_FOUND })
                    }
                    else {
                        if (result2.status == "BLOCK") {
                            return res.status(403).send({responseMessage: ErrorMessage.BLOCKED_BY_ADMIN })
                        }
                        else if (result2.status == "DELETE") {
                            return res.status(401).send({responseMessage: ErrorMessage.DELETED_BY_ADMIN })

                        }
                        else {                     
                            req.userId=result2.id
                            next(); 
                        }
                    }
                })
            }
        })
    } else {
        return res.status(400).send({responseMessage: ErrorMessage.NO_TOKEN })

    }

}