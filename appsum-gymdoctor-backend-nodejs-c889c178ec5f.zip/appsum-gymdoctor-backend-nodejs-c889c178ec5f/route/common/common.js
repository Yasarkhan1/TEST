const express = require('express')
const router = express.Router()
const common = require('../../controller/common/common');
const auth = require('../../middleware/auth');




router.post('/getUrl', common.uploadFile)
router.put('/makeCard_primary',auth.verifyToken, common.makeCard_primary)
router.get('/getReferralCode', auth.verifyToken,common.getReferralCode)
router.get('/invitationReportList', auth.verifyToken,common.invitationReportList)






module.exports = router;