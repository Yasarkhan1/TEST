const express = require('express')
const router = express.Router()
const cms = require('../../controller/static/cms');



router.get('/getStaticPage', cms.getStaticPage)
router.get('/testimonialList', cms.testimonialList)
router.post('/contactUs_form', cms.contactUs_form)
router.get('/teamList', cms.teamList)
router.post('/subscribe_newsLetter', cms.subscribe_newsLetter)







module.exports = router;