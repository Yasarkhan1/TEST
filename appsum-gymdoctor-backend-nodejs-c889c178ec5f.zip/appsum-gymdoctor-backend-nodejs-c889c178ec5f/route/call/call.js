const express = require('express')
const router = express.Router()
const call = require('../../controller/call/call');
const auth = require('../../middleware/auth');



router.post('/getTwilioToken',auth.verifyToken,call.getTwilioToken)
router.post('/callDisconnect',call.callDisconnect)

// for doctor app to get remaining minute
router.get('/getRemainingMinute',auth.verifyToken,call.getRemainingMinute)
router.post('/updateRemainingMinute',auth.verifyToken,call.updateRemainingMinute)


module.exports = router;