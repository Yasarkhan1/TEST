const express = require('express')
const router = express.Router()
const user = require('../../controller/doctor/doctor');
const booking = require('../../controller/doctor/booking');
const help = require('../../controller/doctor/help')
const notification = require('../../controller/doctor/notification')
const setting = require('../../controller/doctor/setting')
const rating = require('../../controller/doctor/rating')
const prescription = require('../../controller/doctor/prescription')
const invoice = require('../../controller/doctor/invoice')
const medicalRecord = require('../../controller/doctor/medicalRecord')

const auth = require('../../middleware/auth');








router.post('/signup', user.signup)
router.post('/verifyOtp', user.verifyOtp)
router.post('/forgotPassword', user.forgotPassword)
router.post('/resetPassword', user.resetPassword)
router.post('/resendOtp', user.resendOtp)
router.post('/createPersonalProfile', auth.verifyToken, user.createPersonalProfile)
router.get('/subscriptionList', user.subscriptionList)
router.get('/couponList', auth.verifyToken, user.couponList)
router.post('/BuySubscription', auth.verifyToken, user.BuySubscription)
router.get('/primarySpecialtyList', user.primarySpecialtyList)
router.get('/secondrySpecialtyList', auth.verifyToken, user.secondrySpecialtyList)
router.post('/createProfessionalProfile', auth.verifyToken, user.createProfessionalProfile)
router.post('/login', user.login)
router.get('/myProfile', auth.verifyToken, user.myProfile)



// Home
router.get('/dashboard', auth.verifyToken, user.dashboard)
router.post('/recommendation', auth.verifyToken, user.recommendation)



//Booking

router.get('/upcomingAppointments', auth.verifyToken, booking.upcomingAppointments)
router.get('/previousAppointments', auth.verifyToken, booking.previousAppointments)
router.get('/viewAppointment/:id', auth.verifyToken, booking.viewAppointment)
router.get('/getSlot', auth.verifyToken, booking.getSlot)
router.post('/rescheduleAppointment', auth.verifyToken, booking.rescheduleAppointment)
router.post('/cancelAppointment', auth.verifyToken, booking.cancelAppointment)




// Help

router.post('/submitHelpRequest', auth.verifyToken, help.submitHelpRequest)
router.get('/helpRequestList', auth.verifyToken, help.helpRequestList)
router.get('/viewHelpRequest/:id', auth.verifyToken, help.viewHelpRequest)
router.post('/replyOnRequest',auth.verifyToken,help.replyOnRequest)

// Notification

router.get('/notificationList', auth.verifyToken, notification.notificationList)
router.delete('/deleteNotification/:_id', auth.verifyToken, notification.deleteNotification)
router.get('/viewNotification/:id', auth.verifyToken, notification.viewNotification)



//setting

router.post('/editProfile', auth.verifyToken, setting.editProfile)
router.post('/changePassword', auth.verifyToken, setting.changePassword)
router.get('/privacyPolicy', setting.viewPrivacyPolicy)
router.get('/termsAndConditions', setting.viewTermsAndCondtion)
router.get('/aboutUs', setting.aboutUs)
router.get('/myWallet',auth.verifyToken, setting.myWallet)
router.get('/mySubscription',auth.verifyToken, setting.mySubscription)
router.post('/upgradeSubscription',auth.verifyToken,setting.upgradeSubscription)
router.post('/editAvailability', auth.verifyToken, setting.editAvailability)
router.get('/invoiceBillList', auth.verifyToken,setting.invoiceBillList)
router.post('/upgradeSubscription_fromWallet',auth.verifyToken,setting.upgradeSubscription_fromWallet)





// Card
router.post('/addCard', auth.verifyToken, setting.addCard)
router.post('/editCard', auth.verifyToken, setting.editCard)
router.get('/cardList', auth.verifyToken, setting.cardList)
router.delete('/deleteCard/:_id', auth.verifyToken, setting.deleteCard)

router.post('/logout', auth.verifyToken, setting.logout)


// Reviews and Rating
router.get('/reviewsList', auth.verifyToken, rating.reviewsList)
router.post('/challengeReviews', auth.verifyToken, rating.challengeReviews)

// Prescription
router.post('/addPrescription', auth.verifyToken, prescription.addPrescription)
router.post('/editPrescription', auth.verifyToken, prescription.editPrescription)
router.get('/prescriptionList', auth.verifyToken, prescription.prescriptionList)
router.get('/viewPrescription/:_id', auth.verifyToken, prescription.viewPrescription)
router.delete('/deletePrescription/:_id', auth.verifyToken, prescription.deletePrescription)



// medical Records
router.post('/addMedicalRecord', auth.verifyToken, medicalRecord.addMedicalRecord)
router.post('/editMedicalRecord', auth.verifyToken, medicalRecord.editMedicalRecord)
router.get('/medicalRecordList', auth.verifyToken, medicalRecord.medicalRecordList)
router.get('/viewMedicalRecord/:_id', auth.verifyToken, medicalRecord.viewMedicalRecord)

// Invoice 
router.get('/invoiceList', auth.verifyToken,invoice.invoiceList)
router.get('/viewInvoice/:_id', auth.verifyToken, invoice.viewInvoice)

// Withdraw amount rquest
router.post('/withdrawRequest', auth.verifyToken, setting.withdrawRequest)
router.get('/transactionHistory', auth.verifyToken,setting.transactionHistory)




module.exports = router;