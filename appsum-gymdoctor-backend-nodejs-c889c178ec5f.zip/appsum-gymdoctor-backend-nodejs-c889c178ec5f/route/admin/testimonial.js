const express = require('express')
const router = express.Router()
const testimonial = require('../../controller/admin/testimonial');
const auth = require('../../middleware/auth');








router.post('/addTestimonial',auth.verifyAdminToken,testimonial.addTestimonial)
router.put('/editTestimonial',auth.verifyAdminToken,testimonial.editTestimonial)
router.get('/viewTestimonial/:_id',auth.verifyAdminToken,testimonial.viewTestimonial)
router.get('/testimonialList',auth.verifyAdminToken,testimonial.testimonialList)
router.patch('/actionPerform',auth.verifyAdminToken,testimonial.actionPerform)







module.exports = router;