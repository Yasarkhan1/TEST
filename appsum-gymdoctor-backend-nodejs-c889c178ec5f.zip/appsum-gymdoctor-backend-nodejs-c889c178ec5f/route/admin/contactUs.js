const express = require('express')
const router = express.Router()
const contactUs = require('../../controller/admin/contactUs');
const auth = require('../../middleware/auth');








router.get('/view_contactUs/:_id',auth.verifyAdminToken,contactUs.view_contactUs)
router.get('/contactUs_list',auth.verifyAdminToken,contactUs.contactUs_list)








module.exports = router;