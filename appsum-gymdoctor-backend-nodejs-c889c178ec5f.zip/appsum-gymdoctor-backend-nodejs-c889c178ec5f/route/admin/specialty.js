const express = require('express')
const router = express.Router()
const specialty = require('../../controller/admin/specialty');
const auth = require('../../middleware/auth');






router.get('/primarySecialtyList',auth.verifyAdminToken,specialty.primarySecialtyList)


router.post('/addSpecialty',auth.verifyAdminToken,specialty.addSpecialty)
router.put('/editSpecialty',auth.verifyAdminToken,specialty.editSpecialty)
router.get('/viewSpecialty/:_id',auth.verifyAdminToken,specialty.viewSpecialty)
router.get('/specialtyList',auth.verifyAdminToken,specialty.specialtyList)
router.patch('/actionPerform',auth.verifyAdminToken,specialty.actionPerform)







module.exports = router;