const express = require('express')
const router = express.Router()
const patient = require('../../controller/admin/patient');
const auth = require('../../middleware/auth');







router.get('/viewPatient/:_id',auth.verifyAdminToken,patient.viewPatient)
router.get('/patientList',auth.verifyAdminToken,patient.patientList)
router.patch('/actionPerform',auth.verifyAdminToken,patient.actionPerform)







module.exports = router;