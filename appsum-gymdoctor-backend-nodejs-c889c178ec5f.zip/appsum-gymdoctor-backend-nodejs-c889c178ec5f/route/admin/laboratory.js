const express = require('express')
const router = express.Router()
const laboratory = require('../../controller/admin/laboratory');
const auth = require('../../middleware/auth');





router.post('/addLaboratory',auth.verifyAdminToken,laboratory.addLaboratory)
router.put('/editLaboratory',auth.verifyAdminToken,laboratory.editLaboratory)
router.get('/viewLaboratory/:_id',auth.verifyAdminToken,laboratory.viewLaboratory)
router.get('/laboratoryList',auth.verifyAdminToken,laboratory.laboratoryList)
router.patch('/actionPerform',auth.verifyAdminToken,laboratory.actionPerform)

//**************PACKAGE APIS*********************************** */

router.post('/addPackage',auth.verifyAdminToken,laboratory.addPackage)
router.put('/editPackage',auth.verifyAdminToken,laboratory.editPackage)
router.get('/viewPackage/:_id',auth.verifyAdminToken,laboratory.viewPackage)
router.get('/packageList',auth.verifyAdminToken,laboratory.packageList)
router.patch('/actionPerform_package',auth.verifyAdminToken,laboratory.actionPerform_package)

// Report management


router.get('/appointmentList',auth.verifyAdminToken,laboratory.appointmentList)
router.get('/viewReport/:id',auth.verifyAdminToken,laboratory.viewReport)
router.post('/uploadReport',auth.verifyAdminToken,laboratory.uploadReport)
router.put('/updateReport/:id',auth.verifyAdminToken,laboratory.updateReport)







module.exports = router;