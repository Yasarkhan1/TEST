const express = require('express')
const router = express.Router()
const coupon = require('../../controller/admin/coupon');
const auth = require('../../middleware/auth');








router.post('/addCoupon',auth.verifyAdminToken,coupon.addCoupon)
router.put('/editCoupon',auth.verifyAdminToken,coupon.editCoupon)
router.get('/viewCoupon/:_id',auth.verifyAdminToken,coupon.viewcoupon)
router.get('/couponList',auth.verifyAdminToken,coupon.couponList)
router.patch('/actionPerform',auth.verifyAdminToken,coupon.actionPerform)







module.exports = router;