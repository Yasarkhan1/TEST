const express = require('express')
const router = express.Router()
const dashboard = require('../../controller/admin/dashboard');
const auth = require('../../middleware/auth');





router.get('/dashboard',dashboard.dashboard)
router.get('/revenueGraph',dashboard.revenueGraph)
router.get('/appointmentGraph',dashboard.appointmentGraph)
router.get('/patientGraph',dashboard.patientGraph)
router.get('/doctorGraph',dashboard.doctorGraph)












module.exports = router;