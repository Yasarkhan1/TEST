const express = require('express')
const router = express.Router()
const review = require('../../controller/admin/review');
const auth = require('../../middleware/auth');








router.get('/viewReview/:_id',auth.verifyAdminToken,review.viewReview)
router.get('/reviewList',auth.verifyAdminToken,review.reviewList)
router.delete('/actionPerform',auth.verifyAdminToken,review.actionPerform)







module.exports = router;