const express = require('express')
const router = express.Router()
const help = require('../../controller/admin/help');
const auth = require('../../middleware/auth');








router.post('/replyOnRequest',auth.verifyAdminToken,help.replyOnRequest)
router.get('/viewHelpRequest/:_id',auth.verifyAdminToken,help.viewHelpRequest)
router.get('/helpRequestList',auth.verifyAdminToken,help.helpRequestList)
router.delete('/actionPerform',auth.verifyAdminToken,help.actionPerform)







module.exports = router;