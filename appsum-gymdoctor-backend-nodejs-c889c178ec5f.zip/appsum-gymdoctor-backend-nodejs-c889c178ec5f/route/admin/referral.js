const express = require('express')
const router = express.Router()
const referral = require('../../controller/admin/referral');
const auth = require('../../middleware/auth');



router.get('/getInvitationAmount',auth.verifyAdminToken,referral.getInvitationAmount)
router.put('/updateInvitationAmount',auth.verifyAdminToken,referral.updateInvitationAmount)
router.get('/viewReferral/:_id',auth.verifyAdminToken,referral.viewReferral)
router.get('/referralList',auth.verifyAdminToken,referral.referralList)

module.exports = router;