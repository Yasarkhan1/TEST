const express = require('express')
const router = express.Router()
const subadmin = require('../../controller/admin/subadmin');
const auth = require('../../middleware/auth');








router.post('/addSubadmin',subadmin.addSubadmin)
router.put('/updateSubadmin',auth.verifyAdminToken,subadmin.updateSubadmin)
router.get('/viewSubadmin/:_id',auth.verifyAdminToken,subadmin.viewSubadmin)
router.get('/subadminList',auth.verifyAdminToken,subadmin.subadminList)
router.patch('/actionPerform',auth.verifyAdminToken,subadmin.actionPerform)







module.exports = router;