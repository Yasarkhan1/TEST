const express = require('express')
const router = express.Router()
const subscription = require('../../controller/admin/subscription');
const auth = require('../../middleware/auth');








router.post('/addSubscription',auth.verifyAdminToken,subscription.addSubscription)
router.put('/editSubscription',auth.verifyAdminToken,subscription.editSubscription)
router.get('/viewSubscription/:_id',auth.verifyAdminToken,subscription.viewSubscription)
router.get('/subscriptionList',auth.verifyAdminToken,subscription.subscriptionList)
router.patch('/actionPerform',auth.verifyAdminToken,subscription.actionPerform)



 



module.exports = router;