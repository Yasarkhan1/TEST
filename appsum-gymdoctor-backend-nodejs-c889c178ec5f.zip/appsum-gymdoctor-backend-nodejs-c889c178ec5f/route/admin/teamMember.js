const express = require('express')
const router = express.Router()
const member = require('../../controller/admin/teamMember');
const auth = require('../../middleware/auth');








router.post('/addMember',auth.verifyAdminToken,member.addMember)
router.put('/editMember',auth.verifyAdminToken,member.editMember)
router.get('/viewMember/:_id',auth.verifyAdminToken,member.viewMember)
router.get('/memberList',auth.verifyAdminToken,member.memberList)
router.patch('/actionPerform',auth.verifyAdminToken,member.actionPerform)







module.exports = router;