const express = require('express')
const router = express.Router()
const notification = require('../../controller/admin/notification');
const auth = require('../../middleware/auth');






router.post('/sendNotification',auth.verifyAdminToken,notification.sendNotification)
router.get('/viewNotification/:_id',auth.verifyAdminToken,notification.viewNotification)
router.get('/sentNotificationList',auth.verifyAdminToken,notification.sentNotificationList)
router.delete('/deleteNotification/:_id',auth.verifyAdminToken,notification.deleteNotification)








module.exports = router;