const express = require('express')
const router = express.Router()
const admin = require('../../controller/admin/admin');
const auth = require('../../middleware/auth');








router.post('/login', admin.adminLogin)
router.post('/forgotPassword', admin.forgotPassword)
router.post('/resetPassword', admin.resetPassword)
router.post('/changePassword',auth.verifyAdminToken, admin.changePassword)
router.get('/myProfile',auth.verifyAdminToken, admin.myProfile)
router.post('/logout',auth.verifyAdminToken, admin.logout)
router.post('/verifyOtp', admin.verifyOtp)
router.post('/resendOtp', admin.resendOtp)











module.exports = router;