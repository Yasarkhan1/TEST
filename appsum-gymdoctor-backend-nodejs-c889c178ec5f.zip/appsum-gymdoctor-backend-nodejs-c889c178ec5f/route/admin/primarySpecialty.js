const express = require('express')
const router = express.Router()
const primarySpecialty = require('../../controller/admin/primarySpecialty');
const auth = require('../../middleware/auth');








router.post('/addSpecialty',auth.verifyAdminToken,primarySpecialty.addSpecialty)
router.put('/editSpecialty',auth.verifyAdminToken,primarySpecialty.editSpecialty)
router.get('/viewSpecialty/:_id',auth.verifyAdminToken,primarySpecialty.viewSpecialty)
router.get('/specialtyList',auth.verifyAdminToken,primarySpecialty.specialtyList)
router.patch('/actionPerform',auth.verifyAdminToken,primarySpecialty.actionPerform)







module.exports = router;