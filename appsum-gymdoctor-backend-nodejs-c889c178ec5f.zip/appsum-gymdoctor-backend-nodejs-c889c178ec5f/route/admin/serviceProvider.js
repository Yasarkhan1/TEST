const express = require('express')
const router = express.Router()
const serviceProvider = require('../../controller/admin/serviceProvider');
const auth = require('../../middleware/auth');






router.get('/viewServiceProvider/:_id',auth.verifyAdminToken,serviceProvider.viewServiceProvider)
router.get('/serviceProviderList',auth.verifyAdminToken,serviceProvider.serviceProviderList)
router.patch('/actionPerform',auth.verifyAdminToken,serviceProvider.actionPerform)
router.put('/acceptRejectDeleteRequest',auth.verifyAdminToken,serviceProvider.acceptRejectDeleteRequest)








module.exports = router;