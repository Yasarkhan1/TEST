const express = require('express')
const router = express.Router()
const appointment = require('../../controller/admin/appointment');
const auth = require('../../middleware/auth');

router.get('/appointmentList',auth.verifyAdminToken,appointment.appointmentList)

module.exports = router;