const express = require('express')
const router = express.Router()
const earning = require('../../controller/admin/earning');
const auth = require('../../middleware/auth');



router.get('/invoiceList',auth.verifyAdminToken,earning.invoiceList)
router.get('/viewInvoice/:id',auth.verifyAdminToken,earning.viewInvoice)


module.exports = router;