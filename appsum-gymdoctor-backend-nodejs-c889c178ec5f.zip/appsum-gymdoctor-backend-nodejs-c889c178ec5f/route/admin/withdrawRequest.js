const express = require('express')
const router = express.Router()
const withdrawRequest = require('../../controller/admin/withdrawAmountRequest');
const auth = require('../../middleware/auth');






router.get('/list',auth.verifyAdminToken,withdrawRequest.list)
router.get('/view/:_id',auth.verifyAdminToken,withdrawRequest.view)
router.put('/paymentDone/:_id',auth.verifyAdminToken,withdrawRequest.paymentDone)
router.put('/rejectRequest/:_id',auth.verifyAdminToken,withdrawRequest.rejectRequest)

module.exports = router;