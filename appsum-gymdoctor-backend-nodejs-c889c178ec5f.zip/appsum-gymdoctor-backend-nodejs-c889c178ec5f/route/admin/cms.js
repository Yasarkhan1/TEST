const express = require('express')
const router = express.Router()
const cms = require('../../controller/admin/cms');
const auth = require('../../middleware/auth');








router.get('/viewContent/:_id',cms.viewContent)
router.put('/editContent',cms.editContent)
router.get('/contentList',cms.contentList)








module.exports = router;