const express = require('express')
const router = express.Router()
const user = require('../../controller/user/patient');
const rating = require('../../controller/user/rating');
const booking = require('../../controller/user/booking')
const setting = require('../../controller/user/setting')
const help = require('../../controller/user/help')
const notification = require('../../controller/user/notification')
const prescription = require('../../controller/user/prescription')
const invoice = require('../../controller/user/invoice')
const medicalRecord = require('../../controller/user/medicalRecord')
const laboratory = require('../../controller/user/laboratoryBooking')
const report = require('../../controller/user/report')


const auth = require('../../middleware/auth');




router.post('/signup', user.signup)
router.post('/verifyOtp', user.verifyOtp)
router.post('/resendOtp', user.resendOtp)
router.post('/forgotPassword', user.forgotPassword)
router.post('/resetPassword', user.resetPassword)
router.post('/createPersonalProfile',auth.verifyToken, user.createPersonalProfile)
router.get('/subscriptionList',user.subscriptionList)
router.get('/couponList',auth.verifyToken,user.couponList)
router.post('/BuySubscription',auth.verifyToken,user.BuySubscription)
router.post('/createMedicalProfile',auth.verifyToken, user.createMedicalProfile)
router.post('/login', user.login)
router.get('/myProfile',auth.verifyToken,user.myProfile)



//
router.get('/serviceProviderTypeList',user.primarySpecialtyList)
router.get('/secondrySpecialtyList',auth.verifyToken,user.secondrySpecialtyList)
router.post('/nearByServiceProvider',auth.verifyToken,user.nearByServiceProvider)
router.post('/homeData',user.homeData)
router.post('/laboratoryHomeData',user.laboratoryHomeData)





// favourite unfavourite 

router.post('/favourite',auth.verifyToken,user.favourite)

// Rating
router.post('/rating',auth.verifyToken,rating.rating)
router.get('/reviewsList',auth.verifyToken,rating.reviewsList)
router.post('/editRating',auth.verifyToken,rating.editRating)



//
router.get('/viewDoctorDetails/:id',auth.verifyToken,user.viewDoctorDetails)




// Booking
router.get('/getSlot',auth.verifyToken,booking.getSlot)
router.post('/bookAppointment',auth.verifyToken,booking.bookAppointment)
router.get('/upcomingAppointments',auth.verifyToken,booking.upcomingAppointments)
router.get('/previousAppointments',auth.verifyToken,booking.previousAppointments)
router.get('/viewAppointment/:id',auth.verifyToken,booking.viewAppointment)
router.post('/cancelAppointment', auth.verifyToken, booking.cancelAppointment)
router.post('/rescheduleAppointment', auth.verifyToken, booking.rescheduleAppointment)

router.post('/bookAppointment_fromCard',auth.verifyToken,booking.bookAppointment_fromCard)






// Setting



router.post('/editProfile',auth.verifyToken, setting.editProfile)
router.post('/changePassword',auth.verifyToken, setting.changePassword)
router.get('/privacyPolicy', setting.viewPrivacyPolicy)
router.get('/termsAndConditions', setting.viewTermsAndCondtion)
router.get('/aboutUs', setting.aboutUs)
router.get('/myWallet',auth.verifyToken, setting.myWallet)
router.get('/mySubscription',auth.verifyToken, setting.mySubscription)
router.get('/medicalHistory',auth.verifyToken, setting.medicalHistory)
router.get('/invoiceBillList',auth.verifyToken, setting.invoiceBillList)
router.post('/upgradeSubscription',auth.verifyToken,setting.upgradeSubscription)
router.get('/favouriteList',auth.verifyToken,setting.favouriteList)


router.post('/upgradeSubscription_fromWallet',auth.verifyToken,setting.upgradeSubscription_fromWallet)




 // Card
 router.post('/addCard',auth.verifyToken, setting.addCard)
 router.post('/editCard',auth.verifyToken, setting.editCard)
 router.get('/cardList',auth.verifyToken,setting.cardList)
 router.delete('/deleteCard/:id',auth.verifyToken,setting.deleteCard)

 //

 // Help

router.post('/submitHelpRequest',auth.verifyToken,help.submitHelpRequest)
router.get('/helpRequestList',auth.verifyToken,help.helpRequestList)
router.get('/viewHelpRequest/:id',auth.verifyToken,help.viewHelpRequest)
router.post('/replyOnRequest',auth.verifyToken,help.replyOnRequest)
// Notification

router.get('/notificationList',auth.verifyToken,notification.notificationList)
router.delete('/deleteNotification/:_id',auth.verifyToken,notification.deleteNotification)
router.get('/viewNotification/:id',auth.verifyToken,notification.viewNotification)


// Prescription
router.get('/prescriptionList', auth.verifyToken, prescription.prescriptionList)
router.get('/viewPrescription/:_id', auth.verifyToken, prescription.viewPrescription)

// Invoice Billing
router.get('/invoiceList', auth.verifyToken,invoice.invoiceList )
router.get('/viewInvoice/:_id', auth.verifyToken, invoice.viewInvoice)


// medical Records
router.get('/medicalRecordList', auth.verifyToken, medicalRecord.medicalRecordList)
router.get('/viewMedicalRecord/:_id', auth.verifyToken, medicalRecord.viewMedicalRecord)

// Reschedule request list

router.get('/rescheduleRequestList',auth.verifyToken,booking.rescheduleRequestList)
router.post('/acceptRescheduleRequest',auth.verifyToken,booking.acceptRescheduleRequest)
router.post('/rejectRescheduleRequest',auth.verifyToken,booking.rejectRescheduleRequest)

router.post('/logout',auth.verifyToken, setting.logout)



// LABORATORY
router.post('/nearByLaboratory',laboratory.nearByLaboratory)
router.get('/viewLaboratory/:id',laboratory.viewLaboratory)
router.get('/getLaboratorySlot',auth.verifyToken,laboratory.getSlot)

router.post('/bookLaboratory_appointment',auth.verifyToken,laboratory.bookLaboratory_appointment)
router.get('/upcomingLaboratory_appointments',auth.verifyToken,laboratory.upcomingLaboratory_appointments)
router.get('/previousLaboratory_appointments',auth.verifyToken,laboratory.previousLaboratory_appointments)
router.get('/viewLaboratory_appointment/:id',auth.verifyToken,laboratory.viewLaboratory)
router.post('/cancelLaboratory_appointment', auth.verifyToken, laboratory.cancelLaboratory_appointment)
router.post('/rescheduleLaboratory_appointment', auth.verifyToken, laboratory.rescheduleLaboratory_appointment)


// WEB HOME SEARCH API

router.post('/webHomeSearch',user.webHomeSearch)
router.post('/topHealthCoaches',user.topHealthCoaches)

// REPORT 
router.get('/reportList',auth.verifyToken,report.reportList)


module.exports = router;