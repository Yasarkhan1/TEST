const nodemailer = require('nodemailer')



module.exports = {

    acceptRequest: function (email, subject, name, callback) {

        let html = `<body style="margin: 0;padding: 0;background: #e0e0e0;font-family: 'Roboto',sans-serif;padding:10px 0"">
        <style>
        .im{
            color:#000 !important
        }
        </style>
        <div class="sl-email" style="width:550px;margin:0px auto;padding:0 25px;background:#fff;color:#555555;line-height:20px">
            <div class="header" style="text-align: center;padding:15px 0;margin-bottom: 30px;border-bottom:1px solid #be141b;">
            <div class="logo" style="width: 300px;margin: 20px auto;">
            <img src=${process.env.logo} width="200" alt="Logo">
       </div>
            </div>
            <div class="mail-body"> 
                <table cellpadding="0" cellspacing="0" style="max-width:100%; min-width:100%;" width="100%" class="mcnTextContentContainer">
                    <tbody>
                        <tr>    
                            <td valign="top" class="mcnTextContent" style="padding-top:0; padding-bottom:9px;">
    
                                <h1 style="font-size:15px;margin-bottom:0">your application to work as a service provider for gymdoctor has been accepted. Your account is now live now.</h1>
                                <h2 style="font-size:15px;margin-bottom:0;margin-top:5px;">Here is your Email:${email}</h2>
                                <p style="font-size:15px;">Thank you.<br>
                                    <br>
                                    <strong>Gym Doctor Team</strong>
                                </p>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>    
    </body>`
        const mailBody = {
            from: "<do_not_reply@gmail.com>",
            to: email,
            subject: subject,
            html: html
        };
        nodemailer.createTransport({
            service: 'GMAIL',
            auth: {
                user: process.env.NODEMAILER,
                pass: process.env.NODEMAILER_PASSWORD
            },
            port: 465,
            host: 'smtp.gmail.com'

        }).sendMail(mailBody, callback)
    },





}
