const nodemailer = require('nodemailer')
module.exports = {

    forgot: function (email, subject, name, otp, callback) {

        let html = `<body style="margin: 0;padding: 0;background: #e0e0e0;font-family: 'Roboto',sans-serif;">
        <div class="sl-email" style="width:550px;margin:20px auto;padding:0 25px;background:#fff;color:#555555;line-height:20px">
            <div class="header" style="text-align: center;padding:15px 0;border-bottom: 2px solid #222222;margin-bottom: 30px;">
                <div class="logo" style="width: 300px;margin: 20px auto;">
                     <img src=${process.env.logo} width="200" alt="Logo">
                </div>
            </div>
            <div class="mail-body">
                <p style="font-size: 16px;margin-top: 0;">Dear <span style="color: #222222;"><b>${name}</b>,</span> </p>
    
                <table cellpadding="0" cellspacing="0" style="max-width:100%; min-width:100%;" width="100%" class="mcnTextContentContainer">
                    <tbody>
                        <tr>    
                            <td valign="top" class="mcnTextContent" style="padding-top:0; padding-bottom:9px;">
    
                                <h1 style="font-size:16px;margin-bottom:0">Please verify your account on Doccure</h1>
                                <h2 style="font-size:16px;margin-bottom:0">Here is your One Time Password</h2>
                                <p style="font-size: 16px;margin-top: 0;">to reset your password </p>
                                <h3 style="font-size:20px;margin-bottom:0">${otp}</h3>
                                <p>Thank you.<br>
                                    <br>
                                    <strong>Doccure</strong>
                                </p>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>    
    </body>`
        const mailBody = {
            from: "<do_not_reply@gmail.com>",
            to: email,
            subject: subject,
            html: html
        };
        nodemailer.createTransport({
            service: 'GMAIL',
            auth: {
                user: process.env.NODEMAILER,
                pass: process.env.NODEMAILER_PASSWORD
            },
            port: 465,
            host: 'smtp.gmail.com'

        }).sendMail(mailBody, callback)
    },





}
