const nodemailer = require('nodemailer')



module.exports = {

    rejectRequest: function (email, subject, callback) {

        let html = `<body style="margin: 0;padding: 0;background: #e0e0e0;font-family: 'Roboto',sans-serif;padding:10px 0"">
        <style>
        .im{
            color:#000 !important
        }
        </style>
        <div class="sl-email" style="width:550px;margin:0px auto;padding:0 25px;background:#fff;color:#555555;line-height:20px">
            <div class="header" style="text-align: center;padding:15px 0;margin-bottom: 30px;border-bottom:1px solid #be141b;">
            <div class="logo" style="width: 300px;margin: 20px auto;">
            <img src=${process.env.logo} width="200" alt="Logo">
       </div>
            </div>
            <div class="mail-body"> 
                <table cellpadding="0" cellspacing="0" style="max-width:100%; min-width:100%;" width="100%" class="mcnTextContentContainer">
                    <tbody>
                        <tr>    
                            <td valign="top" class="mcnTextContent" style="padding-top:0; padding-bottom:9px;">
    
                            <p style="font-size:14px;">Thank you for your interest with the Gymdoctor.</p>
                            <p style="font-size:14px;">We've reviewed your request details closely, but unfortunately, we can't continue your service at this moment.</p>
          
                            <p style="font-size:14px;"> We appreciate your interest on our platform and wish you success for your future endeavour </p>          
                            <p style="font-size:14px;margin-bottom:0px;">Thanks,</p>
                                    <br>
                                    <strong>Gym Doctor Team</strong>
                                </p>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>    
    </body>`
        const mailBody = {
            from: "<do_not_reply@gmail.com>",
            to: email,
            subject: subject,
            html: html
        };
        nodemailer.createTransport({
            service: 'GMAIL',
            auth: {
                user: process.env.NODEMAILER,
                pass: process.env.NODEMAILER_PASSWORD
            },
            port: 465,
            host: 'smtp.gmail.com'

        }).sendMail(mailBody, callback)
    },





}
