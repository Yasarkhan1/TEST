const twilio = require('twilio')
var FCM = require('fcm-node')

module.exports = {
    getOTP() {
      var otp = Math.floor(1000 + Math.random() * 9000);
      return otp;
    },
  
    generateString: (length) => {
      const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789'
      let result = ' ';
      const charactersLength = characters.length;
      for (let i = 0; i < length; i++) {
        result += characters.charAt(Math.floor(Math.random() * charactersLength));
      }
      return result;
    },  /**
    * Function Name :sendSMS using twilio.
    * Description :sendSMS using twilio.
    * @return  response
    */
      sendSms: (phoneNumber, text, callback) => {
        let client = new twilio(process.env.TWILIO_SID,process.env.TWILIO_TOKEN);
        client.messages.create({
          body: 'Your otp-  ' + text,
          to: phoneNumber,
          from: process.env.TWILIO_NUMBER
      
        },
          (err, result) => {
            // console.log("sms part>>>37",err,result) 
            if (err) {
              // callback(err, null)
              console.log("Errorrr>>>>>>", err);
    
            } else {
              // callback(null, result)
              console.log("Successfulll", result)
            }
    
          })
      },

        //-------------------------Push notiFICATION----------
  pushNotification: (deviceToken, title, body, callback) => {
    var serverKey = process.env.SERVER_KEY
    var fcm = new FCM(serverKey);
    var message = {
      to: deviceToken, // required fill with device token or topics
      "content_available": true,
      priority: 'high',
      notification: {
        title: title,
        body: body
      }
    };

    //callback style
    console.log(">>>>>>>>>>>>>>>>>fcm", fcm)
    fcm.send(message, function (err, response) {
      if (err) {
        console.log(">>>>>>>>>>fcm Err", err)
        //callback(err, null)
      } else {
        console.log(">>>>>>>>>response", response)
        //callback(null, response)
      }
    });

  },

    //-----------------------CALL Push notiFICATION(SILENT PUSH)----------
    callPushNotification: (deviceToken, data, callback) => {
      var serverKey = process.env.SERVER_KEY
      var fcm = new FCM(serverKey);
  
      var message = {
        to: deviceToken, // required fill with device token or topics
        "content_available": true,
        priority: 1,
        data: data
      };
  
      console.log(">>>>>>>>>>>>>>>>>>>>>>>>message", message)
  
      //callback style
      fcm.send(message, function (err, response) {
        if (err) {
          console.log(">>>>>>>>>>fcm Err", err)
          //callback(err, null)
        } else {
          console.log(">>>>>>>>>response", response)
          //callback(null, response)
        }
      });
  
    },

  }