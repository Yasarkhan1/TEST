const nodemailer = require('nodemailer')
module.exports = {
sendMail:function (email, subject,otp, callback) {
    let html=`<!DOCTYPE html>
    <html class="gr__practicebuilders_com">
      <head>
        <meta http-equiv="content-type" content="text/html; charset=UTF-8">
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <title></title>
        <style>
        body {
        margin: 0;
        padding: 0;
        background: #eaeaea;
        }
        table {
          border-collapse: collapse;
        }
        td, th {
          font-family: Arial, sans-serif;
          color: #000;
          text-align: left;
          font-size: 14px;
        }
        table td p{
          margin:0;
        }
      @media only screen and (max-width: 600px) {
        body, table, td, p, a, li, blockquote {
          -webkit-text-size-adjust: none !important;
        }
        table {
          width: 100% !important;
        }
        table img {
          max-width: 100% !important;
          min-width: 15px;
        }
        tr td{text-align: left;}
       </style>
     </head>
     <body style="margin: 0;padding: 0;background: #e0e0e0;font-family: 'Roboto',sans-serif;padding:10px 0">

       <table cellpadding="15" cellspacing="0" style="width: 600px; margin:0 auto; font-family: Calibri, sans-serif; background-color: #ffffff;">
         <tr>
           <td style="text-align: center;">
          <div class="header" style="text-align: center;padding:15px 0;margin-bottom:0px;border-bottom:1px solid #be141b;">
            <div class="logo" style="width: 300px;margin: 20px auto;">
            <img src=${process.env.logo} width="200" alt="Logo">
       </div>
            </div>
           </td>
         </tr>
         <tr>
         <td>
             <h2 style="color: #555; font-size:20px;margin-top:0;margin-bottom:10px">Welcome to gymdoctor</h2>
             <p style="color: #555; font-size: 16px;margin:0"><strong >Here is your One Time Password</strong></p>
             <p style="color: #555; margin-bottom: 0; font-size: 16px;margin:0">to verify your account</p>
             <p style="color: #555; margin-bottom: 10px; margin-top:10px; font-size:20px; font-weight: bold;">${otp}</p>
           </td>
         </tr>
       </table>
     </body>
     </html>
    `  
    const mailBody = {
        from: "<do_not_reply@gmail.com>",
        to: email,
        subject: subject,
        html: html
    };
    nodemailer.createTransport({
        service: 'GMAIL',
        auth: {
            user: process.env.NODEMAILER,
            pass: process.env.NODEMAILER_PASSWORD
        },
        port: 465,
        host: 'smtp.gmail.com'

    }).sendMail(mailBody, callback)
}
}