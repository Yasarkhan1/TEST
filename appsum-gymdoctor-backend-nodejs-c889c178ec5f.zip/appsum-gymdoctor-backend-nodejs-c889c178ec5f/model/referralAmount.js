const mongoose = require('mongoose');
const schema = mongoose.Schema;

var referralInvitationAmount = new schema(
    {
        amount: {
            type: Number
        }
    },
);

module.exports = mongoose.model('referralInvitationAmount', referralInvitationAmount, 'referralInvitationAmount');
mongoose.model('referralInvitationAmount', referralInvitationAmount).find((error, result) => {
    if (result.length == 0) {
        let obj1 = {
            'amount': 10

        };
        mongoose.model('referralInvitationAmount', referralInvitationAmount, 'referralInvitationAmount').create(obj1,
            (err, success) => {
                if (err)
                    console.log("Error is" + err)
                else
                    console.log("Static about_us content saved succesfully.", success);
            })
    }
});


