var mongoose = require("mongoose"),
    mongoosePaginate = require("mongoose-paginate"),
    schema = mongoose.Schema,
    withdrawAmount = new schema(
        {
            userId: { type: schema.Types.ObjectId, ref: 'user' },
            amount: { type: Number },
            bankName:{ type: String},
            ifscCode:{ type:String},
            accountHolderName:{ type:String},
            accountNumber:{ type:String},
            branchName:{ type:String},
            paymentStatus: {
                type: String,
                enum: ["PENDING", "PAID", "REJECTED"],
                default: "PENDING"
            },
            status: {
                type: String,
                enum: ["ACTIVE", "DELETE"],
                default: "ACTIVE"
            },

        },
        {
            timestamps: true,
        }
    );

withdrawAmount.plugin(mongoosePaginate);
module.exports = mongoose.model("withdrawAmount", withdrawAmount, "withdrawAmount");
