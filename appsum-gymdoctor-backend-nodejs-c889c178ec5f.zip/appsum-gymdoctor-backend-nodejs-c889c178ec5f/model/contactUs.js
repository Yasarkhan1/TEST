const mongoose = require("mongoose")
const mongoosePaginate = require("mongoose-paginate")
const schema = mongoose.Schema
const contactUs = new schema(
    {
        name: { type: String },
        mobileNumber: { type: String },
        email: { type: String },
        message: { type: String },
        status: {
            type: String,
            enum: ["ACTIVE", "BLOCK", "DELETE"],
            default: "ACTIVE"
        },
    },
    {
        timestamps: true,
    }
);

contactUs.plugin(mongoosePaginate);
module.exports = mongoose.model("contactUs", contactUs, "contactUs");
