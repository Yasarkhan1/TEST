const mongoose = require("mongoose")
const mongoosePaginate = require("mongoose-paginate")
const schema = mongoose.Schema
const invoiceModel = new schema(
    {
        invoiceNumber: { type: String },
        paymentType:{ type:String},
        cardNumber:{type:String},
        patientId: { type: schema.Types.ObjectId, ref: 'user' },
        serviceProviderId: { type: schema.Types.ObjectId, ref: 'user' },
        subscriptionId: { type: schema.Types.ObjectId, ref: 'subscription' },
        laboratoryId: { type: schema.Types.ObjectId, ref: 'laboratory' },
        amount: { type: Number },
        paidDate: { type: Date, default: new Date() },
        invoiceFrom: { type: schema.Types.ObjectId, ref: 'user' }, // to show in admin panel 
        status: {
            type: String,
            enum: ["ACTIVE", "BLOCK", "DELETE"],
            default: "ACTIVE"
        },
        invoiceType: {
            type: String,
            enum: ["SUBSCRIPTION", "APPOINTMENT","LABORATORY"],
            default: "APPOINTMENT"
        },
    },
    {
        timestamps: true,
    }
);
invoiceModel.plugin(mongoosePaginate);
module.exports = mongoose.model("invoiceModel", invoiceModel, "invoiceModel");
