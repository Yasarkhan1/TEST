const mongoose = require("mongoose");
const mongoosePaginate = require("mongoose-paginate");
const schema = mongoose.Schema
const prescription = new schema(
    {
        patientId: { type: schema.Types.ObjectId, ref: 'user' },
        serviceProviderId: { type: schema.Types.ObjectId, ref: 'user' },
        appointmentId: { type: schema.Types.ObjectId, ref: 'appointment' },
        name: { type: String },
        quantity: { type: Number },
        number_of_days: { type: Number },
        description: { type: String },
        signature: { type: String },
        timing: [String],
        issueDate: { type: Date, default: Date.now },
        dueDate: { type: Date },
        status: {
            type: String,
            enum: ["ACTIVE", "BLOCK", "DELETE"],
            default: "ACTIVE"
        },
    },
    {
        timestamps: true,
    }
);

prescription.plugin(mongoosePaginate);
module.exports = mongoose.model("prescription", prescription, "prescription");
