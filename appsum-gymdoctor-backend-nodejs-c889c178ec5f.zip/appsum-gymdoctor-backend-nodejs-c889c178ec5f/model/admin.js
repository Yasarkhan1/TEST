const mongoose = require('mongoose');
const schema = mongoose.Schema;
const bcrypt = require('bcrypt-nodejs')
const Paginate = require('mongoose-paginate');

var adminModel = new schema({
    firstName: {
        type: String,
        trim: true
    },
    lastName: {
        type: String,
        trim: true
    },
    email: {
        type: String,
        require: true,
        unique: true,
        lowercase: true,
        trim: true
    },
    countryCode:{
        type:String
    },
    mobileNumber:{
        type:String
    },
    designation:{
        type:String
    },
    profilePic: {
        type: String,
        default: ''
    },
    password: {
        type: String,
        trim: true
    },
    otp: {
        type: Number
    },
    isEmailVerified: {
        type: Boolean,
        default: false
    },
    otpTime: {
        type: Number
    },
    userType: {
        type: String,
        enum: ["ADMIN", "SUBADMIN"],
        default: "ADMIN"
    },
    status: {
        type: String,
        enum: ["ACTIVE", "BLOCK", "DELETE"],
        default: "ACTIVE"
    },
    designation:String,
    permissions:{
        dashboard:Boolean,
        appointments:Boolean,
        specialities:Boolean,
        serviceProviders:Boolean,
        patients:Boolean,
        reviews:Boolean,
        earning:Boolean, 
        reports:Boolean,
        subscription:Boolean,
        laboratory:Boolean,
        subAdmin:Boolean,
        help:Boolean,
        coupon:Boolean,
        referral:Boolean,
        notification:Boolean,
        content:Boolean,
        setting:Boolean,
        ourTeam:Boolean,
        contactUs:Boolean,
        testimonial:Boolean,
        withdrawRequest:Boolean


    }

}, { timestamps: true });

adminModel.plugin(Paginate);
module.exports = mongoose.model("admin", adminModel);
mongoose.model("admin", adminModel).find({ userType: "ADMIN" }, (err, result) => {
    if (err) {
        console.log("DEFAULT ADMIN ERROR", err);
    } else if (result.length != 0) {
        console.log("Default Admin.");
    } else {
        let obj = {
            userType: "ADMIN",
            firstName: "gym",
            lastName: "doctor",
            isEmailVerified: true,
            profilePic: "https://res.cloudinary.com/dkoznoze6/image/upload/v1563943105/n7zdoyvpxxqhexqybvkx.jpg",
            email: "appsum123@gmail.com",
            password: bcrypt.hashSync("admin1234"),
        };
        mongoose.model("admin", adminModel).create(obj, (err1, result1) => {
            if (err1) {
                console.log("DEFAULT ADMIN  creation ERROR", err1);
            } else {
                console.log("DEFAULT ADMIN Created", result1);
            }
        });
    }
});