var mongoose = require("mongoose"),
    mongoosePaginate = require("mongoose-paginate"),
    schema = mongoose.Schema,
    card = new schema(
        {
            userId: { type: schema.Types.ObjectId, ref: 'user' },
            cardType: { type: String, enum: ["DEBIT", "CREDIT"] },
            cardHolderName: { type: String },
            cardNumber: { type: String },
            expMonth: {
                type: String,
            },
            expYear: {
                type: String,
            },
            isPrimary: { type: Boolean, default: false },
            status: {
                type: String,
                enum: ["ACTIVE", "BLOCK", "DELETE"],
                default: "ACTIVE"
            },
        },
        {
            timestamps: true,
        }
    );

card.plugin(mongoosePaginate);
module.exports = mongoose.model("card", card, "card");
