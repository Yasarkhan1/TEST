const mongoose = require('mongoose');
const schema = mongoose.Schema;

var mongoosePaginate = require('mongoose-paginate');
let transactionModel = new schema({
    userId: {
        type: schema.Types.ObjectId,
        ref: 'user'
    },
    transactionId: {
        type: String
    },
    chargeId: {
        type: String
    },
    customerId: {
        type: String
    },
    url: {
        type: String
    },
    paymentType: {
        type: String
    },
    currency: {
        type: String,
        default: "USD"
    },
    amount: {
        type: Number,
    },
    email: {
        type: String
    },
    transactionStatus: {
        type: String
    }
}, {
    timestamps: true
})

transactionModel.plugin(mongoosePaginate);
module.exports = mongoose.model('transaction', transactionModel,'transaction');