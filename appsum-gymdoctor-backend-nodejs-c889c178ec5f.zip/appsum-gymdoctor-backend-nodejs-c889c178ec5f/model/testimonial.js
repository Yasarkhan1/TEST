const mongoose = require("mongoose");
const mongoosePaginate = require("mongoose-paginate");
const schema = mongoose.Schema;
const testimonial = new schema(
    {

        name: { type: String },
        designation: { type: String },
        image: { type: String },
        description: { type: String },
        status: {
            type: String,
            enum: ["ACTIVE", "BLOCK", "DELETE"],
            default: "ACTIVE"
        },
    },
    {
        timestamps: true,
    }
);

testimonial.plugin(mongoosePaginate);
module.exports = mongoose.model("testimonial", testimonial, "testimonial");
