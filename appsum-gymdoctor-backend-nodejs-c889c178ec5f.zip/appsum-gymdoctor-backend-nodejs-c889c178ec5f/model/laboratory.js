var mongoose = require("mongoose"),
    mongoosePaginate = require("mongoose-paginate"),
    mongooseAggregatePaginate = require('mongoose-aggregate-paginate');

    schema = mongoose.Schema,
    laboratory = new schema(
        {
            name: {
                type: String,
            },
            image: {
                type: String,
            },
            serviceType: {
                type: String,
                enum: ["HOME_LOCATION", "LABORATORY_LOCATION", "BOTH"]
            },
            location: {
                address: String,
                type: {
                    type: String,
                    default: "Point",
                },
                coordinates: []
            },
            city: {
                type: String,
            },
            state: {
                type: String,
            },
            postalCode: {
                type: String,
            },
            availability:[{
                day:String,
                startTime:String,
                endTime:String,
                interval:Number,
                slots:[{
                    slotTime:String,
                    status: {
                        type: String,
                        enum: ["ACTIVE", "INACTIVE", "DELETE"],
                        default: "ACTIVE"
                    }           
                }]
            }],
            status: {
                type: String,
                enum: ["ACTIVE", "BLOCK", "DELETE"],
                default: "ACTIVE"
            },
        },
        {
            timestamps: true,
        }
    );

laboratory.plugin(mongoosePaginate);
laboratory.index({ location: "2dsphere" });
laboratory.plugin(mongooseAggregatePaginate);
module.exports = mongoose.model("laboratory", laboratory, "laboratory");
