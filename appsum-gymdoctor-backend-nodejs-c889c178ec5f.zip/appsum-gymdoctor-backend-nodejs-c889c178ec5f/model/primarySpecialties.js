var mongoose = require("mongoose"),
    mongoosePaginate = require("mongoose-paginate"),
    schema = mongoose.Schema,
    primary_specialty = new schema(
        {

            primary_specialty: {
                type: String,
            },
            description: {
                type: String,
            },
            image: {
                type: String,
            },
            status: {
                type: String,
                enum: ["ACTIVE", "BLOCK", "DELETE"],
                default: "ACTIVE"
            },
        },
        {
            timestamps: true,
        }
    );

primary_specialty.plugin(mongoosePaginate);
module.exports = mongoose.model("primary_specialty", primary_specialty, "primary_specialty");
