const mongoose = require("mongoose")
const mongoosePaginate = require("mongoose-paginate")
const schema = mongoose.Schema
const teamMember = new schema(
    {
        name: { type: String },
        image: { type: String },
        designation: { type: String },
        status: {
            type: String,
            enum: ["ACTIVE", "BLOCK", "DELETE"],
            default: "ACTIVE"
        },
    },
    {
        timestamps: true,
    }
);

teamMember.plugin(mongoosePaginate);
module.exports = mongoose.model("teamMember", teamMember, "teamMember");
