const mongoose = require('mongoose');
const schema = mongoose.Schema;
var Paginate = require('mongoose-paginate');
const mongooseAggregatePaginate = require('mongoose-aggregate-paginate');
const labAppointment = new schema({
    sample_collection_type: {
        type: String,
        enum: ['HOME', 'LOCATION'],
        default: 'LOCATION'
    },
    name: {
        type: String
    },
    date_of_birth: {
        type: String
    },
    mobileNumber: {
        type: String
    },
    email: {
        type: String
    },
    gender: {
        type: String
    },
    location: {
        address: String,
        type: {
            type: String,
            default: "Point"
        },
        coordinates: []
    },
    address: {
        type: String
    },
    pincode: {
        type: String
    },
    landmark: {
        type: String
    },
    patientId: {
        type: schema.Types.ObjectId,
        ref: "user"
    },
    packageId: {
        type: schema.Types.ObjectId,
        ref: "package"
    },
    laboratoryId: {
        type: schema.Types.ObjectId,
        ref: "laboratory"
    },
    slotId: {
        type: schema.Types.ObjectId,
        ref: "user"
    },
    dayId: {
        type: schema.Types.ObjectId,
        ref: "user"
    },
    bookingDate: {
        type: Date
    },
    appointmentStartTime: {
        type: Date
    },
    appointmentEndTime: {
        type: Date
    },

    status: {
        type: String,
        enum: ['pending', 'cancelled', 'accepted', 'rejected', 'rescheduled'],
        default: 'accepted'
    },
    amount: {
        type: Number
    },
    paymentStatus: {   // payment status which paid by user  after booking.
        type: String,
        enum: ['due', 'paid'],
        default: 'paid'
    },
    oldAppointmentId: {
        type: schema.Types.ObjectId,
        ref: "appointment"
    },
    reportStatus: {
        type: String,
        enum: ['pending',"delivered"],
        default: 'pending'
    },
    reportDateTime: {
        type: Date
    },
    reportFile: { type: String },
    deliveryStatus: [String] //   HOME/MAIL

}, { timestamps: true })
labAppointment.index({ location: "2dsphere" });
labAppointment.plugin(Paginate);
labAppointment.plugin(mongooseAggregatePaginate);
module.exports = mongoose.model("labAppointment", labAppointment, "labAppointment");