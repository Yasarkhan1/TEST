var mongoose = require("mongoose"),
    mongoosePaginate = require("mongoose-paginate"),
    schema = mongoose.Schema,
    referral = new schema(
        {
            userId: { type: schema.Types.ObjectId, ref: 'user' },
            joinerId: { type: schema.Types.ObjectId, ref: 'user' },
            referralCode: { type: String },
            referralUrl: { type: String },
            status: {
                type: String,
                enum: ["Joined", "Pending"],
                default: "Pending"
            },
        },
        {
            timestamps: true,
        }
    );

    referral.plugin(mongoosePaginate);
module.exports = mongoose.model("referral", referral, "referral");
