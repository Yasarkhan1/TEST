var mongoose = require("mongoose"),
    mongoosePaginate = require("mongoose-paginate"),
    schema = mongoose.Schema,
    mongooseAggregatePaginate = require('mongoose-aggregate-paginate'),

    searchHistory = new schema(
        {
            userId: { type: schema.Types.ObjectId, ref: 'user' },
            specialtyId: { type: schema.Types.ObjectId, ref: 'specialty' },
            location: {
                type: {
                    type: String,
                    default: "Point"
                },
                coordinates: []
            },
            status: {
                type: String,
                enum: ["ACTIVE", "BLOCK", "DELETE"],
                default: "ACTIVE"
            }
        },
        {
            timestamps: true,
        }
    );

searchHistory.plugin(mongoosePaginate);
searchHistory.index({ location: "2dsphere" });
searchHistory.plugin(mongooseAggregatePaginate);
module.exports = mongoose.model("searchHistory", searchHistory, "searchHistory");
