var mongoose = require("mongoose"),
    mongoosePaginate = require("mongoose-paginate"),
    schema = mongoose.Schema,
    wallet = new schema(
        {
            userId: { type: schema.Types.ObjectId, ref: 'user' },
            subscriptionId: { type: schema.Types.ObjectId, ref: 'subscription'},
            userType: { type: String },
            totalBalance: { type: Number },
            minutesOfAudioCalls: { type: Number },
            minutesOfVideoCalls: { type: Number },
            numberOfPrimarySpecialty: { type: Number },
            numberOfSecondrySpecialty: { type: Number },
            numberOfLeads: { type: Number },
            numberOfMessages: { type: Number },
            isFeatured: {type: Boolean,default: false},
            sessions:{ type: Number,default:0},
            expiryDate :{ type:Date}
        },
        {
            timestamps: true,
        }
    );

wallet.plugin(mongoosePaginate);
module.exports = mongoose.model("wallet", wallet, "wallet");
