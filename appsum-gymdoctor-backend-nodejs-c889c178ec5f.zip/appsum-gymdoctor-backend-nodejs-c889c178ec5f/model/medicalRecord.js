const mongoose = require("mongoose");
const mongoosePaginate = require("mongoose-paginate");
const schema = mongoose.Schema
const medicalRecord = new schema(
    {
        patientId: { type: schema.Types.ObjectId, ref: 'user' },
        serviceProviderId: { type: schema.Types.ObjectId, ref: 'user' },
        name: { type: String },
        description: { type: String },
        medicalRecordFile: { type: String },
        status: {
            type: String,
            enum: ["ACTIVE", "BLOCK", "DELETE"],
            default: "ACTIVE"
        },
    },
    {
        timestamps: true,
    }
);

medicalRecord.plugin(mongoosePaginate);
module.exports = mongoose.model("medicalRecord", medicalRecord, "medicalRecord");
