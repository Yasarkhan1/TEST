var mongoose = require("mongoose"),
    mongoosePaginate = require("mongoose-paginate"),
    schema = mongoose.Schema,
    rating = new schema(
        {
            userId: { type: schema.Types.ObjectId, ref: 'user' },
            doctorId: { type: schema.Types.ObjectId, ref: 'user' },
            rating: { type: Number },
            review: { type: String },
            overAllServices: { type: Number },
            attentiveness: { type: Number },
            supportive: { type: Number }, 
            serviceQuality: { type: Number },
            challenge: { type: String },
            isChallenged: { type: Boolean, default: false },
            status: {
                type: String,
                enum: ["ACTIVE", "BLOCK", "DELETE"],
                default: "ACTIVE"
            },
        },
        {
            timestamps: true,
        }
    );

rating.plugin(mongoosePaginate);
module.exports = mongoose.model("rating", rating, "rating");
