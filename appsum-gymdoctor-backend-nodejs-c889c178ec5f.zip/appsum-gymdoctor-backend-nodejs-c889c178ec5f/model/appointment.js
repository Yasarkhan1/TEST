const mongoose = require('mongoose');
const schema = mongoose.Schema;
var Paginate = require('mongoose-paginate');
const mongooseAggregatePaginate = require('mongoose-aggregate-paginate');
const appointment = new schema({

    reason: {
        type: String
    },
    cancelReason: {
        type: String
    },
    document: {
        type: String
    },
    patientId: {
        type: schema.Types.ObjectId,
        ref: "user"
    },
    serviceProviderId: {
        type: schema.Types.ObjectId,
        ref: "user"
    },
    slotId: {
        type: schema.Types.ObjectId,
        ref: "user"
    },
    dayId: {
        type: schema.Types.ObjectId,
        ref: "user"
    },
    bookingDate: {
        type: Date
    },
    appointmentStartTime: {
        type: Date
    },
    appointmentEndTime: {
        type: Date
    },

    status: {
        type: String,
        enum: ['pending', 'cancelled', 'accepted', 'rejected', 'rescheduled'],
        default: 'accepted'
    },
    appointmentType: {
        type: String,
        enum: ['SUBSCRIPTION', 'BANK_CARD'],
        default: 'SUBSCRIPTION'
    },
    amount: {
        type: Number
    },
    is_counted: {
        type: Boolean,
        default: false
    },
    paymentStatus: {   // payment status which paid by user  after booking.
        type: String,
        enum: ['due', 'paid'],
        default: 'due'
    },

    serviceProviderPaymentStatus: {  // amount which is paid by admin to provider
        type: String,
        enum: ['due', 'paid'],
        default: 'due'
    },
    oldAppointmentId: {
        type: schema.Types.ObjectId,
        ref:"appointment"
    },

}, { timestamps: true })

appointment.plugin(Paginate);
appointment.plugin(mongooseAggregatePaginate);
module.exports = mongoose.model("appointment", appointment, "appointment");