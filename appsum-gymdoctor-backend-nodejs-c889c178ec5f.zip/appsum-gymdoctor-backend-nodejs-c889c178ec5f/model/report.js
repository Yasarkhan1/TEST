const mongoose = require("mongoose");
const mongoosePaginate = require("mongoose-paginate");
const schema = mongoose.Schema
const report = new schema(
    {
        patientId: { type: schema.Types.ObjectId, ref: 'user' },
        packageId: { type: schema.Types.ObjectId, ref: 'package' },
        appointmentId: { type: schema.Types.ObjectId, ref: 'labAppointment' },
        reportFile: { type: String },
        deliveryStatus: [String] //   HOME/MAIL
    },
    {
        timestamps: true,
    }
);

report.plugin(mongoosePaginate);
module.exports = mongoose.model("report", report, "report");
