var mongoose = require("mongoose"),
    mongoosePaginate = require("mongoose-paginate"),
    schema = mongoose.Schema,
    help = new schema(
        {
            userId: { type: schema.Types.ObjectId, ref: 'user' },
            subject: { type: String },
            message: { type: String },
            userType:{ type:String},
            isRead: {
                type: Boolean,
                default: false
            },
            status: {
                type: String,
                enum: ["ACTIVE", "BLOCK", "DELETE"],
                default: "ACTIVE"
            },
        },
        {
            timestamps: true,
        }
    );

    help.plugin(mongoosePaginate);
module.exports = mongoose.model("help", help, "help");
