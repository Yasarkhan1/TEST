var mongoose = require("mongoose"),
    mongoosePaginate = require("mongoose-paginate"),
    schema = mongoose.Schema,
    subscription = new schema(
        {
            name: { type: String },
            price: { type: Number },
            applicability: {
                type: String,
                enum: ["PATIENT", "DOCTOR"]
            },
            minutesOfAudioCalls: { type: Number },
            minutesOfVideoCalls: { type: Number },
            // numberOfPrimarySpecialty: { type: Number },
            numberOfSecondrySpecialty: { type: Number },
            numberOfLeads: { type: Number },
            numberOfMessages: { type: Number },
            days_duration:{ type: Number},
            session_numbers:{ type: Number},
            isFeatured: {type: Boolean,default: false},
            status: {
                type: String,
                enum: ["ACTIVE", "BLOCK", "DELETE"],
                default: "ACTIVE"
            },
        },
        {
            timestamps: true,
        }
    );

subscription.plugin(mongoosePaginate);
module.exports = mongoose.model("subscription", subscription, "subscription");
