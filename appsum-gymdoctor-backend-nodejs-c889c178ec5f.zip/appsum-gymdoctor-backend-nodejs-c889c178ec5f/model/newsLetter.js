const mongoose = require("mongoose")
const mongoosePaginate = require("mongoose-paginate")
const schema = mongoose.Schema
const newsLetter = new schema(
    {
        name: { type: String },
        email: { type: String },
        status: {
            type: String,
            enum: ["ACTIVE", "BLOCK", "DELETE"],
            default: "ACTIVE"
        },
    },
    {
        timestamps: true,
    }
);

newsLetter.plugin(mongoosePaginate);
module.exports = mongoose.model("newsLetter", newsLetter, "newsLetter");
