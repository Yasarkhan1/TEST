var mongoose = require("mongoose"),
    mongoosePaginate = require("mongoose-paginate"),
    schema = mongoose.Schema,
    helpMessage = new schema(
        {
            ticketId: { type: schema.Types.ObjectId, ref: 'help' },
            userId: { type: schema.Types.ObjectId, ref: 'user' },
            adminId: { type: schema.Types.ObjectId, ref: 'admin' },
            message: { type: String },
            replyBy: { type: String },
            userType: { type: String },
            status: {
                type: String,
                enum: ["ACTIVE", "BLOCK", "DELETE"],
                default: "ACTIVE"
            },
        },
        {
            timestamps: true,
        }
    );

    helpMessage.plugin(mongoosePaginate);
module.exports = mongoose.model("helpMessage", helpMessage, "helpMessage");
