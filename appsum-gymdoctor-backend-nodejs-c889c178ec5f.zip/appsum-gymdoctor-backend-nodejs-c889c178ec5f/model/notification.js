const mongoose = require('mongoose');
const paginate = require('mongoose-paginate');
const schema = mongoose.Schema;

let notification = new schema({
    userId: {
        type: schema.Types.ObjectId,
        ref: 'user'
    },
    title: {
        type: String
    },
    body: {
        type: String
    },
    notificationType: {
        type: String,
        enum: ["BOOKING", "CANCEL", "REQUEST", "RESCHEDULE",
            "ACCEPTED", "REJECTED", "BROADCAST",
            "REPORT", "PAYMENT_WITHDRAW", "PRESCRIPTION", "MEDICAL_RECORDS", "HELP_MESSAGE", "SUBSCRIPTION","NONE"]
    },
    isRead: {
        type: Boolean,
        default: false
    },
    isAdminInvolved: {
        type: Boolean,
        default: false
    },
    appointmentId: {
        type: schema.Types.ObjectId,
        ref: 'appointment'
    },
    senderId: {
        type: schema.Types.ObjectId,
        ref: 'admin'
    },
    status: {
        type: String,
        enum: ["ACTIVE", "BLOCK", "DELETE"],
        default: "ACTIVE"
    },
}, {
    timestamps: true,
})
notification.plugin(paginate);
module.exports = mongoose.model("notification", notification, "notification");