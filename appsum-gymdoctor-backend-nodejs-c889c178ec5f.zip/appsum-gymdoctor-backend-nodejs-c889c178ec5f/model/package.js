var mongoose = require("mongoose"),
    mongoosePaginate = require("mongoose-paginate"),
    schema = mongoose.Schema,
    package = new schema(
        {
            laboratoryId: { type: schema.Types.ObjectId, ref: 'laboratory' },
            name: { type: String },
            image: { type: String },
            description: { type: String },
            price: { type: Number },
            discounted_price: { type: Number },
            status: {
                type: String,
                enum: ["ACTIVE", "BLOCK", "DELETE"],
                default: "ACTIVE"
            },
        },
        {
            timestamps: true,
        }
    );

package.plugin(mongoosePaginate);
module.exports = mongoose.model("package", package, "package");
