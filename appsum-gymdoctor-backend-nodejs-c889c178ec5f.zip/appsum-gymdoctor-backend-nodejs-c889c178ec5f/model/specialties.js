var mongoose = require("mongoose"),
    mongoosePaginate = require("mongoose-paginate"),
    schema = mongoose.Schema,
    specialty = new schema(
        {

            // primary_specialty: {
            //     type: String,
            //     enum: ["Physician", "Coach_Practitioner", "Metabolic_Centres"]
            // },
            primary_specialtyId: { type: schema.Types.ObjectId, ref: 'primary_specialty' },
            secondry_specialty: {
                type: String,
            },
            image: {
                type: String,
            },
            status: {
                type: String,
                enum: ["ACTIVE", "BLOCK", "DELETE"],
                default: "ACTIVE"
            },
        },
        {
            timestamps: true,
        }
    );

specialty.plugin(mongoosePaginate);
module.exports = mongoose.model("specialty", specialty, "specialty");
