const mongoose = require('mongoose');
const schema = mongoose.Schema;
const bcrypt = require('bcrypt-nodejs')
const Paginate = require('mongoose-paginate');
const mongooseAggregatePaginate = require('mongoose-aggregate-paginate');


var userModel = new schema({

    // profle 
    firstName: { type: String, trim: true },
    lastName: { type: String, trim: true },
    fullName: { type: String, trim: true },
    email: { type: String, require: true, trim: true },
    countryCode: { type: String },
    mobileNumber: { type: String },
    profilePic: { type: String, default: '' },
    gender: { type: String },
    date_of_birth: { type: String },
    marital_status: { type: String },
    bio: { type: String },
    password: { type: String, trim: true },
    otp: { type: Number },
    rating: { type: Number, default: 0 },
    isVerified: { type: Boolean, default: false },
    isPersonal_profile_complete: { type: Boolean, default: false },
    isMedical_profile_complete: { type: Boolean, default: false },
    isSubscribe: { type: Boolean, default: false },
    subscriptionId: { type: schema.Types.ObjectId, ref: 'subscription' },
    isFeatured: { type: Boolean, default: false },
    otpTime: { type: Number },
    userType: {
        type: String,
        enum: ["PATIENT", "DOCTOR"]
    },
    deviceType: {
        type: String,
        enum: ["ANDROID", "WEB","IOS"]
    },
    deviceToken:{
        type:String
    }, 
    location: {
        address: String,
        type: {
            type: String,
            default: "Point"
        },
        coordinates: []
    },
    pincode: { type: String },

    // Medical details of patient
    height: { type: String },
    weight: { type: String },
    bloodGroup: { type: String },
    iSDiabetes: { type: Boolean, default: false },
    diabetesDetails: { type: String },
    allergyDeatils: { type: String },
    familyNotes: { type: String },
    medicalFile: { type: String },

    // professional details of doctor
    // primary_specialty: { type: String },  //  enum: ["Physician", "Coach_Practitioner", "Metabolic_Centres"]
    primary_specialtyId: { type: schema.Types.ObjectId, ref: 'primary_specialty' },
    secondry_specialty: [schema.Types.ObjectId],
    businessLogo: { type: String, default: '' },
    experience_in_years: {
        type: Number,
        trim: true
    },
    experience_in_months: {
        type: Number,
        trim: true
    },
    licenceNumber: {
        type: String
    },
    degreeFile: {
        type: String                          // Additional requirement for this keyin doctor signup.(dont have idea where to show)
    },
    serviceCharge: { type: Number },
    availability: [{
        day: String,
        startTime: String,
        endTime: String,
        interval: Number,
        slots: [{
            slotTime: String,
            status: {
                type: String,
                enum: ["ACTIVE", "BLOCK", "DELETE"],
                default: "ACTIVE"
            }
        }]
    }],
    isProfessional_profile_complete: { type: Boolean, default: false },
    offset: {
        type: Number
    },
    expiryDate: { type: Date },
    favourites: [{ type: schema.Types.ObjectId, ref: 'user' }],
    ratingArray: [{ type: schema.Types.ObjectId, ref: 'user' }],
    joinStatus: {
        type: String,
        enum: ["Pending", "Approved", "Rejected"],
        default: "Pending"
    },
    status: {
        type: String,
        enum: ["ACTIVE", "BLOCK", "DELETE"],
        default: "ACTIVE"
    },
    totalAppointment: {
        type: Number,
        default: 0
    },
    socketId: String,
    isOnline:{
      type:Boolean,
      default:false
    },

}, { timestamps: true });
userModel.index({ location: "2dsphere" });
userModel.plugin(Paginate);
userModel.plugin(mongooseAggregatePaginate);
module.exports = mongoose.model("user", userModel, 'user');