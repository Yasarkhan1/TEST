const express = require('express');
const router = express.Router();



const admin = require('./route/admin/admin');
router.use('/admin/account', admin)
const primarySpecialty = require('./route/admin/primarySpecialty');
router.use('/admin/primarySpecialty',primarySpecialty)

const specialty = require('./route/admin/specialty');
router.use('/admin/specialty',specialty)

const subscription = require('./route/admin/subscription');
router.use('/admin/subscription',subscription)

const subadmin = require('./route/admin/subadmin');
router.use('/admin/subadmin', subadmin)

const user = require('./route/admin/patient');
router.use('/admin/user', user)

const serviceProvider = require('./route/admin/serviceProvider');
router.use('/admin/serviceProvider', serviceProvider)

const help = require('./route/admin/help');
router.use('/admin/help', help)

const static = require('./route/admin/cms');
router.use('/admin/static', static)

const coupon = require('./route/admin/coupon');
router.use('/admin/coupon', coupon) 

const laboratory = require('./route/admin/laboratory');
router.use('/admin/laboratory', laboratory)

const testimonial = require('./route/admin/testimonial');
router.use('/admin/testimonial',testimonial)

const team = require('./route/admin/teamMember');
router.use('/admin/team',team)

const contactUs = require('./route/admin/contactUs');
router.use('/admin/contactUs',contactUs)

const dashboard = require('./route/admin/dashboard');
router.use('/admin/dashboard',dashboard)

const review = require('./route/admin/review');
router.use('/admin/review',review)

const referral = require('./route/admin/referral');
router.use('/admin/referral',referral)

const appointment = require('./route/admin/appointment');
router.use('/admin/appointment',appointment)

const notification = require('./route/admin/notification');
router.use('/admin/notification',notification)

const earning = require('./route/admin/earning');
router.use('/admin/earning',earning)

const payment = require('./route/admin/withdrawRequest');
router.use('/admin/payment',payment)



const common = require('./route/common/common');
router.use('/common',common)


//**********************DOCTOR APP*************** */

const doctor = require('./route/doctor/doctor');
router.use('/doctor',doctor)
const patient = require('./route/user/patient');
router.use('/patient',patient)
const cms = require('./route/static/static');
router.use('/cms',cms)

//****************CALL ROUTES***************************/
const call = require('./route/call/call');
router.use('/call',call)

module.exports = router;

