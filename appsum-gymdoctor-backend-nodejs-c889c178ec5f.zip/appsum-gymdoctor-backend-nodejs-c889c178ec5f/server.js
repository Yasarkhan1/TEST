const express = require('express')
const bodyParser = require("body-parser");
require('./loader/dbConnect');
const Port = process.env.PORT
const index = require('./index')
const app = express()
const morgan = require('morgan');
const cors = require('cors')
//const path = require('path');
dotenv = require('dotenv');
dotenv.config();
const myCron = require('./controller/common/common')
var cron = require('node-cron');
app.use(cors());
const http = require('http')
const server = http.createServer(app);
const io = require('socket.io')(server,{
  cors:{
    origin:["https://api.flexuslab.us","http://localhost:3000",,"https://flexuslab.us","http://localhost:4000","http://3.139.149.219:4000"],
    methods: ["GET", "POST"],
      transports: ['polling'],
      // transports: ['websocket'],
    credentials: true
  }
});
require('./controller/chat/chat')(io);

app.use(bodyParser.urlencoded({ extended: true, limit: "50mb",parameterLimit: 1000000}));
app.use(bodyParser.json({ limit: "50mb" }));
app.use(morgan('dev'))

app.use('/api/v1', index)
cron.schedule('*/2 * * * *', () => {
  console.log("Cron is running for appointment count update of user")
  myCron.appointment_Count_Update()
})


server.listen(Port, function () {

  console.log("Server is listening on",Port)
})



//H6xg8h7UKZ7nK3spUG7s  app password

