/** 
 * @description All the Error messages that needed to be sent to Admin or App
 * @type {Object}
*/
module.exports.ErrorMessage = Object.freeze({
    INVALID_TOKEN: 'Unauthorized user.',
    INTERNAL_ERROR: 'Internal Server Error.',
    INVALID_CREDENTIAL: 'Invalid credentials.Please enter valid credentials.',
    NO_TOKEN: 'Please provide token.',
    SOMETHING_WRONG: 'Unexpected error!',
    NOT_FOUND: 'Data not found.',
    USER_NOT_FOUND: 'This user does not exist.',
    INCORRECT_JWT: 'Invalid JWT token.',
    ALREADY_EXITS: "Already exits",
    EMAIL_NOT_REGISTERED: 'Provided email is not registered.',
    EMAIL_EXIST: 'This email already exists.',
    MOBILE_EXIST: 'This mobile number already exists.',
    OTP_EXPIRED: "OTP has expired, please try resend OTP.",
    INVALID_OTP: 'Invalid OTP',
    NEW_CONFIRM_INCORRECT:'New and confirm password are not similar.',
    OLD_PASSWORD_INCORRECT:'Old password is incorrect.',
    REQUEST_UNAPPROVED:"Your account is not approved by the administrator yet. Please recheck later",










    COUNTRY_EXIST: 'Country name already exist',
    ALREADY_EXIST: 'Already exists.',
    NOT_REGISTERED: "Provided email/mobile number is not registered.",
    RESET_PASSWORD_EXPIRED: 'Your Token has expired.',
    WRONG_PASSWORD: 'Please enter valid password.',
    INVALID_MOBILE: 'This mobile number is not valid.',
    UPDATE_NOT: "Unexpected error during update, please try again.",
    USERNAME_EXIST: 'This user name already exists.',
    USER_ID: 'A valid User Id is required.',
    BLOCKED_BY_ADMIN: 'You are not authorized, please contact Admin.',
    DELETED_BY_ADMIN: 'Your account is deleted, please contact Admin.',
    FIELD_REQUIRED: 'Fields are required.',
    OLD_PASSWORD: 'You have provided an incorrect old password.',
    FORBIDDEN: 'There was an error in sending email.',
    PASSMATCH: "Password do not match.",
    CATEGORY_EXIST: "This category name already exists.",
 
    



});

/** 
 * @description All the Success messages that needed to be sent to App or Admin .
 * @type {Object}
*/
module.exports.SuccessMessage = Object.freeze({
    SIGNUP_SUCCESSFULLY: "Otp sent",
    LOGIN_SUCCESS: 'Your login is successful.',
    LOGOUT_SUCCESS: 'Logout successfully.',
    DATA_SAVED: "Data is saved successfully.",
    UPDATE_SUCCESS: "Successfully updated.",
    DATA_FOUND: "Data found",
    VERIFY_OTP: 'OTP verified successfully.',
    RESET_SUCCESS: 'your password has been successfully reset',
    REGISTRATION_LINK: 'Otp sent to your mail,Please use otp to verify and complete your registration process',
    DELETE_SUCCESS: "Successfully deleted.",























    VERIFY_OTP_NEED:"Please verify  your otp first.",

    UPLOADED_URL: 'Uploaded successfully',
    OTP_SEND: 'Otp has been sent to your registered email,please use the same to verify.',
    PROFILE_UPDATE: "Your profile details has been updated sucessfully.",
    BOOKING_SUCCESS: "Congratulations, your appointment is confirmed",
    CARD_DELETE:"Card deleted successfully",
    AVAILABLE_SLOT:"Available slot found successfully",
    BOOKING_FOUND:"Booking list found successfully",
    CARD_ADD:"Card add successfully",
    FOLLOW_UP_REQUEST:"Follow-up request sent successfully",
    CANCEL_SUCCESS:"Appointment cancel successfully",
    RESCHEDULE_APPOINTMENT:"Appointment reschedule successfully with different time.",
    MOVED_APPOINTMENT:"Appointment moved successfully",
    REJECT_SUCCESS: "Successfully rejected.",
    ACCEPT_SUCCESS: "Successfully accepted.",
    RATING_SAVED:"Rating submitted successfully",
  
    //*********************************************** */
    CUSTOMER_VERIFY: 'Customer verified successfully',
    FORGET_SUCCESS: 'A password link has been sent to your registered ID.',
    PRODUCT_LIST_FETCH: 'Successfully fetched product list.',
    USER_LIST_FETCH: 'Successfully fetched user list.',
    AUTHORIZATION: 'This User is Authorized.',
    ACCOUNT_CREATION: 'Your account has been created successfully.',
    EMAIL_SEND: "Otp has been sent to your registered Email successfully.",
    PIN_SET: "Your Pin has been set successfully.",
    PASSWORD_UPDATE: "Your password has been updated successfully.",
    DETAIL_GET: "Details have been fetched successfully.",
    STATUS_UPDATED: "Your Status has been changed successfully.",
    BLOCK_SUCCESS: "Successfully blocked.",
    UNBLOCK_SUCCESS: "Successfully activated.",
    POST_LIKE: "Post liked successfully",
    POST_DISLIKE: "Post dislike successfully",
    HIDE_SUCCESS: "Successfully hidden.",
    SUB_ADMIN_CREATED: "Sub-admin has been created successfully.",
    SMS_SEND: "The SMS has been send to the buddies successfully.",
    DESTINATION_ADD: "Destination has been added successfully.",
    EDIT_SUCC: "Successfully edit.",
    POST_BOOKMARK: "Post has been bookmarked successfully.",
    EVENT_ADDED: "Event has been added successfully.",
    ACCOUNT_DELETE: "Your account deleted successfully.",
    REQUEST_SENT: "Friend request sent successfully.",
    GOAL_DELETE: "Goal delete successfully.",
    COMM_DELETE: "Community delete successfully.",
    REQUEST_ACCEPT: "You have successfully accepted the request.",
    REQUEST_REJECT: "You have successfully rejected the request.",
    UNFRIEND_SUCCESS: "Successfully unfriended.",
    POST_REPORT: "Post has been reported successfully.",
    REPORT_SUCCESS: "Successfully reported.",
    EXITED_SUCCESS: "Successfully exited.",
    MEMBER_ADD: "Members has been added successfully.",
    FOLLOW_REQUEST_SENT: "Follow request sent successfully.",
    UNFOLLOW_SUCCESS: "successfully unfollowed.",
    COMMUNITY_BOOKMARK: "Community has been bookmarked successfully.",
    MUTE_SUCCESS: "Successfully mute.",
    UNMUTE_SUCCESS: "Successfully activated.",
    REQUEST_CANCEL: "Request cancelled successfully.",
    FOLLOW_CANCEL:"Follow request cancelled successfully.",
    IGNORE_SUCCESS:"Report ignored successfully"
});