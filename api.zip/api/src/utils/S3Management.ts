import { Config, config, S3 } from "aws-sdk";
import CONFIG from '../config/config';
import { createReadStream, createWriteStream } from "fs";
import { normalize } from "path";
import { Agent } from "https";
import Axios from "axios";
import * as fs from 'fs';

config.update({
  httpOptions: {
    agent: new Agent({
      rejectUnauthorized: false, // This is insecure, consider more secure approaches
    }),
  },
});

class UploadS3 {
  private S3: S3;

  constructor() {
    this.S3 = new S3({
      apiVersion: "2006-03-01",
      accessKeyId: CONFIG.ACCESS_KEY_ID,
      secretAccessKey: CONFIG.SECRET_ACCESS_KEY
    })
  }

  async uploadToS3(filePath: string, key: string, mimetype: string) {
    const fileStream = createReadStream(filePath);
    const params: S3.PutObjectRequest = {
      Bucket: CONFIG.BUCKET_NAME,
      Key: key,
      Body: fileStream,
      ContentType: mimetype,
    };
    try {
      let data = await this.S3.upload(params).promise();
      return data
    } catch (error) {
      throw new Error(`Failed to upload to S3: ${error.message}`);
    }
  }

  async downloadFromURL(url: string, localPath: string): Promise<void> {
    const response = await Axios({
      url,
      method: "GET",
      responseType: "stream",
    });

    response.data.pipe(createWriteStream(localPath));

    return new Promise((resolve, reject) => {
      response.data.on("end", () => resolve());
      response.data.on("error", (error) => reject(error));
    });
  }
  async deleteFilesFromLocal(files:any) {
    try {
      console.log(files)
      files.forEach((element) => {
        console.log('element',element)
        fs.unlinkSync(element.path);
      });
      return true;
    } catch (error) {
      return false;
    }
  }
  async deleteFileFromS3(key: string) {
    const params: S3.DeleteObjectRequest = {
      Bucket: CONFIG.BUCKET_NAME,
      Key: key
    };
    try {
      let data = await this.S3.deleteObject(params).promise();
      console.log(data)
      return data;
    } catch (error) {
      console.log('error', error);
    }
  }

}

const uploadS3 = new UploadS3();
export default uploadS3;
