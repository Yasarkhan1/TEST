import { diskStorage, StorageEngine } from 'multer';
import Boom from 'boom';
import { normalize } from 'path';
import { Request, Response, NextFunction } from 'express';
import * as multer from 'multer';

interface UploadHandlerOptions {
  fileSize: number;
}

export class UploadHandler {
  private fileSize: number;
  private storage: StorageEngine;
  private upload: multer.Multer;

  constructor(options: UploadHandlerOptions) {
    this.fileSize = options.fileSize;
    this.storage = diskStorage({
      destination: (req, file, cb) => {
        const root = normalize(`${__dirname}/../..`);
        cb(null, `${root}/public/uploads/`);
      },
      filename: (req, file, cb) => {
        cb(null, `${Date.now()}_${file.originalname}`);
      }
    })

    this.upload = multer({
      storage: this.storage,
      limits: {
        fileSize: this.fileSize * 1024 * 1024,
      },
    });
    this.uploadFile = this.uploadFile.bind(this);
  }

  private async handleUploadError(req: Request, res: Response, next: NextFunction) {
    try {
      await new Promise<void>((resolve, reject) => {
        this.upload.any()(req, res, (err) => {
          console.log('erro', err)
          if (err) {
            if (err.code === 'LIMIT_FILE_SIZE') {
              return reject(Boom.boomify(err, { message: 'File size limit exceeds' }));
            }
            return reject(Boom.internal(err, { message: 'Error in file upload' }));
          }
          resolve();
        });
      });
      next();
    } catch (error) {
      next(error);
    }
  }

  public async uploadFile(req: Request, res: Response, next: NextFunction) {
    try {
      await this.handleUploadError(req, res, next);
    } catch (err) {
      console.log("err", err)
    }
  }
}

export default new UploadHandler({ fileSize: 10 });
