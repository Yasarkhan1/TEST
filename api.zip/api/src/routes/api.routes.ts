import * as express from 'express';
import { verifyToken, verifyTokenConsultant } from '../middleware/verifyToken';
import PatientController from '../controllers/patient.controller';
import CommonController from '../controllers/common.controller';
import { middleware } from '../middleware/validation';
import uploadHandler, { UploadHandler } from '../utils/uploadHandler';
import { schemas } from '../validation/schema';
import CPNController from '../controllers/cpn.controller';
import ConsultantController from '../controllers/consultant.controller';

import AdminController from '../controllers/admin.controller';

class ApiRoutes {
	public router: express.Router;
	public patientCtrl: PatientController;
	public commonCtrl: CommonController;
	public cpnCtrl: CPNController;
	public consultantCtrl: ConsultantController;
	public adminctrl: AdminController
	constructor() {
		this.patientCtrl = new PatientController();
		this.commonCtrl = new CommonController();
		this.cpnCtrl = new CPNController()
		this.consultantCtrl = new ConsultantController()
		this.adminctrl = new AdminController()
		this.router = express.Router();
		this.init();
	}

	init() {
		/** Auth Route */
		this.router.get('/getAllcountry', this.commonCtrl.getAllcountry);
		this.router.post('/getAggrement', this.commonCtrl.getAggrement);
		this.router.post('/createCountry', middleware(schemas.createCountry, 'body'),this.commonCtrl.createCountry);
		this.router.post('/createAgreement', this.commonCtrl.createAgreement);
		this.router.post('/checkEmailIdExit', this.patientCtrl.checkEmailIdExit);
		this.router.get('/dropdownOptions', this.patientCtrl.dropdownOptions);
		this.router.post('/forgetPassword', this.commonCtrl.forgetPassword);
		this.router.post('/resetPassword', this.commonCtrl.resetPassword);
		this.router.post('/verifyOTP', this.commonCtrl.verifyOTP);


		/** User Route patients*/
		this.router.get('/patients/getPatientDetails', verifyToken, this.patientCtrl.getPatientDetails);
		this.router.post('/patients/create', uploadHandler.uploadFile, this.patientCtrl.create);
		this.router.post('/patients/login',middleware(schemas.patientLogin, 'body'), this.patientCtrl.login);
		this.router.post('/checkEmailIdExit', this.patientCtrl.checkEmailIdExit);
		this.router.patch('/patients/updateProfile', verifyToken, uploadHandler.uploadFile, this.patientCtrl.updateProfile);
		this.router.patch('/appointmentBook', verifyToken, uploadHandler.uploadFile, this.patientCtrl.appointmentBook);
		this.router.get('/appointment/:appointmentId', this.patientCtrl.getappointmentBooking);
		this.router.get('/getAllAppointment', verifyToken, this.patientCtrl.getAllAppointment);
		this.router.patch('/add-card-details', verifyToken, this.patientCtrl.AddCardDetails);
		this.router.post('/patients/payment', this.patientCtrl.payment);
		this.router.get('/patients/getAllCard',verifyToken, this.patientCtrl.getAllCard);
		this.router.post('/patients/getTwilioToken', this.patientCtrl.createTwilioToken);
		this.router.post('/patients/bookingCancellation',verifyToken, this.patientCtrl.bookingCancellation);
		this.router.post('/patients/rescheduleAppointment',verifyToken, this.patientCtrl.rescheduleAppointment);

		
		/** User Route expert_conultant*/

		this.router.post('/consultant/create', uploadHandler.uploadFile, this.consultantCtrl.create);
		this.router.post('/consultant/login', this.consultantCtrl.login);
		this.router.patch('/consultant/updateProfile', verifyToken, uploadHandler.uploadFile, this.consultantCtrl.updateProfile);
		this.router.patch('/consultant/seheduleAppointment', uploadHandler.uploadFile, this.consultantCtrl.seheduleAppointment);
		this.router.get('/consultant/getAllConsultant', uploadHandler.uploadFile, this.consultantCtrl.getAllConsultant);

		

		/** User Route cpn*/
		
		this.router.post('/cpn/create', this.cpnCtrl.create);
		this.router.post('/cpn/login', this.cpnCtrl.login);

		/** User Route Admin*/



		/** Admin Route*/
		this.router.post('/admin/login', this.adminctrl.login);
		this.router.post('/admin/addNewUser', this.adminctrl.addNewUser);
		this.router.post('/admin/deleteUser', this.adminctrl.deleteUser);
		this.router.get('/admin/patients/:_id', this.adminctrl.getPatientDetails);
		this.router.get('/admin/consultant/:_id', this.adminctrl.getConsultantDetails);
		this.router.get('/admin/cpn/:_id', this.adminctrl.getCPNDetails);
		this.router.get('/admin/getAllUser', this.adminctrl.getAllUser);

	}
}

export default new ApiRoutes();
