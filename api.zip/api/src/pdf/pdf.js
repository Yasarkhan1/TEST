import { promisify } from "util";
import * as fs from 'fs';
const fsPromise = promisify(fs.readFile);
import hbs from 'handlebars';
import htmlToPdf from 'html-pdf';


// standard hbs equality check, pass in two values from template
// {{#ifeq keyToCheck data.myKey}} [requires an else blockin template regardless]
/**
 * Represents a PDF document
 * Generates PDF via handlebars template
 */

 hbs.registerHelper("multiply", function(numberOne, numberTwo) {
    return parseInt(numberOne) * parseInt(numberTwo);
  });

 hbs.registerHelper("sum", function(numberOne, numberTwo) {
    return parseInt(numberOne) + parseInt(numberTwo);
  });
hbs.registerHelper("subtract", function(numberOne, numberTwo) {
    return parseInt(numberOne) - parseInt(numberTwo);
  });
  hbs.registerHelper("valid", function(value) {
    return value ? "checked" : "";
  });
export default class PDF {
  constructor({ data, template, fileName, orientation }) {
    try {
      // stringify & parse used data orderData doesn't support assign or any other type of mutability
      data = JSON.parse(JSON.stringify(data));
      if (!template || !fileName) {
        throw new Error("Could not create PDF. Missing parameters.");
      }
      this.path = fileName;
      this.path += ".pdf";
      this.data = data;
      this.template = template;
      this.orientation = orientation;
    } catch (err) {
      console.error(err, "Error in getPDF");
      this.url = "";
    }
  }
  async getUrl() {
    try {
      if (!this.url) {
          console.log(__dirname, process.cwd())
        const content = await fsPromise(
            process.cwd() + '/src'  + `/templates/${this.template}.hbs`,
          {
            encoding: "utf8",
          }
        );
        const template = hbs.compile(content);
        const html = template({ data: this.data });
        this.url = await new Promise((resolve) => {
          htmlToPdf
            .create(html, { orientation: this.orientation})
            .toFile(this.path, (err, resp) => {
              resolve(this.path);
            });
        });
      }
      return this.url;
    } catch (err) {
      console.error(err, "Error during pdf.getUrl");
      return "";
    }
  }
};
