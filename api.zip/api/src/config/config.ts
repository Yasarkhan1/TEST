import * as dotenv from 'dotenv';
dotenv.config();

const env = (process.env.APP_ENV === undefined) ? 'dev' : process.env.APP_ENV;

export default {
    APP_ENV: env || 'dev',
    PORT: process.env.PORT || 3000,
    API_PREFIX: process.env.API_PREFIX || 'api',
    DB_DIALECT: process.env.DB_DIALECT || 'mongo',
    DB_HOST: process.env.DB_HOST || 'mongodb://127.0.0.1:27017',
    DB_NAME: process.env.DB_NAME || 'cpn',
    DB_USER: process.env.DB_USER || 'root',
    DB_PASSWORD: process.env.DB_PASSWORD || 'y7z27tQdwER6Knk8',
    DB_PORT: process.env.DB_PORT || 27017,
    JWT_SECRET: process.env.JWT_SECRET || 'WpDmcvTCzTfm7g7o',
    JWT_SECRETCONSLTANT: process.env.JWT_SECRET || 'WpDmcvTCzTfm7WQW',
    JWT_EXPIRATION: process.env.JWT_EXPIRATION || 10000,
    SALT_ROUNDS: process.env.SALT_ROUNDS || 10,
    BUCKET_NAME:process.env.BUCKET_NAME || "appsums-static-assets",
    ACCESS_KEY_ID:process.env.ACCESS_KEY_ID || "AKIAZG455GYRNK5AIIQ7",
    SECRET_ACCESS_KEY:process.env.SECRET_ACCESS_KEY || "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",
    EMAIL:"techappsums@gmail.com",
    PASSWORD:"wsdbrpfyqahvnojd"
};