import * as Mongoose from 'mongoose';
import CONFIG from './config';

module.exports = {
    dbConnect : async (eventEmitter) => {
        try {
           let db= await Mongoose.connect(`${CONFIG.DB_HOST}/${CONFIG.DB_NAME}`, {
                useUnifiedTopology: true,
                useNewUrlParser: true,
                connectTimeoutMS: 60000
            });
            console.log(`${CONFIG.DB_HOST}/${CONFIG.DB_NAME}`);
            console.log(`Congratulation: ${CONFIG.DB_NAME} db is connected Successfully.`);
        } catch (error) {
            console.log(`Error: Establishing a Database Connection.`);
            console.log(`${error}`);
            process.exit();
        }
    }
} 