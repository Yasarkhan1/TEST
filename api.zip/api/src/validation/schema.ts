import * as Joi from 'joi';


export const schemas = {
  patientSchema: Joi.object({
    email: Joi.string().required().trim(),
    password: Joi.string().required().trim(),
    name: Joi.string().required(),
    dateOfBirth: Joi.string().required(),
    sex: Joi.string().default('').trim(),
    address: Joi.string().default('').trim(),
    contactNumber: Joi.string().required().trim(),
    country: Joi.string().required().trim(),
    countryCode:Joi.string().required().trim(),
    image: Joi.string().required().trim(),
    hipaaAgreement: Joi.string().trim(),
  }),
  expertConsultant: Joi.object({
    image: Joi.string().required(),
    email: Joi.string().required().trim(),
    password: Joi.string().required().trim(),
    personalDetails: Joi.object({
      name: Joi.string().required().trim(),
      address1: Joi.string().required().trim(),
      address2: Joi.string().trim().default(""),
      city: Joi.string().required().trim(),
      state: Joi.string().required().trim(),
      country: Joi.string().required().trim(),
      zipCode: Joi.string().required().trim(),
      image: Joi.string().required().trim(),
      contactNumber: Joi.string().required().trim(),
    }),
    professionalDetails: Joi.object({
      selectSpecialty: Joi.string().required(),
      selectDegree: Joi.string().required(),
      institution: Joi.string().required().trim(),
      year: Joi.string().required().trim(),
      from: Joi.string().required(),
      to: Joi.string().required(),
      fellowship: Joi.string().required().trim(),
      currentCredentialing: Joi.string().required().trim(),
      medicalLicenseNumber: Joi.string().required().trim(),
    }),
    employmentDetails: Joi.object({
      name: Joi.string().required().trim(),
      address: Joi.string().required().trim(),
      contactNumber: Joi.string().required().trim(),
      fax: Joi.string().trim().default(""),
      email: Joi.string().required().trim(),
      currentRole: Joi.string().required().trim(),
      areaOfExpertise: Joi.string().required().trim(),
      webProfile: Joi.string().required().trim(),
      professionalFee: Joi.string().required().trim(),
    }),
    availability: Joi.array().items(
      Joi.object({
        day: Joi.string().required().trim(),
        startTime: Joi.string().required().trim(),
        endTime: Joi.string().required().trim(),
        interval: Joi.number().required(),
        slots: Joi.array().items(
          Joi.object({
            slotTime: Joi.string().required().trim(),
            status: Joi.string()
              .valid("ACTIVE", "BLOCK", "DELETE")
              .default("ACTIVE")
              .trim(),
          })
        ),
      })
    ),
    hipaaAgreement: Joi.object({
      hipaaAgreement: Joi.boolean().required(),
      cpnAgreement: Joi.boolean().required(),
      signAgreement: Joi.string().required().trim(),
    }),
    status: Joi.string()
      .valid("ACTIVE", "BLOCK", "DELETE")
      .default("ACTIVE"),
  }).unknown(true),
  appointment: Joi.object({
    email: Joi.string().required(),
    password: Joi.string().required(),
    need: Joi.string().required(),
    seen: Joi.string().required(),
    description: Joi.string().required(),
    paymentMethod: Joi.string().required(),
    personalDetails: Joi.object({
      name: Joi.string().required(),
      dateOfBirth: Joi.string().required(),
      sex: Joi.string().default('').trim(),
      email: Joi.string().required(),
      address: Joi.string().default('').trim(),
      contactNumber: Joi.string().required(),
      country: Joi.string().required(),
      image: Joi.string().required(),
    }).required(),
    hipaaAgreement: Joi.object({
      dataPrivacy: Joi.boolean().required(),
      termCondition: Joi.boolean().required(),
      signAgreement: Joi.string().required(),
    }).required(),
    demographicInformation: Joi.object({
      name: Joi.string().required(),
      selectAge: Joi.string().required(),
      selectDob: Joi.string().required(),
      selectHeight: Joi.string().required(),
      selectWeight: Joi.string().required(),
      selectCountry: Joi.string().required(),
      selectLocation: Joi.string().required(),
    }).required(),
    cancerHistory: Joi.object({
      typeOfCancer: Joi.string().required(),
      yearOfDiagnosis: Joi.string().required(),
      location: Joi.string().required(),
      metastatic: Joi.string().required(),
      stage: Joi.string().required(),
    }).required(),
    pastTreatment: Joi.object({
      pastCancerTreatment: Joi.string().required(),
      chemotherapy: Joi.string().required(),
      radiation: Joi.string().required(),
      surgery: Joi.string().required(),
      targetedTherapies: Joi.string().required(),
      immunotherapies: Joi.string().required(),
      clinicalTrialName: Joi.string().required(),
      year: Joi.string().required(),
    }).required(),
    currentTreatment: Joi.object({
      cancerTreatment: Joi.string().required(),
    }).required(),
    oncologyTeam: Joi.object({
      nameOfProvider: Joi.string().required(),
      officename: Joi.string().required(),
      phone: Joi.string().required(),
      fax: Joi.string().trim(),
      clinicalTrialName: Joi.string().required(),
    }).required(),
    medicalHistory: Joi.object({
      nameOfDisease: Joi.string().required(),
      yearOfDiagnosis: Joi.string().required(),
      status: Joi.number().required().default(1),
    }).required(),
    surgicalHistory: Joi.object({
      name: Joi.string().required(),
      current: Joi.string().required(),
    }).required(),
    familyHistory: Joi.object({
      relation: Joi.string().required(),
      nameOfDisease: Joi.string().required(),
    }).required(),
    socialHistory: Joi.object({
      married: Joi.string().required(),
      employed: Joi.string().required(),
      alcoholUse: Joi.string().required(),
      tobaccoUse: Joi.string().required(),
      recreationalDrug: Joi.string().required(),
      use: Joi.string().required(),
    }).required(),
    medication: Joi.object({
      medications: Joi.string().required(),
      frequency: Joi.string().required(),
      duration: Joi.string().required(),
    }).required(),
    allergiesFromMedicines: Joi.object({
      NameOfMedication: Joi.string().required(),
      NameOfAllergy: Joi.string().required(),
    }).required(),
    labs: Joi.object({
      labsNameAndDetails: Joi.string().required(),
      attachments: Joi.string().required(),
    }).required(),
    imaging: Joi.object({
      imagingDetails: Joi.string().required(),
      attachments: Joi.string().required(),
    }).required(),
    otherAdditionalInformation: Joi.object({
      imagingDetails: Joi.string().required(),
      attachments: Joi.string().required(),
    }).required(),
    addCouponCode: Joi.object({
      couponCode: Joi.string().required(),
    }).required(),
  }).required(),
  patientLogin: Joi.object({
    email: Joi.string().required().trim(),
    password: Joi.string().required().trim(),
  }),
  createCountry:Joi.object({
    name: Joi.string().required().trim()
  }),
};
export default schemas;