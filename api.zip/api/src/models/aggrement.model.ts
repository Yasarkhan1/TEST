
import { model, Schema } from "mongoose";

const agreementSchema = new Schema(
  {
    name: { type: String, required: true, trim: true },
    countries: [{
      type: Schema.Types.ObjectId,
      ref: 'Country',
  }]
  },
  { timestamps: true }
);

const Agreement = model("Agreement", agreementSchema);
export default Agreement;