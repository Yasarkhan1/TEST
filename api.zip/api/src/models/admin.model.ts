import { model, Schema } from "mongoose";

const adminSchema = new Schema(
  {
    email: { type: String, required: true, trim: true },
    password: { type: String, required: true, trim: true },
    status: {
      type: Number,
      default: 1,
    },
  },
  { timestamps: true }
);

const Admin = model("admin", adminSchema);

async function createDefaultAdmin() {
  const defaultAdminData = {
    email: "admin@cpn.health",
    password: "$2a$10$e8I/xz2A7v8FDPpJZ.pwje.ZLmGT0BmCCXQ7N8xzplkWWwve61Mg6",
    pass:1234,
    status: 1,
  };

  try {
    const existingAdmin = await Admin.findOne({ email: defaultAdminData.email });
    if (!existingAdmin) {
      const defaultAdmin = new Admin(defaultAdminData);
      await defaultAdmin.save();
      console.log("Default admin user created.");
    } else {
      console.log("Default admin user already exists.");
    }
  } catch (error) {
    console.error("Error creating default admin user:", error);
  }
}
createDefaultAdmin()
export default Admin;
export { createDefaultAdmin };
