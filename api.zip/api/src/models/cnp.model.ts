import { model, Schema } from "mongoose";

const cpnSchema = new Schema(
    {

        email: { type: String, required: true, trim: true },
        password: { type: String, trim: true },
        pass:{ type: String, trim: true },
        name: { type: String,  trim: true },
        address: { type: String, default: "", trim: true },
        qualification: { type: String, trim: true },
        contactNumber: { type: String,  trim: true },
        hipaaAgreement: [{
            key: { type: String, required: true },
            status: { type: Boolean, required: true },
            _id: { type: String, required: true },
        }],
        // 1, ACTIVE 2, BLOCK,3 DELETE
        status: {
            type: Number,
            default: 1
          },
        signAgreement: { type: String,  trim: true },
    },


    { timestamps: true }
);

const CPN = model("cpn", cpnSchema);

export default CPN;
