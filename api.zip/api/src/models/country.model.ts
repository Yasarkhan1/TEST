
import { model, Schema } from "mongoose";

const countrySchema = new Schema({
    name: String
},
    { timestamps: true }
);

const Country = model("Country", countrySchema);
export default Country;
