import { model, Schema } from "mongoose";
   
   let  couponSchema = new Schema(
        {
            code: { type: String },
            image: { type: String },
            couponType: {
                type: String,
                enum: ["FIXED", "PERCENTAGE"]
            },
            value: { type: Number },
            numberOfUsesLimit: { type: Number },
            numberOfUsed: { type: Number , default:0 },
            minimum_Applicability_Value: { type: Number },// value in dollar
            maximum_Applicability_Value: { type: Number },//   value in dollar
            startDate: {
                type: Date
            },
            endDate: {
                type: Date
            },
            status: {
                type: String,
                enum: ["ACTIVE", "BLOCK", "DELETE","LIMIT_COMPLETE"],
                default: "ACTIVE"
            },
        },
        {
            timestamps: true,
        }
    );

const Coupon = model("coupon", couponSchema);
export default Coupon;
