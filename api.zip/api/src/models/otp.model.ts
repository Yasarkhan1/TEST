import { model, Schema } from "mongoose";
const otpSchema: Schema = new Schema({
    otp: { type: String, required: true },
    expiryTime: { type: Date, required: true },
    userId: { type: Schema.Types.ObjectId, required: true },
});
const OTP = model('OTP', otpSchema);
export default OTP;
