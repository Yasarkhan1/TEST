import { model, Schema } from "mongoose";

const AppointmentSchema = new Schema(
    {
        // steps 1
        expertNeed: { type: String, trim: true },
        seen: { type: String, trim: true },
        concernToDay: { type: String, trim: true },
        steps: { type: String, trim: true, default: "1" },
        status: { type: String, trim: true, default: "InComplated" },

        // InComplated requested scheduled completed
        paymentStatus: { type: String, trim: true, default: "pending" },  //pending paid
        patientId: {
            type: Schema.Types.ObjectId,
            ref: 'Patient',
        },
        trackingId: { type: String, trim: true },
        // steps 2
        demographicInformation: {
            PreferredName: { type: String, trim: true },
            age: { type: String, trim: true },
            dateOfBirth: { type: String, trim: true },
            height: { type: String, trim: true },
            weight: { type: String, default: "", trim: true },
            locatoin: { type: String, trim: true },
        },
        // steps 3
        cancerHistory: {
            typeOfCancer: { type: String, trim: true },
            yearOfDiagnosis: { type: String, trim: true },
            location: { type: String, trim: true },
            metastatic: { type: String, trim: true },
            stage: { type: String, trim: true },
        },
        pastTreatment: {
            pastCancerTreatment: { type: String, trim: true },
            chemotherapy: {
                value: { type: String, trim: true },
                date: { type: String, trim: true }
            },
            radiation: {
                value: { type: String, trim: true },
                date: { type: String, trim: true }
            },
            surgery: {
                value: { type: String, trim: true },
                date: { type: String, trim: true }
            },
            targetedTherapies: {
                value: { type: String, trim: true },
                date: { type: String, trim: true }
            },
            immunotherapies: {
                value: { type: String, trim: true },
                date: { type: String, trim: true }
            },
            clinicalTrialName: { type: String, trim: true },
            year: { type: String, trim: true },
        },
        // steps 4
        currentTreatment: [{
            cancerTreatment: { type: String, trim: true },
            treatmentDate: { type: String, trim: true }
        }],
        oncologyTeam: {
            nameOfProvider: { type: String, trim: true },
            officename: { type: String, trim: true },
            phone: { type: String, trim: true },
            countryCode: { type: String, trim: true },
            fax: { type: String, trim: true },
            clinicalTrialName: { type: String, trim: true },
        },
        medicalHistory: {
            nameOfDisease: { type: String, trim: true },
            yearOfDiagnosis: { type: String, trim: true },
            status: { type: String, default: 1 },
        },
        surgicalHistory: {
            name: { type: String, trim: true },
            current: { type: String, trim: true },
        },
        // steps 5
        familyHistory: {
            relation: { type: String, trim: true },
            nameOfDisease: { type: String, trim: true },
        },
        socialHistory: {
            married: { type: String, trim: true },
            employed: { type: String, trim: true },
            alcoholUse: {
                value: { type: String, trim: true },
                week: { type: String, trim: true }
            },
            tobaccoUse: {
                value: { type: String, trim: true },
                day: { type: String, trim: true }
            },
            recreationalDrug: {
                value: { type: String, trim: true },
                name: { type: String, trim: true },
                day: { type: String, trim: true }
            }
        },
        medication: {
            medications: { type: String, trim: true },
            frequency: { type: String, trim: true },
            duration: { type: String, trim: true },
        },
        // steps 6
        allergiesFromMedicines: {
            medication: { type: String, trim: true },
            allergy: { type: String, trim: true },
        },
        labs: {
            name: { type: String, trim: true },
            attachments: [{ image: { type: String, trim: true } }],
            labDetails: { type: String, trim: true }
        },
        imageDetails: {
            details: { type: String, trim: true },
            attachments: [{ image: { type: String, trim: true } }],
        },
        otherAdditionalInformation: {
            details: { type: String, trim: true },
            attachments: [{ image: { type: String, trim: true } }],
        },
        cardDetails: {
            cardId: { type: String, trim: true }
        },
        //...............................//
        //Sehedule Appointment
        seheduleAppointment: {
            expertConsulatant: {
                type: Schema.Types.ObjectId,
                ref: 'ExpertConsultant',
            },
            uploadDoc: {
                type: String,
                default: ""
            },
            addAdditionInformation: {
                type: String,
                default: ""
            },
            appointmentDate: {
                type: Date,
                default: ""
            },
            appointmentTime: {
                type: String,
                default: ""
            },
            slotId: {
                type: String,
                default: ""
            },
            isoStartTime: {
                type: Schema.Types.Date
            },
            isoEndTime: {
                type: Schema.Types.Date
            },
            unixStartTime: {
                type: Schema.Types.Number,
            },
            unixEndTime: {
                type: Schema.Types.Number,
            },
            //------new Add field----------------->
            is_counted: {
                type: Boolean,
                default: false
            },
            amount: {
                type: Number,
                default: 0
            },
            appointmentType: {
                type: String,
                enum: ['SUBSCRIPTION', 'BANK_CARD'],
                default: 'SUBSCRIPTION'
            },
            reason: {
                type: String,
            },
            cancelReason: {
                type: String,
            },
            cancelledBy: {
                type: String,
            }
        },
        //>>>>>>>>>>>>>>>>>>>>>>>>>>>>>//
        rescheduleSlots: [{
            appointmentdate: {
                type: String,
                default: ""
            },
            appointmentTime: {
                type: String,
                default: ""
            },
            slotId: {
                type: String,
                default: ""
            },
            updatedAt: {
                type: Schema.Types.Number,
                default: Date.now
            }
        }],
    },
    { timestamps: true }
);

const Appointment = model("Appointment", AppointmentSchema);
export default Appointment;