import { model, Schema } from "mongoose";



const SlotSchema = new Schema({
    slotId: { type: Number },
    label: { type: String },
    start_time: { type: String },
    end_time: { type: String },
    enabled: { type: Boolean, default: true }
});

const DaySlotSchema = new Schema([{
        day: { type: String }, // Day of the week (e.g., "Monday", "Tuesday", etc.)
        enabled: { type: Boolean, default: true },
        startTime: { type: String },
        endTime: { type: String },
        interval:{ type: Number }, // 15,
        time: [SlotSchema]
}]);
const ExpertConsultantSchema = new Schema(
    {
        email: { type: String, trim: true },
        password: { type: String, trim: true },
        pass:{ type: String, trim: true },
        personalDetails: {
            name: { type: String, trim: true },
            address1: { type: String, trim: true },
            address2: { type: String, trim: true, default: "" },
            city: { type: String, trim: true },
            state: { type: String, trim: true },
            country: { type: String, trim: true },
            zipCode: { type: String, trim: true },
            image: { type: String, trim: true },
            contactNumber: { type: String, trim: true },
            countryCode: { type: String, trim: true },
        },
        professionalDetails: {
            specialty: { type: String },
            degree: { type: String },
            institution: {
                name: { type: String, trim: true },
                from: { type: String },
                to: { type: String },
            },
            residency: {
                name: { type: String, trim: true },
                from: { type: String },
                to: { type: String },
            },
            fellowship: {
                name: { type: String, trim: true },
                from: { type: String },
                to: { type: String },
            },
            currentCredentialing: { type: String, trim: true },
            medicalLicenseNumber: { type: String, trim: true },
            years: { type: String, trim: true },
        },
        employmentDetails: {
            name: { type: String, trim: true },
            address: { type: String, trim: true },
            countryCode: { type: String, trim: true },
            contactNumber: { type: String, trim: true },
            fax: { type: String, trim: true, default: "" },
            email: { type: String, trim: true },
            currentRole: { type: String, trim: true },
            areaOfExpertise: { type: String, trim: true },
            webProfile: { type: String, trim: true },
            professionalFee: { type: String, trim: true },
        },
        slots: [DaySlotSchema],

        hipaaAgreement: {
            hipaaAgreement: { type: Boolean },
            cpnAgreement: { type: Boolean },
            signAgreement: { type: String, trim: true },
        },
        status: {  // 1, ACTIVE 2, BLOCK,3 DELETE
            type: Number,
            default: 1
        },
        paymentMethod: { type: String, trim: true },
        WNine: { type: String, trim: true }
    },
    { timestamps: true }
);

const ExpertConsultant = model("ExpertConsultant", ExpertConsultantSchema);

export default ExpertConsultant;
