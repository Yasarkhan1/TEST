import { model, Schema } from "mongoose";

let transactionModel = new Schema({
    patientId: {
        type: Schema.Types.ObjectId,
        ref: 'Patient',
    },
    expertConsulatant: {
        type: Schema.Types.ObjectId,
        ref: 'ExpertConsultant',
    },
    transactionId: {
        type: String
    },
    chargeId: {
        type: String
    },
    customerId: {
        type: String
    },
    url: {
        type: String
    },
    paymentType: {
        type: String
    },
    currency: {
        type: String,
        default: "USD"
    },
    amount: {
        type: Number,
    },
    email: {
        type: String
    },
    transactionStatus: {
        type: String
    }
}, {
    timestamps: true
})
const Transaction = model("transaction", transactionModel);
export default Transaction;