import { model, Schema } from "mongoose";

const PatientSchema = new Schema(
  {

    email: { type: String, required: true, trim: true },
    password: { type: String, trim: true },
    // 1, ACTIVE 2, BLOCK,3 DELETE
    pass:{ type: String, trim: true },
    status: {
      type: Number,
      default: 1
    },
    personalDetails: {
      name: { type: String, trim: true },
      dateOfBirth: { type: String, trim: true },
      sex: { type: String, default: "", trim: true },
      address: { type: String, default: "", trim: true },
      contactNumber: { type: String, trim: true },
      country: { type: String, trim: true },
      countryCode: { type: String, trim: true },
      image: { type: String, trim: true },
    },

    hipaaAgreement: [{
      key: { type: String },
      status: { type: Boolean },
      _id: { type: String },
    }],
    addCardDetails: [{
      paymentMethod: { type: String, trim: true },
      name: { type: String, trim: true },
      cardNumber: { type: String, trim: true },
      expiry: { type: String, trim: true },
      ccv: { type: String, trim: true },
    }],
    deviceType: {
      type: String,
      enum: ["ANDROID", "WEB", "IOS"]
    },
    deviceToken: {
      type: String
    },
    userDeviceToken: {
      type: String
    },
  },
  
  { timestamps: true }
);

const Patient = model("Patient", PatientSchema);

export default Patient;
