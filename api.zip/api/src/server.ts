import * as bodyParser from "body-parser";
import * as compression from "compression";
import * as cors from "cors";
import * as dotenv from "dotenv";
import * as express from "express";
import * as helmet from "helmet";
import * as mongoose from "mongoose";
import * as logger from "morgan";
dotenv.config();
import ApiRoutes from "./routes/api.routes";
// require('./configuration/passport')(passport);

global["__basedir"] = __dirname;

const allowedOrigins = [
  "http://localhost:3000",
  "http://15.206.13.50:3000",
  "http://15.206.13.50:4000",
];

class Server {
  public app: express.Application;
  apiPrefix: string = "api";
  constructor() {
    this.app = express();
    this.init();
  }

  init() {
    // this.dbConn();
    this.app.use(bodyParser.json({ limit: "50mb" }));
    this.app.use(bodyParser.urlencoded({ limit: "50mb", extended: true }));
    this.app.use(bodyParser.json());
    this.app.use(logger("dev"));
    this.app.use(compression());
    this.app.use(helmet());
   
    const isOriginAllowed = (origin) => {
      return allowedOrigins.includes(origin) || !origin;
    };
    this.app.use(
        cors({
          origin: (origin, callback) => {
            console.log(origin);
            if (isOriginAllowed(origin)) {
              console.log(`Origin ${origin} is allowed`);
              callback(null, true);
            } else {
              const msg = `CORS policy doesn't allow access from the specified Origin. (${origin})`;
              console.log(msg);
              callback(new Error(msg), false);
            }
          },
        })
    );
    // this.app.use((req, res, next) => {
    //   const origin = req.get('origin');
    //   if (allowedOrigins.includes(origin) || !origin) {
    //     res.setHeader('Access-Control-Allow-Origin', origin || '*');
    //     res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE');
    //     res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
    //     next();
    //   } else {
    //     res.status(403).send('CORS policy violation');
    //   }
    // });

    // this.app.use(passport.initialize());
    // require('./configuration/passport')(passport);
    this.app.use("/" + this.apiPrefix, ApiRoutes.router);
  }

  // dbConn() {
  //     const MONGO_URL = process.env.DB_URI;
  //     console.log('Database is connecting....');
  
  //     mongoose.connect(MONGO_URL, { useNewUrlParser: true });
  //     const message = `Database has been connected to - ${process.env.DB_CON}`;
  //     console.log(message);
  // }
}

export default new Server().app;
