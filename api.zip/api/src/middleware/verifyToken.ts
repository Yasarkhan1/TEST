import * as JWT from 'jsonwebtoken';
import { HTTP_STATUS, MESSAGE } from '../shared/constants/app.const';
import { Request, Response } from 'express';
import CONFIG from '../config/config';

export const verifyToken = async (request: Request, response: Response, next: Function) => {
  let token = request.headers["x-access-token"] ? request.headers["x-access-token"].toString() : null
  if (!token) {
    return response.status(HTTP_STATUS.UNAUTHORIZED).json({ status: HTTP_STATUS.UNAUTHORIZED, message: MESSAGE.UNAUTHORIZED });
  }
  try {
    let decoded: any = {};
    decoded = JWT.verify(token, CONFIG.JWT_SECRET);
    console.log(decoded)
    request.user = decoded
    next()
  }
  catch (ex) {
    return response.status(HTTP_STATUS.UNAUTHORIZED).json({ status: HTTP_STATUS.UNAUTHORIZED, message: MESSAGE.TOKEN_EXPIRED });
  }
}

export const verifyTokenConsultant = async (request: Request, response: Response, next: Function) => {
  let token = request.headers["x-access-token"] ? request.headers["x-access-token"].toString() : null
  if (!token) {
    return response.status(HTTP_STATUS.UNAUTHORIZED).json({ status: HTTP_STATUS.UNAUTHORIZED, message: MESSAGE.UNAUTHORIZED });
  }
  try {
    let decoded: any = {};
    decoded = JWT.verify(token, CONFIG.JWT_SECRETCONSLTANT);
    console.log(decoded)
    request.user = decoded
    next()
  }
  catch (ex) {
    return response.status(HTTP_STATUS.UNAUTHORIZED).json({ status: HTTP_STATUS.UNAUTHORIZED, message: MESSAGE.TOKEN_EXPIRED });
  }
}
