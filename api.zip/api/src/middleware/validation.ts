import { Request, Response, NextFunction } from 'express';
import  { Schema } from 'joi';
import { getErrorResponse } from '../utils/ResponseUtility';

export const middleware = (schema: Schema, property: string) => {
  
  return (req: Request, res: Response, next: NextFunction) => {
    const validationResult = schema.validate(req[property]);
    const { error } = validationResult;

    if (error == null) {
      next();
    } else {
      const errorMessages = error.details.map(detail => {
        const field = detail.path.join('.'); // Join path elements to get the field name
        const message = detail.message;
        return `${message}`;
      });
      const errorMessage = errorMessages.join(', ');
      res.status(422).json(getErrorResponse(errorMessage));
    }
  };
};
