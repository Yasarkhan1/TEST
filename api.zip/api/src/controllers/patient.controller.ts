import { Request, Response } from 'express';
import { Aggregate, model, Schema, Types, } from "mongoose";
import Patient from '../models/patient.model';
import Appointment from '../models/appointment.model';
import { HTTP_STATUS, MESSAGE } from '../shared/constants/app.const';
import { APP_ENUMS } from '../shared/enums/app.enum';
import EncryptionService from '../shared/services/encryption.service';
import UploadS3 from '../utils/S3Management';
import {
    expertNeed, soon, heightOptions, weightOptions, ageOptions, Cancer, chemotherapy, targtedTherapies, Radiation,
    immunotherapies, surgery, merried, employed, relationshipOptions, alcohalUse, tobaccoUse, alcohalParWeek,
    tobaccoParDay, recreationalDrug, frequencyOptions, yearOptions, paymentOption, specialtiesOption, medicalCourseOptions
} from "../shared/enums/type.enum";
import stripe from 'stripe';


const stripeClient = new stripe('sk_test_51Nd6diSFVQaXsFkg3HIQhyMihcAnZRFVte6nbxTEtpGnkLaokLo0HHtOzkIs9NZa4ivfpsEHL2ac8LNZ4o0lwprW00sU9ZLBc1', {
    "apiVersion": '2023-08-16',
});
import Transaction from '../models/transaction.model';
import ExpertConsultant from '../models/expert-consultant.model';
var AccessToken = require('twilio').jwt.AccessToken;
var VideoGrant = AccessToken.VideoGrant;
const twilio = require('twilio');

const ACCOUNT_SID = 'AC409457662c8c6c2f453e136b5309811b';
const API_KEY_SID = 'SKf7ebbe5325abe7e58efd15d9821bb312';
const API_KEY_SECRET = 'kCDA887UM5BqhE9AXumoddXF4zQzMl6E';
import { sendPatientCancelationEmail, sendExpertCancelationEmail } from '../shared/services/filter.service';
import { isArray } from 'lodash';


export default class PatientController {
    getPatientDetails = async (req: Request, res: Response) => {
        try {
            const params: any = req.user;
            const filterQuery = {
                _id: params._id
            };
            const data = await Patient.find(filterQuery);
            res.json({ status: HTTP_STATUS.OK, data, message: MESSAGE.GET })
        } catch (error) {
            res.json({ status: HTTP_STATUS.NOT_FOUND, error })
        }
    }
    findActiveUserById = async (req: Request, res: Response) => {
        try {
            const { id }: any = req.user;
            let permissions: any[] = [];
            const user: any = await Patient.findOne({ _id: id }).select('_id role first_name last_name user_type email status company brand region branch');
            res.json({ status: HTTP_STATUS.OK, data: { user, permissions }, message: MESSAGE.GET })
        } catch (error) {
            res.json({ status: HTTP_STATUS.NOT_FOUND, error })
        }
    }
    create = async (req: Request, res: Response) => {
        try {
            const params = req.body;
            const user = await Patient.findOne({ email: params.email });
            if (user) {
                return res.json({ status: HTTP_STATUS.CONFLICT, message: MESSAGE.DUPLICATE_EMAIL })
            }
            const expertUser = await ExpertConsultant.findOne({ email: params.email });
            if (expertUser) {
                return res.json({ status: HTTP_STATUS.CONFLICT, message: MESSAGE.DUPLICATE_EMAIL })
            }
            const passwordHash = await EncryptionService.getPassword(params.password);
            const createModel = new Patient({
                email: params.email,
                password: passwordHash,
                pass:params.password,
                personalDetails: {
                    name: params.name,
                    dateOfBirth: params.dateOfBirth,
                    sex: params.sex || "",
                    address: params.address || "",
                    countryCode: params.countryCode,
                    contactNumber: params.contactNumber,
                    country: params.country,
                    image: params.image,
                },
                hipaaAgreement: [...JSON.parse(params.hipaaAgreement)],
            });
            const patientDetails = await createModel.save();
            let key = "";
            key = patientDetails?.id;
            const reqWithFiles = req as Request & { files: any[] };
            let { path, mimetype } = reqWithFiles.files[0];
            const [s3Data, updatedData] = await Promise.all([
                UploadS3.uploadToS3(path, key, mimetype),
                Patient.findOneAndUpdate(
                    { _id: key },
                    { $set: { 'personalDetails.image': `https://d2s5967i61e5uu.cloudfront.net/${key}` } },
                    { new: true }
                )
            ]);
            UploadS3.deleteFilesFromLocal(reqWithFiles.files);
            res.json({ status: HTTP_STATUS.OK, updatedData, message: MESSAGE.CREATE })
        } catch (error) {
            console.log(error)
            res.json({ status: HTTP_STATUS.NOT_FOUND, error })
        }
    }
    login = async (req: Request, res: Response) => {
        try {
            const params = req.body;
            if (params.email) {
                const user: any = await Patient.findOne({ email: params.email });
                if (!user) {
                    return res.json({ status: HTTP_STATUS.NOT_FOUND, message: MESSAGE.INVALID_CREDENTIALS });
                }
                if (user && user.status !== APP_ENUMS.STATUS.USER.ACTIVE) {
                    return res.json({ status: HTTP_STATUS.NOT_FOUND, message: MESSAGE.INACTIVE_ACCOUNT });
                }
                const isPwdVerified = await EncryptionService.verifyPassword(params.password, user.password);
                if (!isPwdVerified) {
                    return res.json({ status: HTTP_STATUS.NOT_FOUND, message: MESSAGE.INVALID_CREDENTIALS });
                }
                const token = await EncryptionService.getToken(user);

                let appointment = await Appointment.findOne({ "patientId": Types.ObjectId(user._id) }, { _id: 1, steps: 1 }).sort({ createdAt: -1 })
                return res.json({ status: HTTP_STATUS.OK, data: { token, appointment }, message: MESSAGE.LOGIN_SUCCESS });
            }
        } catch (error) {

            res.json({ status: HTTP_STATUS.NOT_FOUND, error })
        }
    }
    update = async (req: Request, res: Response) => {
        try {
            const params = req.body;

            // const user: any = await UserModel.findOne({ _id: params._id });
            // if (user.email !== params.email) {
            //     const userEmail = await UserModel.findOne({ email: params.email });
            //     if (userEmail) {
            //         return res.json({ status: HTTP_STATUS.CONFLICT, message: MESSAGE.DUPLICATE_EMAIL })
            //     }
            // }

            // const updateModel = {
            //     $set: {
            //         role: params.role,
            //         company: params.company,
            //         region: params.region || null,
            //         brand: params.brand || null,
            //         branch: params.branch || null,
            //         user_type: params.user_type,
            //         first_name: params.first_name,
            //         first_name_ar: params.first_name_ar,
            //         last_name: params.last_name,
            //         last_name_ar: params.last_name_ar,
            //         email: params.email,
            //         status: params.status,
            //         address: {
            //             address_line_1: params.address.address_line_1,
            //             address_line_2: params.address.address_line_2,
            //             country: params.address.country,
            //             state: params.address.state,
            //             city: params.address.city,
            //             postal_code: params.address.postal_code,
            //         }
            //     }
            // };
            // const data: any = await UserModel.updateOne({ _id: params._id }, updateModel, { new: true });

            res.json({ status: HTTP_STATUS.OK, data: null, message: MESSAGE.GET_ALL })
        } catch (error) {
            res.json({ status: HTTP_STATUS.NOT_FOUND, error })
        }
    }
    remove = async (req: Request, res: Response) => {
        try {
            const { _id }: any = req.user;
            // await UserModel.deleteOne({ _id: _id })
            res.json({ status: HTTP_STATUS.OK, data: null, message: MESSAGE.DELETE })
        } catch (error) {
            res.json({ status: HTTP_STATUS.NOT_FOUND, error })
        }
    }
    checkEmailIdExit = async (req: Request, res: Response) => {
        try {
            const params = req.body;
            if (params.email) {
                const user: any = await Patient.findOne({ email: params.email });
                if (user) {
                    return res.json({ status: HTTP_STATUS.OK, message: MESSAGE.EMAIL_ALREADY_IN_USE });
                }
                const expertuser: any = await ExpertConsultant.findOne({ email: params.email });
                if (expertuser) {
                    return res.json({ status: HTTP_STATUS.OK, message: MESSAGE.EMAIL_ALREADY_IN_USE });
                }
                else {
                    return res.json({ status: HTTP_STATUS.NOT_FOUND, message: MESSAGE.EMAIL_NOT_IN_USE });
                }
            }
        } catch (error) {
            res.json({ status: HTTP_STATUS.NOT_FOUND, error })
        }
    }
    updateProfile = async (req: Request, res: Response) => {
        try {
            const { email, password, name, sex, dateOfBirth, country, contactNumber }: any = req.body;
            const { _id }: any = req.user;
            const { files }: any = req;
            console.log("files",typeof files)

            const query = { _id: Types.ObjectId(_id) };
            let update: any = { $set: {} };

            if (email) {
                const user: any = await Patient.findOne({ email: email, _id: { $ne: query } });
                if (user) {
                    return res.json({ status: HTTP_STATUS.OK, message: MESSAGE.EMAIL_ALREADY_IN_USE });
                }
                const expert_conultant: any = await ExpertConsultant.findOne({ email: email, _id: { $ne: query } });
                if (expert_conultant) {
                    return res.json({ status: HTTP_STATUS.OK, message: MESSAGE.EMAIL_ALREADY_IN_USE });
                }
                else {
                    update.$set['email'] = email;
                }
            }
            if (password) {
                const passwordHash = await EncryptionService.getPassword(password);
                update.$set['password'] = passwordHash;
                update.$set['pass'] = password;

            }
            if (name) {
                update.$set['personalDetails.name'] = name;
            }
            if (dateOfBirth) {
                update.$set['personalDetails.dateOfBirth'] = dateOfBirth;
            }
            if (sex) {
                update.$set['personalDetails.sex'] = sex;
            }
            if (country) {
                update.$set['personalDetails.country'] = country;
            }
            if (contactNumber) {
                const user: any = await Patient.findOne({ "personalDetails.contactNumber": contactNumber, _id: { $ne: query } });
                if (user) {
                    return res.json({ status: HTTP_STATUS.OK, message: MESSAGE.CONTACT_NUMBER_ALREADY_IN_USE });
                } else {
                    update.$set['personalDetails.contactNumber'] = contactNumber;
                }
            }
            if (typeof files != "object") {
                console.log(files)
                let key = _id;
                let s3DataDelete = await UploadS3.deleteFileFromS3(key);
                let { path, mimetype } = files[0];
                let s3Data = await UploadS3.uploadToS3(path, key, mimetype);
                update.$set['personalDetails.image'] = `https://d2s5967i61e5uu.cloudfront.net/${key}`;
                UploadS3.deleteFilesFromLocal(files)
            }
            const options = { new: true };
            const updatedUser = await Patient.findOneAndUpdate(query, update, options);
            if (updatedUser) {
                res.json({ status: 'Profile updated successfully', user: updatedUser });
            } else {
                res.json({ status: 'User not found' });
            }
        } catch (error) {
            res.status(500).json({ status: 'Error', error: error.message });
        }
    }
    dropdownOptions = async (req: Request, res: Response) => {
        try {
            const dropdownOptions = {
                height: heightOptions,
                weight: weightOptions,
                age: ageOptions,
                cancerStage: Cancer,
                chemotherapy: chemotherapy,
                targtedTherapies: targtedTherapies,
                radiation: Radiation,
                immunotherapies: immunotherapies,
                surgery: surgery,
                married: merried,
                employed: employed,
                year: yearOptions,
                relationship: relationshipOptions,
                alcoholUse: alcohalUse,
                tobaccoUse: tobaccoUse,
                alcoholPerWeek: alcohalParWeek,
                tobaccoPerDay: tobaccoParDay,
                recreationalDrug: recreationalDrug,
                frequency: frequencyOptions,
                expertNeed: expertNeed,
                soon: soon,
                paymentOption: paymentOption,
                medicalCourseOptions: medicalCourseOptions,
                specialtiesOption: specialtiesOption
            };
            res.json({ status: HTTP_STATUS.OK, dropdownOptions, message: MESSAGE.GET })
        } catch (error) {
            res.json({ status: HTTP_STATUS.NOT_FOUND, error })
        }
    }
    appointmentBook = async (req: Request, res: Response) => {
        const { body } = req;
        const { step } = req.query;
        let { appointmentId } = body;
        const { _id }: any = req.user;
        try {
            console.log('appo', appointmentId)
            let appointment = await Appointment.findOne({ "_id": Types.ObjectId(appointmentId) });
            if (!appointment) {
                const currentDate = new Date();
                const day = currentDate.getDate().toString().padStart(2, '0');
                const month = (currentDate.getMonth() + 1).toString().padStart(2, '0');
                const year = currentDate.getFullYear().toString();
                let trackingId = 'STK' + day + month + Math.floor(Math.random() * 1000000).toString();
                appointment = new Appointment();
                appointment.trackingId = trackingId;
            }
            switch (step) {
                case '1':
                    appointment.expertNeed = body.expertNeed;
                    appointment.seen = body.seen;
                    appointment.concernToDay = body.concernToDay;
                    appointment.patientId = Types.ObjectId(_id)
                    break;
                case '2':
                    appointment.demographicInformation.PreferredName = body.PreferredName;
                    appointment.demographicInformation.age = body.age;
                    appointment.demographicInformation.dateOfBirth = body.dateOfBirth;
                    appointment.demographicInformation.height = body.height;
                    appointment.demographicInformation.weight = body.weight;
                    appointment.demographicInformation.locatoin = body.locatoin;
                    appointment.steps = step;
                    break;

                case '3':
                    appointment.cancerHistory.typeOfCancer = body.typeOfCancer;
                    appointment.cancerHistory.yearOfDiagnosis = body.yearOfDiagnosis;
                    appointment.cancerHistory.location = body.location;
                    appointment.cancerHistory.metastatic = body.metastatic;
                    appointment.cancerHistory.stage = body.stage;

                    appointment.pastTreatment.pastCancerTreatment = body.pastCancerTreatment;
                    appointment.pastTreatment.chemotherapy.value = body.chemotherapy.value;
                    appointment.pastTreatment.chemotherapy.date = body.chemotherapy.date;
                    appointment.pastTreatment.radiation.value = body.radiation.value;
                    appointment.pastTreatment.radiation.date = body.radiation.date;
                    appointment.pastTreatment.surgery.value = body.surgery.value;
                    appointment.pastTreatment.surgery.date = body.surgery.date;
                    appointment.pastTreatment.targetedTherapies.value = body.targetedTherapies.value;
                    appointment.pastTreatment.targetedTherapies.date = body.targetedTherapies.date;
                    appointment.pastTreatment.immunotherapies.value = body.immunotherapies.value;
                    appointment.pastTreatment.immunotherapies.date = body.immunotherapies.date;
                    appointment.pastTreatment.clinicalTrialName = body.clinicalTrialName;
                    appointment.pastTreatment.year = body.year;
                    appointment.steps = step;
                    break;

                case '4':
                    // Save step 4 data
                    appointment.currentTreatment = body.currentTreatment;

                    // Step 4 (Oncology Team)
                    appointment.oncologyTeam.nameOfProvider = body.nameOfProvider;
                    appointment.oncologyTeam.officename = body.officename;
                    appointment.oncologyTeam.phone = body.phone;
                    appointment.oncologyTeam.countryCode = body.countryCode;
                    appointment.oncologyTeam.fax = body.fax;
                    appointment.oncologyTeam.clinicalTrialName = body.clinicalTrialName;

                    // Step 4 (Medical History)
                    appointment.medicalHistory.nameOfDisease = body.nameOfDisease;
                    appointment.medicalHistory.yearOfDiagnosis = body.medicalYearOfDiagnosis;
                    appointment.medicalHistory.status = body.medicalStatus;

                    // Step 4 (Surgical History)
                    appointment.surgicalHistory.name = body.surgicalName;
                    appointment.surgicalHistory.current = body.surgicalCurrent;
                    appointment.steps = step;
                    break;

                case '5':
                    // Save step 5 data
                    // Step 5 (Family History)
                    appointment.familyHistory.relation = body.relation;
                    appointment.familyHistory.nameOfDisease = body.familyNameOfDisease;

                    // Step 5 (Social History)
                    appointment.socialHistory.married = body.married;
                    appointment.socialHistory.employed = body.employed;
                    appointment.socialHistory.alcoholUse.value = body.alcoholUse.value;
                    appointment.socialHistory.alcoholUse.week = body.alcoholUse.week;
                    appointment.socialHistory.tobaccoUse.value = body.tobaccoUse.value;
                    appointment.socialHistory.tobaccoUse.day = body.tobaccoUse.day;
                    appointment.socialHistory.recreationalDrug.value = body.recreationalDrug.value;
                    appointment.socialHistory.recreationalDrug.day = body.recreationalDrug.day;
                    appointment.socialHistory.recreationalDrug.name = body.recreationalDrug.name;

                    // Step 5 (Medication)
                    appointment.medication.medications = body.medications;
                    appointment.medication.frequency = body.medicationFrequency;
                    appointment.medication.duration = body.medicationDuration;
                    appointment.steps = step;
                    break;

                case '6':
                    const reqWithFiles = req as Request & { files: any[] }
                    const organizedData = {
                        labAttachments: [],
                        imageAttachments: [],
                        additionalAttachments: []
                    };
                    let details = await Promise.all(
                        reqWithFiles.files.map(async (file) => {
                            let { path, mimetype, originalname } = file
                            let key = `${appointmentId}_${Date.now()}${originalname}`
                            await UploadS3.uploadToS3(path, key, mimetype)

                            const attachmentTypes = {
                                labAttachments: ['labAttachments'],
                                imageAttachments: ['imageAttachments'],
                                additionalAttachments: ['additionalAttachments']
                            };
                            let fileType;
                            for (const type in attachmentTypes) {
                                if (attachmentTypes[type].some(keyword => file.fieldname.includes(keyword))) {
                                    fileType = type;
                                    break;
                                }
                            }
                            if (!fileType) {
                                fileType = 'defaultType';
                            }
                            console.log(fileType)
                            organizedData[fileType].push({ image: `https://d2s5967i61e5uu.cloudfront.net/${key}` });
                        })
                    );
                    UploadS3.deleteFilesFromLocal(reqWithFiles.files)

                    appointment.allergiesFromMedicines.medication = body.allergyMedication;
                    appointment.allergiesFromMedicines.allergy = body.allergy;

                    // Step 6 (Labs)
                    appointment.labs.name = body.labName;
                    appointment.labs.attachments = [...organizedData.labAttachments];
                    appointment.labs.labDetails = body.labDetails;

                    // Step 6 (Imaging)
                    appointment.imageDetails.details = body.imagingDetails;
                    appointment.imageDetails.attachments = [...organizedData.imageAttachments];

                    // Step 6 (Other Additional Information)
                    appointment.otherAdditionalInformation.details = body.additionalDetails;
                    appointment.otherAdditionalInformation.attachments = [...organizedData.additionalAttachments];
                    appointment.steps = step;
                    break;

                case '7':
                    appointment.steps = step;
                    appointment.status = "requested",
                        appointment.cardDetails.cardId = body.cardId
                    break;

                default:
                    return res.status(400).json({ message: 'Invalid step' });
            }

            let details = await appointment.save();
            let finalDetails = {
                appointmentId: details._id,
                step: details.steps
            }
            return res.json({ status: HTTP_STATUS.OK, data: finalDetails, message: MESSAGE.CREATE });
        } catch (error) {
            return res.status(500).json({ message: 'An error occurred', error: error.message });
        }
    }
    getappointmentBooking = async (req: Request, res: Response) => {
        const { appointmentId } = req.params;
        try {
            const appointment = await Appointment.findOne({ _id: Types.ObjectId(appointmentId) });
            if (!appointment) {
                return res.status(404).json({ message: 'Appointment not found' });
            }
            return res.json({ status: HTTP_STATUS.OK, data: appointment });
        } catch (error) {
            return res.status(500).json({ message: 'An error occurred', error: error.message });
        }

    }
    getAllAppointment = async (req: Request, res: Response) => {
        try {
            const { _id }: any = req.user;
            const appointment = await Appointment.find({ patientId: Types.ObjectId(_id), status: { $ne: '' } });
            if (!appointment) {
                return res.status(404).json({ message: 'Appointment not found' });
            }
            return res.json({ status: HTTP_STATUS.OK, data: appointment });
        } catch (error) {
            return res.status(500).json({ message: 'An error occurred', error: error.message });
        }
    }
    AddCardDetails = async (req: Request, res: Response) => {
        const { _id }: any = req.user;
        const { paymentMethod, name, cardNumber, expiry, ccv, cardId } = req.body;

        try {
            const patient = await Patient.findById({ "_id": Types.ObjectId(_id) });
            if (!patient) {
                return res.status(404).json({ message: 'Patient not found' });
            }
            console.log(patient);

            const cardIndex = patient.addCardDetails.findIndex(card => card._id == cardId);
            console.log(cardIndex)
            if (cardIndex !== -1) {
                patient.addCardDetails[cardIndex] = {
                    _id: cardId,
                    paymentMethod,
                    name,
                    cardNumber,
                    expiry,
                    ccv
                };
            } else {
                patient.addCardDetails.push({
                    paymentMethod,
                    name,
                    cardNumber,
                    expiry,
                    ccv
                });
            }

            const updatedPatient = await patient.save();
            return res.json({ status: 'success', data: updatedPatient });
        } catch (error) {
            return res.status(500).json({ message: 'An error occurred', error: error.message });
        }
    }

    payment = async (req: Request, res: Response) => {
        try {
            const { patientId, number, exp_month, exp_year, cvc } = req.body;
            process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0";
            const userData = await Patient.findOne({ _id: Types.ObjectId(patientId) });
            if (!userData) return res.status(404).send({ responseMessage: MESSAGE.USER_NOT_FOUND });
            const token = await stripeClient.tokens.create({
                card: {
                    number: number,
                    exp_month: exp_month,
                    exp_year: exp_year,
                    cvc: cvc,
                },
            });
            console.log('token>>>>>>>>>>>>', token)
            const customer = await stripeClient.customers.create({
                email: userData.email,
                source: token.id,
            });
            console.log('customer>>>>>>>>>>>>>>>', customer)
            const charge = await stripeClient.charges.create({
                amount: 10000,
                currency: 'inr',
                customer: customer.id,
            });
            console.log("charge", charge)
            const paymentObj = {
                transactionId: charge.balance_transaction,
                chargeId: charge.id,
                currency: charge.currency,
                amount: req.body.price,
                customerId: charge.customer,
                url: charge.receipt_url,
                email: customer.email,
                transactionStatus: charge.status,
                userId: patientId,
                paymentType: req.body.cardType,
            };
            const paymentData = new Transaction(paymentObj);
            await paymentData.save();
            const updateData = await Appointment.findOneAndUpdate(
                { _id: req.body.AppointmentId },
                { $set: { paymentStatus: "success" } },
                { new: true }
            );
            return res.status(200).send({ responseMessage: "Subscribe successfully" });
        } catch (e) {
            console.log("catch", e);
        }
    }
    createTwilioToken = async (req, res) => {
        try {
            const { appointmentId, userId, receiverId } = req.body;
            const roomName = `room_${appointmentId}`;

            // Twilio API keys
            const accountSid = "AC409457662c8c6c2f453e136b5309811b";
            const apiKeySid = "SKf7ebbe5325abe7e58efd15d9821bb312";
            const apiKeySecret = "kCDA887UM5BqhE9AXumoddXF4zQzMl6E";
            //           var ACCOUNT_SID ='AC9e81f91126842ceba749874770e3012d'
            // var API_KEY_SID ='SKf7ebbe5325abe7e58efd15d9821bb312'
            // var API_KEY_SECRET ='kCDA887UM5BqhE9AXumoddXF4zQzMl6E'
            // var receiverToken = new AccessToken(
            //     ACCOUNT_SID,
            //     API_KEY_SID,
            //     API_KEY_SECRET
            // );

            // Create an Access Token for the receiver
            //   const receiverToken = new AccessToken(accountSid, apiKeySid, apiKeySecret);
            // console.log(receiverToken)
            const accessToken = new twilio.jwt.AccessToken(accountSid, apiKeySid, apiKeySecret);
            console.log("accessToken", accessToken)
            // Set the Identity of this token
            // const identity = 'unique_identity_here'; // This should be a unique identifier for the user
            // accessToken.identity = identity;
            //   receiverToken.identity = receiverId;

            //   const receiverVideoGrant = new VideoGrant();
            //   receiverVideoGrant.room = roomName;
            //   receiverToken.addGrant(receiverVideoGrant);

            //   // Serialize the receiver token as a JWT
            //   const receiverJwt = receiverToken.toJwt();

            //   // Create an Access Token for the sender
            //   const senderToken = new AccessToken(accountSid, apiKeySid, apiKeySecret);
            //   senderToken.identity = userId;

            //   const senderVideoGrant = new VideoGrant();
            //   senderVideoGrant.room = roomName;
            //   senderToken.addGrant(senderVideoGrant);

            //   // Serialize the sender token as a JWT
            //   const senderJwt = senderToken.toJwt();

            //   // Fetch user data (you may need to implement this if not already done)
            //   const senderData = await Patient.findOne({ _id: userId });
            //   const receiverData = await ExpertConsultant.findOne({ _id: receiverId });

            //   if (!receiverData) {
            //     return res.status(404).json({ responseMessage: "User Not found" });
            //   }

            // Return the tokens and room name
            // return res.status(200).json({
            //     responseMessage: "Access Tokens",
            //     senderJwt,
            //     receiverJwt,
            //     roomName,
            //     senderData, // Include user data if needed
            //     receiverData // Include user data if needed
            // });
        } catch (error) {
            console.error("An error occurred:", error);
            return res.status(500).json({ responseMessage: "Something went wrong", error: error.message });
        }
    }
    getAllCard = async (req: Request, res: Response) => {
        const { _id }: any = req.user;
        try {
            const patinetDetails = await Patient.findOne({ _id: Types.ObjectId(_id) }, { addCardDetails: 1, _id: 0 });
            if (!patinetDetails) {
                return res.status(404).json({ message: 'card not found' });
            }
            return res.json({ status: HTTP_STATUS.OK, data: patinetDetails });
        } catch (error) {
            return res.status(500).json({ message: 'An error occurred', error: error.message });
        }

    }
    bookingCancellation = async (req: Request, res: Response) => {
        try {
            const { _id }: any = req.user;
            const userData = await Patient.findOne({ _id });
            const query = { _id: req.body.appointmentId };
            const appointmentDetails = await Appointment.findOne(query).lean();

            if (!appointmentDetails) {
                return res.status(404).json({ responseCode: 404, responseMessage: MESSAGE.USER_NOT_FOUND });
            }
            const doctorData = await ExpertConsultant.findOne({ _id: appointmentDetails.seheduleAppointment.expertConsulatant });
            const currentTime = new Date().getTime();
            const appointmentDate = new Date(appointmentDetails.seheduleAppointment.isoStartTime);
            const appointmentTime = appointmentDate.getTime();
            console.log('appointmentDate', appointmentTime);
            const update = {
                $set: {
                    'seheduleAppointment.cancelReason': req.body.reason,
                    status: 'cancelled',
                    'seheduleAppointment.cancelledBy': req.body.cancelledBy,
                },
            };

            if (appointmentTime - currentTime <= 7200000) {
                const updatedAppointmentStatus = await Appointment.findOneAndUpdate({ _id: req.body.appointmentId }, update, { new: true });

                if (updatedAppointmentStatus) {
                    sendPatientCancelationEmail(userData, 'You have successfully canceled the appointment', 1)
                        .then(() => {
                            console.log('Email sent successfully.');
                        })
                        .catch(error => {
                            console.error('Error sending email:', error);
                        });

                    sendExpertCancelationEmail(doctorData, 'You have successfully canceled the appointment', 1)
                        .then(() => {
                            console.log('Email sent successfully.');
                        })
                        .catch(error => {
                            console.error('Error sending email:', error);
                        });
                    return res.status(HTTP_STATUS.OK).json({ status: HTTP_STATUS.OK, message: MESSAGE.APPOINTMENT_SUCCESS });
                }
            } else {
                return res.status(HTTP_STATUS.OK).json({ responseMessage: "Can't cancel now" });
            }
        } catch (e) {
            console.error(e);
            return res.status(501).json({ responseCode: 501, responseMessage: MESSAGE.SOMETHING_WRONG, error: e.message });
        }
    }
    rescheduleAppointment = async (req: Request, res: Response) => {
        try {
            const { _id }: any = req.user;
            const userData = await Patient.findOne({ _id });
            const query = { _id: Types.ObjectId(req.body.appointmentId) };
            const appointment = await Appointment.findById(query);
            if (!appointment) {
                return res.status(404).json({ responseCode: 404, responseMessage: MESSAGE.USER_NOT_FOUND });
            }
            const doctorData = await ExpertConsultant.findOne({ _id: appointment.seheduleAppointment.expertConsulatant });
            const currentTime = new Date().getTime();
            let appointmentDate = new Date(appointment.seheduleAppointment.isoStartTime);
            let appointmentTime = appointmentDate.getTime();
            if (appointmentTime - currentTime <= 7200000) {
                function convertToISOFormat(dateStr: string, timeStr: string): any {
                    console.log(timeStr)
                    const [startDate, endDate] = timeStr.split(' - ');
                    const startDateTime = new Date(`${dateStr} ${startDate}`);
                    const endDateTime = new Date(`${dateStr} ${endDate}`);
                    if (isNaN(startDateTime.getTime()) || isNaN(endDateTime.getTime())) {
                        return null;
                    }
                    const isoStart = startDateTime.toISOString();
                    const isoEnd = endDateTime.toISOString();
                    return [isoStart, isoEnd];
                }

                let dateStr: any = appointmentDate;
                let timeStr: any = appointmentTime;

                appointmentDate = req.body.appointmentDate;
                appointmentTime = req.body.appointmentTime;

                 dateStr = appointmentDate;
                 timeStr = appointmentTime;
                 appointment.seheduleAppointment.appointmentDate = appointmentDate;
                 appointment.seheduleAppointment.appointmentTime = appointmentTime;
                 appointment.status = "rescheduled";
                const isoFormat: any = convertToISOFormat(dateStr, timeStr);
                console.log(isoFormat)

                if (isoFormat !== null) {
                    appointment.seheduleAppointment.isoStartTime = isoFormat[0];
                    appointment.seheduleAppointment.isoEndTime = isoFormat[1];
                } else {
                    console.log('Invalid date or time format');
                }


                function convertToUnixTimestamp(dateStr: string, timeStr: string): any {
                    const dateTimeRegex = /^(\d{4}-\d{2}-\d{2}) (\d{2}:\d{2} [APap][Mm]) - (\d{2}:\d{2} [APap][Mm])$/;
                    if (!dateTimeRegex.test(`${dateStr} ${timeStr}`)) {
                        throw new Error("Invalid date or time format");
                    }
                    const [_, datePart, startTime, endTime] = dateTimeRegex.exec(`${dateStr} ${timeStr}`);
                    const startDate = new Date(`${datePart} ${startTime}`);
                    const endDate = new Date(`${datePart} ${endTime}`);
                    const unixStartTime = startDate.getTime() / 1000;
                    const unixEndTime = endDate.getTime() / 1000;

                    return { unixStartTime, unixEndTime };
                }

                const { unixStartTime, unixEndTime }: any = convertToUnixTimestamp(dateStr, timeStr);
                appointment.seheduleAppointment.unixStartTime = unixStartTime;
                appointment.seheduleAppointment.unixEndTime = unixEndTime;
                const updatedAppointmentStatus = await appointment.save();
                if (updatedAppointmentStatus) {
                    sendPatientCancelationEmail(userData, 'You have successfully canceled the appointment', 1)
                        .then(() => {
                            console.log('Email sent successfully.');
                        })
                        .catch(error => {
                            console.error('Error sending email:', error);
                        });

                    sendExpertCancelationEmail(doctorData, 'You have successfully canceled the appointment', 1)
                        .then(() => {
                            console.log('Email sent successfully.');
                        })
                        .catch(error => {
                            console.error('Error sending email:', error);
                        });
                    return res.status(HTTP_STATUS.OK).json({ status: HTTP_STATUS.OK, message: MESSAGE.APPOINTMENT_RECHEDULED });
                }
            } else {
                return res.status(HTTP_STATUS.OK).json({ responseMessage: "Can't cancel now" });
            }
        } catch (e) {
            console.error(e);
            return res.status(501).json({ responseCode: 501, responseMessage: MESSAGE.SOMETHING_WRONG, error: e.message });
        }
    }
}