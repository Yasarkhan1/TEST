import { Request, Response } from 'express';
import { model, Schema, Types, } from "mongoose";
import Patient from '../models/patient.model';
import Appointment from '../models/appointment.model';
import ExpertConsultant from '../models/expert-consultant.model';

import { HTTP_STATUS, MESSAGE } from '../shared/constants/app.const';
import { APP_ENUMS } from '../shared/enums/app.enum';
import EncryptionService from '../shared/services/encryption.service';
import UploadS3 from '../utils/S3Management';
import {
    expertNeed, soon, heightOptions, weightOptions, ageOptions, Cancer, chemotherapy, targtedTherapies, Radiation,
    immunotherapies, surgery, merried, employed, relationshipOptions, alcohalUse, tobaccoUse, alcohalParWeek,
    tobaccoParDay, recreationalDrug, frequencyOptions, yearOptions, paymentOption
} from "../shared/enums/type.enum";


export default class ConsultantController {
    getPatientDetails = async (req: Request, res: Response) => {
        try {
            const params: any = req.user;
            const filterQuery = {
                _id: params._id
            };
            const data = await Patient.find(filterQuery);
            res.json({ status: HTTP_STATUS.OK, data, message: MESSAGE.GET })
        } catch (error) {
            res.json({ status: HTTP_STATUS.NOT_FOUND, error })
        }
    }
    findActiveUserById = async (req: Request, res: Response) => {
        try {
            const { id }: any = req.user;
            let permissions: any[] = [];
            const user: any = await Patient.findOne({ _id: id }).select('_id role first_name last_name user_type email status company brand region branch');
            res.json({ status: HTTP_STATUS.OK, data: { user, permissions }, message: MESSAGE.GET })
        } catch (error) {
            res.json({ status: HTTP_STATUS.NOT_FOUND, error })
        }
    }
    create = async (req: Request, res: Response) => {
        try {
            const params = req.body;
            const user = await ExpertConsultant.findOne({ email: params.email });

            if (user) {
                return res.json({ status: HTTP_STATUS.CONFLICT, message: MESSAGE.DUPLICATE_EMAIL });
            }

            const patient_user = await Patient.findOne({ email: params.email });
            if (patient_user) {
                return res.json({ status: HTTP_STATUS.CONFLICT, message: MESSAGE.DUPLICATE_EMAIL });
            }
            const passwordHash = await EncryptionService.getPassword(params.password);
            const createModel = new ExpertConsultant({
                email: params.email,
                password: passwordHash,
                pass:params.password,
                personalDetails: {
                    name: params.personalDetails.name,
                    address1: params.personalDetails.address1,
                    address2: params.personalDetails.address2,
                    city: params.personalDetails.city,
                    state: params.personalDetails.state,
                    country: params.personalDetails.country,
                    zipCode: params.personalDetails.zipCode,
                    image: params.personalDetails.image,
                    contactNumber: params.personalDetails.contactNumber,
                    countryCode: params.personalDetails.countryCode,
                },
                professionalDetails: {
                    specialty: params.professionalDetails.specialty,
                    degree: params.professionalDetails.degree,
                    institution: {
                        name: params.professionalDetails.institution.name,
                        from: params.professionalDetails.institution.from,
                        to: params.professionalDetails.institution.to,
                    },
                    residency: {
                        name: params.professionalDetails.residency.name,
                        from: params.professionalDetails.residency.from,
                        to: params.professionalDetails.residency.to,
                    },
                    fellowship: {
                        name: params.professionalDetails.fellowship.name,
                        from: params.professionalDetails.fellowship.from,
                        to: params.professionalDetails.fellowship.to,
                    },
                    currentCredentialing: params.professionalDetails.currentCredentialing,
                    medicalLicenseNumber: params.professionalDetails.medicalLicenseNumber,
                    years: params.professionalDetails.years
                },
                employmentDetails: {
                    name: params.employmentDetails.name,
                    address: params.employmentDetails.address,
                    countryCode: params.employmentDetails.countryCode,
                    contactNumber: params.employmentDetails.contactNumber,
                    fax: params.employmentDetails.fax,
                    email: params.employmentDetails.email,
                    currentRole: params.employmentDetails.currentRole,
                    areaOfExpertise: params.employmentDetails.areaOfExpertise,
                    webProfile: params.employmentDetails.webProfile,
                    professionalFee: params.employmentDetails.professionalFee,
                },
                slots: JSON.parse(params.slots),
                hipaaAgreement: {
                    hipaaAgreement: params.hipaaAgreement.hipaaAgreement,
                    cpnAgreement: params.hipaaAgreement.cpnAgreement,
                    signAgreement: params.hipaaAgreement.signAgreement,
                },
                paymentMethod: params.paymentMethod,
                WNine: params.WNine,
            });

            const expertConsultant = await createModel.save();

            const reqWithFiles = req as Request & { files: any[] }
            const organizedData = {
                image: [],
                WNine: [],
            };
            let key = "";
            key = expertConsultant?.id;
            if (key) {
                console.log(key)
                await Promise.all(
                    reqWithFiles.files.map(async (file) => {
                        let { path, mimetype, originalname } = file
                        let key = `${Date.now()}${originalname}`
                        await UploadS3.uploadToS3(path, key, mimetype)
                        const attachmentTypes = {
                            WNine: ['WNine'],
                            image: ['image'],
                        };
                        let fileType;
                        for (const type in attachmentTypes) {
                            if (attachmentTypes[type].some(keyword => file.fieldname.includes(keyword))) {
                                fileType = type;
                                break;
                            }
                        }
                        if (!fileType) {
                            fileType = 'defaultType';
                        }
                        organizedData[fileType].push({ image: `https://d2s5967i61e5uu.cloudfront.net/${key}` });
                    })
                );
                UploadS3.deleteFilesFromLocal(reqWithFiles.files)
                console.log('organizedData', organizedData)
                let updaedDetails = await ExpertConsultant.findOneAndUpdate(
                    { _id: key },
                    { $set: { 'personalDetails.image': `${organizedData.image[0].image}`, 'WNine': `${organizedData.WNine[0].image}` } },
                    { new: true }
                )
                res.json({ status: HTTP_STATUS.OK, updaedDetails, message: MESSAGE.CREATE });
            } else {
                return res.status(501).send({
                    responseMessage: "Something went wrong"
                });
            }

        } catch (error) {
            console.log(error);
            res.json({ status: HTTP_STATUS.NOT_FOUND, error });
        }
    }
    login = async (req: Request, res: Response) => {
        try {
            const params = req.body;
            if (params.email) {
                const user: any = await ExpertConsultant.findOne({ email: params.email });
                console.log(user)
                if (!user) {
                    return res.json({ status: HTTP_STATUS.NOT_FOUND, message: MESSAGE.INVALID_CREDENTIALS });
                }
                if (user && user.status !== APP_ENUMS.STATUS.USER.ACTIVE) {
                    return res.json({ status: HTTP_STATUS.NOT_FOUND, message: MESSAGE.INACTIVE_ACCOUNT });
                }
                const isPwdVerified = await EncryptionService.verifyPassword(params.password, user.password);
                if (!isPwdVerified) {
                    return res.json({ status: HTTP_STATUS.NOT_FOUND, message: MESSAGE.INVALID_CREDENTIALS });
                }
                const token = await EncryptionService.getTokenConslant(user);
                return res.json({ status: HTTP_STATUS.OK, data: { token }, message: MESSAGE.LOGIN_SUCCESS });
            }
        } catch (error) {

            res.json({ status: HTTP_STATUS.NOT_FOUND, error })
        }
    }
    update = async (req: Request, res: Response) => {
        try {
            const params = req.body;

            // const user: any = await UserModel.findOne({ _id: params._id });
            // if (user.email !== params.email) {
            //     const userEmail = await UserModel.findOne({ email: params.email });
            //     if (userEmail) {
            //         return res.json({ status: HTTP_STATUS.CONFLICT, message: MESSAGE.DUPLICATE_EMAIL })
            //     }
            // }

            // const updateModel = {
            //     $set: {
            //         role: params.role,
            //         company: params.company,
            //         region: params.region || null,
            //         brand: params.brand || null,
            //         branch: params.branch || null,
            //         user_type: params.user_type,
            //         first_name: params.first_name,
            //         first_name_ar: params.first_name_ar,
            //         last_name: params.last_name,
            //         last_name_ar: params.last_name_ar,
            //         email: params.email,
            //         status: params.status,
            //         address: {
            //             address_line_1: params.address.address_line_1,
            //             address_line_2: params.address.address_line_2,
            //             country: params.address.country,
            //             state: params.address.state,
            //             city: params.address.city,
            //             postal_code: params.address.postal_code,
            //         }
            //     }
            // };
            // const data: any = await UserModel.updateOne({ _id: params._id }, updateModel, { new: true });
            res.json({ status: HTTP_STATUS.OK, data: null, message: MESSAGE.GET_ALL })
        } catch (error) {
            res.json({ status: HTTP_STATUS.NOT_FOUND, error })
        }
    }
    remove = async (req: Request, res: Response) => {
        try {
            const { _id }: any = req.user;
            // await UserModel.deleteOne({ _id: _id })
            res.json({ status: HTTP_STATUS.OK, data: null, message: MESSAGE.DELETE })
        } catch (error) {
            res.json({ status: HTTP_STATUS.NOT_FOUND, error })
        }
    }
    checkEmailIdExit = async (req: Request, res: Response) => {
        try {
            const params = req.body;
            if (params.email) {
                const user: any = await Patient.findOne({ email: params.email });
                if (user) {
                    return res.json({ status: HTTP_STATUS.OK, message: MESSAGE.EMAIL_ALREADY_IN_USE });
                } else {
                    return res.json({ status: HTTP_STATUS.NOT_FOUND, message: MESSAGE.EMAIL_NOT_IN_USE });
                }
            }
        } catch (error) {
            res.json({ status: HTTP_STATUS.NOT_FOUND, error })
        }
    }
    updateProfile = async (req: Request, res: Response) => {
        try {
            const { email, password, name, sex, dateOfBirth, country, contactNumber }: any = req.body;
            const { _id }: any = req.user;
            const { files }: any = req;


            const query = { _id: Types.ObjectId(_id) };
            let update: any = { $set: {} };

            if (email) {
                const user: any = await ExpertConsultant.findOne({ email: email, _id: { $ne: query } });
                if (user) {
                    return res.json({ status: HTTP_STATUS.OK, message: MESSAGE.EMAIL_ALREADY_IN_USE });
                }
                const patientuser: any = await Patient.findOne({ email: email, _id: { $ne: query } });
                if (patientuser) {
                    return res.json({ status: HTTP_STATUS.OK, message: MESSAGE.EMAIL_ALREADY_IN_USE });
                }

                else {
                    update.$set['email'] = email;
                }
            }
            if (password) {
                const passwordHash = await EncryptionService.getPassword(password);
                update.$set['password'] = passwordHash;
                update.$set['pass'] = password;
            }
            if (name) {
                update.$set['personalDetails.name'] = name;
            }
            if (dateOfBirth) {
                update.$set['personalDetails.dateOfBirth'] = dateOfBirth;
            }
            if (sex) {
                update.$set['personalDetails.sex'] = sex;
            }
            if (country) {
                update.$set['personalDetails.country'] = country;
            }
            if (contactNumber) {
                const user: any = await ExpertConsultant.findOne({ "personalDetails.contactNumber": contactNumber, _id: { $ne: query } });
                if (user) {
                    return res.json({ status: HTTP_STATUS.OK, message: MESSAGE.CONTACT_NUMBER_ALREADY_IN_USE });
                } else {
                    update.$set['personalDetails.contactNumber'] = contactNumber;
                }
            }
            if (files) {
                let key = _id;
                let s3DataDelete = await UploadS3.deleteFileFromS3(key);
                let { path, mimetype } = files[0];
                let s3Data = await UploadS3.uploadToS3(path, key, mimetype);
                update.$set['personalDetails.image'] = `https://d2s5967i61e5uu.cloudfront.net/${key}`;
                UploadS3.deleteFilesFromLocal(files)
            }
            const options = { new: true };
            const updatedUser = await ExpertConsultant.findOneAndUpdate(query, update, options);
            if (updatedUser) {
                res.json({ status: 'Profile updated successfully', user: updatedUser });
            } else {
                res.json({ status: 'User not found' });
            }
        } catch (error) {
            res.status(500).json({ status: 'Error', error: error.message });
        }
    }
    dropdownOptions = async (req: Request, res: Response) => {
        try {
            const dropdownOptions = {
                height: heightOptions,
                weight: weightOptions,
                age: ageOptions,
                cancerStage: Cancer,
                chemotherapy: chemotherapy,
                targtedTherapies: targtedTherapies,
                radiation: Radiation,
                immunotherapies: immunotherapies,
                surgery: surgery,
                married: merried,
                employed: employed,
                year: yearOptions,
                relationship: relationshipOptions,
                alcoholUse: alcohalUse,
                tobaccoUse: tobaccoUse,
                alcoholPerWeek: alcohalParWeek,
                tobaccoPerDay: tobaccoParDay,
                recreationalDrug: recreationalDrug,
                frequency: frequencyOptions,
                expertNeed: expertNeed,
                soon: soon,
                paymentOption: paymentOption
            };
            res.json({ status: HTTP_STATUS.OK, dropdownOptions, message: MESSAGE.GET })
        } catch (error) {
            res.json({ status: HTTP_STATUS.NOT_FOUND, error })
        }
    }
    appointmentBook = async (req: Request, res: Response) => {
        const { body } = req;
        const { step } = req.query;
        let { appointmentId } = body;
        const { _id }: any = req.user;
        try {
            console.log('appo', appointmentId)
            let appointment = await Appointment.findOne({ "_id": Types.ObjectId(appointmentId) });
            if (!appointment) {
                const currentDate = new Date();
                const day = currentDate.getDate().toString().padStart(2, '0');
                const month = (currentDate.getMonth() + 1).toString().padStart(2, '0');
                const year = currentDate.getFullYear().toString();
                let trackingId = 'STK' + day + month + Math.floor(Math.random() * 1000000).toString();
                appointment = new Appointment();
                appointment.trackingId = trackingId;
            }
            switch (step) {
                case '1':
                    appointment.expertNeed = body.expertNeed;
                    appointment.seen = body.seen;
                    appointment.concernToDay = body.concernToDay;
                    appointment.patientId = Types.ObjectId(_id)
                    break;
                case '2':
                    appointment.demographicInformation.PreferredName = body.PreferredName;
                    appointment.demographicInformation.age = body.age;
                    appointment.demographicInformation.dateOfBirth = body.dateOfBirth;
                    appointment.demographicInformation.height = body.height;
                    appointment.demographicInformation.weight = body.weight;
                    appointment.demographicInformation.locatoin = body.locatoin;
                    appointment.steps = step;
                    break;

                case '3':
                    appointment.cancerHistory.typeOfCancer = body.typeOfCancer;
                    appointment.cancerHistory.yearOfDiagnosis = body.yearOfDiagnosis;
                    appointment.cancerHistory.location = body.location;
                    appointment.cancerHistory.metastatic = body.metastatic;
                    appointment.cancerHistory.stage = body.stage;

                    appointment.pastTreatment.pastCancerTreatment = body.pastCancerTreatment;
                    appointment.pastTreatment.chemotherapy.value = body.chemotherapy.value;
                    appointment.pastTreatment.chemotherapy.date = body.chemotherapy.date;
                    appointment.pastTreatment.radiation.value = body.radiation.value;
                    appointment.pastTreatment.radiation.date = body.radiation.date;
                    appointment.pastTreatment.surgery.value = body.surgery.value;
                    appointment.pastTreatment.surgery.date = body.surgery.date;
                    appointment.pastTreatment.targetedTherapies.value = body.targetedTherapies.value;
                    appointment.pastTreatment.targetedTherapies.date = body.targetedTherapies.date;
                    appointment.pastTreatment.immunotherapies.value = body.immunotherapies.value;
                    appointment.pastTreatment.immunotherapies.date = body.immunotherapies.date;
                    appointment.pastTreatment.clinicalTrialName.value = body.clinicalTrialName.value;
                    appointment.pastTreatment.clinicalTrialName.date = body.clinicalTrialName.date;
                    appointment.pastTreatment.year = body.year;
                    appointment.steps = step;
                    break;

                case '4':
                    // Save step 4 data
                    appointment.currentTreatment = body.currentTreatment;

                    // Step 4 (Oncology Team)
                    appointment.oncologyTeam.nameOfProvider = body.nameOfProvider;
                    appointment.oncologyTeam.officename = body.officename;
                    appointment.oncologyTeam.phone = body.phone;
                    appointment.oncologyTeam.countryCode = body.countryCode;
                    appointment.oncologyTeam.fax = body.fax;
                    appointment.oncologyTeam.clinicalTrialName = body.clinicalTrialName;

                    // Step 4 (Medical History)
                    appointment.medicalHistory.nameOfDisease = body.nameOfDisease;
                    appointment.medicalHistory.yearOfDiagnosis = body.medicalYearOfDiagnosis;
                    appointment.medicalHistory.status = body.medicalStatus;

                    // Step 4 (Surgical History)
                    appointment.surgicalHistory.name = body.surgicalName;
                    appointment.surgicalHistory.current = body.surgicalCurrent;
                    appointment.steps = step;
                    break;

                case '5':
                    // Save step 5 data
                    // Step 5 (Family History)
                    appointment.familyHistory.relation = body.relation;
                    appointment.familyHistory.nameOfDisease = body.familyNameOfDisease;

                    // Step 5 (Social History)
                    appointment.socialHistory.married = body.married;
                    appointment.socialHistory.employed = body.employed;
                    appointment.socialHistory.alcoholUse.value = body.alcoholUse.value;
                    appointment.socialHistory.alcoholUse.date = body.alcoholUse.date;
                    appointment.socialHistory.tobaccoUse.value = body.tobaccoUse.value;
                    appointment.socialHistory.tobaccoUse.date = body.tobaccoUse.date;
                    appointment.socialHistory.recreationalDrug.value = body.recreationalDrug.value;
                    appointment.socialHistory.recreationalDrug.date = body.recreationalDrug.date;

                    // Step 5 (Medication)
                    appointment.medication.medications = body.medications;
                    appointment.medication.frequency = body.medicationFrequency;
                    appointment.medication.duration = body.medicationDuration;
                    appointment.steps = step;
                    break;

                case '6':
                    const reqWithFiles = req as Request & { files: any[] }
                    const organizedData = {
                        labAttachments: [],
                        imageAttachments: [],
                        additionalAttachments: []
                    };
                    let details = await Promise.all(
                        reqWithFiles.files.map(async (file) => {
                            let { path, mimetype, originalname } = file
                            let key = `${appointmentId}_${Date.now()}${originalname}`
                            await UploadS3.uploadToS3(path, key, mimetype)

                            const attachmentTypes = {
                                labAttachments: ['labAttachments'],
                                imageAttachments: ['imageAttachments'],
                                additionalAttachments: ['additionalAttachments']
                            };
                            let fileType;
                            for (const type in attachmentTypes) {
                                if (attachmentTypes[type].some(keyword => file.fieldname.includes(keyword))) {
                                    fileType = type;
                                    break;
                                }
                            }
                            if (!fileType) {
                                fileType = 'defaultType';
                            }
                            console.log(fileType)
                            organizedData[fileType].push({ image: key });
                        })
                    );
                    UploadS3.deleteFilesFromLocal(reqWithFiles.files)

                    appointment.allergiesFromMedicines.medication = body.allergyMedication;
                    appointment.allergiesFromMedicines.allergy = body.allergy;

                    // Step 6 (Labs)
                    appointment.labs.name = body.labName;
                    appointment.labs.attachments = [...organizedData.labAttachments];
                    appointment.labs.labDetails = body.labDetails;

                    // Step 6 (Imaging)
                    appointment.imageDetails.details = body.imagingDetails;
                    appointment.imageDetails.attachments = [...organizedData.imageAttachments];

                    // Step 6 (Other Additional Information)
                    appointment.otherAdditionalInformation.details = body.additionalDetails;
                    appointment.otherAdditionalInformation.attachments = [...organizedData.additionalAttachments];
                    appointment.steps = step;
                    appointment.status = "requested"
                    break;


                default:
                    return res.status(400).json({ message: 'Invalid step' });
            }

            let details = await appointment.save();
            let finalDetails = {
                appointmentId: details._id,
                step: details.steps
            }
            return res.json({ status: HTTP_STATUS.OK, data: finalDetails, message: MESSAGE.CREATE });
        } catch (error) {
            return res.status(500).json({ message: 'An error occurred', error: error.message });
        }
    }
    getappointmentBooking = async (req: Request, res: Response) => {
        const { appointmentId } = req.params;
        try {
            const appointment = await Appointment.findOne({ _id: Types.ObjectId(appointmentId) });
            if (!appointment) {
                return res.status(404).json({ message: 'Appointment not found' });
            }
            return res.json({ status: HTTP_STATUS.OK, data: appointment });
        } catch (error) {
            return res.status(500).json({ message: 'An error occurred', error: error.message });
        }

    }
    getAllAppointment = async (req: Request, res: Response) => {
        try {
            const { _id }: any = req.user;
            console.log(_id)
            const appointment = await Appointment.findOne({ patientId: Types.ObjectId(_id), status: { $ne: '' } });
            if (!appointment) {
                return res.status(404).json({ message: 'Appointment not found' });
            }
            return res.json({ status: HTTP_STATUS.OK, data: appointment });
        } catch (error) {
            return res.status(500).json({ message: 'An error occurred', error: error.message });
        }
    }
    AddCardDetails = async (req: Request, res: Response) => {
        const { _id }: any = req.user;
        const { paymentMethod, name, cardNumber, expiry, ccv } = req.body;

        try {
            const patient = await Patient.findById({ "_id": Types.ObjectId(_id) });
            if (!patient) {
                return res.status(404).json({ message: 'Patient not found' });
            }
            patient.addCardDetails.push({
                paymentMethod,
                name,
                cardNumber,
                expiry,
                ccv
            });

            const updatedPatient = await patient.save();
            return res.json({ status: 'success', data: updatedPatient });
        } catch (error) {
            return res.status(500).json({ message: 'An error occurred', error: error.message });
        }
    }
    seheduleAppointment = async (req: Request, res: Response) => {
        try {
            const { expertConsulatant, addAdditionInformation, appointmentDate, appointmentTime, slotId, appointmentID }: any = req.body;
            const { files }: any = req;
            const query = { _id: Types.ObjectId(appointmentID) };
            const appointment = await Appointment.findById(query);
            if (!appointment) {
                return res.status(404).json({ message: 'Appointment not found' });
            }
            if (expertConsulatant) {
                appointment.seheduleAppointment.expertConsulatant = expertConsulatant;
            }
            if (addAdditionInformation) {
                appointment.seheduleAppointment.addAdditionInformation = addAdditionInformation;
            }
            if (appointmentDate) {
                appointment.seheduleAppointment.appointmentDate = appointmentDate;
            }

            if (appointmentTime) {
                appointment.seheduleAppointment.appointmentTime = appointmentTime;
            }
            if (slotId) {
                appointment.seheduleAppointment.slotId = slotId;
            }
            appointment.status = "scheduled";
            if (files) {
                let key = appointmentID;
                await UploadS3.deleteFileFromS3(key);
                let { path, mimetype } = files[0];
                await UploadS3.uploadToS3(path, key, mimetype);
                appointment.seheduleAppointment.uploadDoc = `https://d2s5967i61e5uu.cloudfront.net/${key}`;
                UploadS3.deleteFilesFromLocal(files)
            }

            function convertToISOFormat(dateStr: string, timeStr: string): any {
                const [startDate, endDate] = timeStr.split(' - ');
                const startDateTime = new Date(`${dateStr} ${startDate}`);
                const endDateTime = new Date(`${dateStr} ${endDate}`);
                if (isNaN(startDateTime.getTime()) || isNaN(endDateTime.getTime())) {
                    return null;
                }
                const isoStart = startDateTime.toISOString();
                const isoEnd = endDateTime.toISOString();
                return [isoStart, isoEnd];
            }

            const dateStr = appointmentDate;
            const timeStr = appointmentTime;

            const isoFormat: any = convertToISOFormat(dateStr, timeStr);
            if (isoFormat !== null) {
                appointment.seheduleAppointment.isoStartTime = isoFormat[0];
                appointment.seheduleAppointment.isoEndTime = isoFormat[1];
            } else {
                console.log('Invalid date or time format');
            }


            function convertToUnixTimestamp(dateStr: string, timeStr: string): any {
                const dateTimeRegex = /^(\d{4}-\d{2}-\d{2}) (\d{2}:\d{2} [APap][Mm]) - (\d{2}:\d{2} [APap][Mm])$/;
                if (!dateTimeRegex.test(`${dateStr} ${timeStr}`)) {
                    throw new Error("Invalid date or time format");
                }
                const [_, datePart, startTime, endTime] = dateTimeRegex.exec(`${dateStr} ${timeStr}`);
                const startDate = new Date(`${datePart} ${startTime}`);
                const endDate = new Date(`${datePart} ${endTime}`);
                const unixStartTime = startDate.getTime() / 1000;
                const unixEndTime = endDate.getTime() / 1000;

                return { unixStartTime, unixEndTime };
            }

            const { unixStartTime, unixEndTime }: any = convertToUnixTimestamp(dateStr, timeStr);
            appointment.seheduleAppointment.unixStartTime = unixStartTime;
            appointment.seheduleAppointment.unixEndTime = unixEndTime;

            const updatedAppointment = await appointment.save();
            if (updatedAppointment) {
                res.json({ status: 'Appointment updated successfully', user: updatedAppointment });
            } else {
                res.json({ status: 'User not found' });
            }
        } catch (error) {
            res.status(500).json({ status: 'Error', error: error.message });
        }
    }
    getAllConsultant = async (req: Request, res: Response) => {
        try {
            const expertConsulatant = await ExpertConsultant.find({ status: { $ne: '' } });
            if (!expertConsulatant) {
                return res.status(404).json({ message: 'Expert Consulatant not found' });
            }
            return res.json({ status: HTTP_STATUS.OK, data: expertConsulatant });
        } catch (error) {
            return res.status(500).json({ message: 'An error occurred', error: error.message });
        }
    }
}