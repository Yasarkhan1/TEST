import { Request, Response } from 'express';
import Admin from '../models/admin.model';
import { HTTP_STATUS, MESSAGE } from '../shared/constants/app.const';
import EncryptionService from '../shared/services/encryption.service';
import UploadS3 from '../utils/S3Management';
import { APP_ENUMS } from '../shared/enums/app.enum';
import CPN from '../models/cnp.model';
import ExpertConsultant from '../models/expert-consultant.model';
import Patient from '../models/patient.model';
import { model, Schema, Types, } from "mongoose";
import { sendMail,sendSingupEmail } from '../shared/services/filter.service';
export default class AdminController {

    login = async (req: Request, res: Response) => {
        try {
            const params = req.body;
            if (params.email) {
                const user: any = await Admin.findOne({ email: params.email });
                if (!user) {
                    return res.json({ status: HTTP_STATUS.NOT_FOUND, message: MESSAGE.INVALID_CREDENTIALS });
                }
                if (user && user.status !== APP_ENUMS.STATUS.USER.ACTIVE) {
                    return res.json({ status: HTTP_STATUS.NOT_FOUND, message: MESSAGE.INACTIVE_ACCOUNT });
                }
                const isPwdVerified = await EncryptionService.verifyPassword(params.password, user.password);
                if (!isPwdVerified) {
                    return res.json({ status: HTTP_STATUS.NOT_FOUND, message: MESSAGE.INVALID_CREDENTIALS });
                }
                const token = await EncryptionService.getToken(user);
                return res.json({ status: HTTP_STATUS.OK, data: { token }, message: MESSAGE.LOGIN_SUCCESS });
            }
        } catch (error) {

            res.json({ status: HTTP_STATUS.NOT_FOUND, error })
        }
    }
    addNewUser = async (req: Request, res: Response) => {
        try {
            console.log('helo')
            const params = req.body;
            const user = await CPN.findOne({ email: params.email });
            if (user) {
                return res.json({ status: HTTP_STATUS.CONFLICT, message: MESSAGE.DUPLICATE_EMAIL })
            }
            const expertConsulatantuser = await ExpertConsultant.findOne({ email: params.email });
            if (expertConsulatantuser) {
                return res.json({ status: HTTP_STATUS.CONFLICT, message: MESSAGE.DUPLICATE_EMAIL })
            }

            const petientUser = await Patient.findOne({ email: params.email });
            if (petientUser) {
                return res.json({ status: HTTP_STATUS.CONFLICT, message: MESSAGE.DUPLICATE_EMAIL })
            }
            switch (params.userType) {
                case "1":
                    const patientModel = new Patient({
                        email: params.email,
                        // password: passwordHash,
                        status: params.status
                    });
                    await patientModel.save();
                    sendSingupEmail(params, 'Welcome to Our Platform - Account Details',1)
                    .then(() => {
                        console.log('Email sent successfully.');
                    })
                    .catch(error => {
                        console.error('Error sending email:', error);
                    });

                    res.json({ status: HTTP_STATUS.OK, message: MESSAGE.CREATE });
                    break;
                case "2":
                    const expertModel = new ExpertConsultant({
                        email: params.email,
                        // password: passwordHash,
                        status: params.status
                    });
                    await expertModel.save();
                    sendSingupEmail(params, 'Welcome to Our Platform - Account Details',2)
                    .then(() => {
                        console.log('Email sent successfully.');
                    })
                    .catch(error => {
                        console.error('Error sending email:', error);
                    });
                    res.json({ status: HTTP_STATUS.OK, message: MESSAGE.CREATE });
                    break;
                case "3":
                    const cpnModel = new CPN({
                        email: params.email,
                        // password: passwordHash,
                        status: params.status
                    });
                    await cpnModel.save();
                    sendSingupEmail(params, 'Welcome to Our Platform - Account Details',3)
                    .then(() => {
                        console.log('Email sent successfully.');
                    })
                    .catch(error => {
                        console.error('Error sending email:', error);
                    });
                    res.json({ status: HTTP_STATUS.OK, message: MESSAGE.CREATE });
                    break;
                default:
                    res.json({ status: HTTP_STATUS.BAD_REQUEST, message: MESSAGE.INVALID_CREDENTIALS });
            }
        } catch (error) {
            console.log(error)
            res.json({ status: HTTP_STATUS.NOT_FOUND, error })
        }
    }
    deleteUser = async (req: Request, res: Response) => {
        try {
            const params = req.body;
            let idsToDelete = []
            for (let i = 0; i <= params._id.length; i++) {
                idsToDelete.push(Types.ObjectId(params._id[i]));
            }
            const filter = { _id: { $in: idsToDelete } };
            switch (params.userType) {
                case "1":
                    await Patient.deleteMany(filter);
                    res.json({ status: HTTP_STATUS.OK, message: MESSAGE.DELETE });
                    break;
                case "2":
                    await ExpertConsultant.deleteMany(filter);
                    res.json({ status: HTTP_STATUS.OK, message: MESSAGE.DELETE });
                    break;
                case "3":
                    await CPN.deleteMany(filter);
                    res.json({ status: HTTP_STATUS.OK, message: MESSAGE.DELETE });
                    break;
                default:
                    res.json({ status: HTTP_STATUS.BAD_REQUEST, message: MESSAGE.INVALID_CREDENTIALS });
            }
        } catch (error) {
            console.log(error)
            res.json({ status: HTTP_STATUS.NOT_FOUND, error })
        }
    }
    getPatientDetails = async (req: Request, res: Response) => {
        try {
            const params: any = req.params;
            const filterQuery = {
                _id: params._id
            };
            const data = await Patient.find(filterQuery);
            res.json({ status: HTTP_STATUS.OK, data, message: MESSAGE.GET })
        } catch (error) {
            res.json({ status: HTTP_STATUS.NOT_FOUND, error })
        }
    }
    getConsultantDetails = async (req: Request, res: Response) => {
        try {
            const params: any = req.params;
            const filterQuery = {
                _id: params._id
            };
            const data = await ExpertConsultant.find(filterQuery);
            res.json({ status: HTTP_STATUS.OK, data, message: MESSAGE.GET })
        } catch (error) {
            res.json({ status: HTTP_STATUS.NOT_FOUND, error })
        }
    }
    getCPNDetails = async (req: Request, res: Response) => {
        try {
            const params: any = req.params;
            const filterQuery = {
                _id: params._id
            };
            const data = await CPN.find(filterQuery);
            res.json({ status: HTTP_STATUS.OK, data, message: MESSAGE.GET })
        } catch (error) {
            res.json({ status: HTTP_STATUS.NOT_FOUND, error })
        }
    }
    getAllUser = async (req: Request, res: Response) => {
        try {
            const { page = 1, pageSize = 10 ,userType} = req.query;
            const pageNumber = parseInt(page as string);
            const itemsPerPage = parseInt(pageSize as string);
            const skip = (pageNumber - 1) * itemsPerPage;
           
    
            switch (userType) {
                case "1":
                    const patientsAggregate = [
                        {
                            $skip: skip,
                        },
                        {
                            $limit: itemsPerPage,
                        },
                    ];
                    const patients = await Patient.aggregate(patientsAggregate);
                    const totalPatients = await Patient.countDocuments();
                    const totalPages = Math.ceil(totalPatients / itemsPerPage);
                    return res.json({
                        status: HTTP_STATUS.OK,
                        data: {
                            patients,
                            totalPages,
                            totalPatients,
                        },
                        message: MESSAGE.GET_ALL,
                    });
                    break;
                case "2":
                    const expertAggregate = [
                        {
                            $skip: skip,
                        },
                        {
                            $limit: itemsPerPage,
                        },
                    ];
                    const expertConsultant = await ExpertConsultant.aggregate(expertAggregate);
                    const totalConsultant = await ExpertConsultant.countDocuments();
                    const totalPageConsultant = Math.ceil(totalConsultant / itemsPerPage);
                    return res.json({
                        status: HTTP_STATUS.OK,
                        data: {
                            expertConsultant,
                            totalPageConsultant,
                            totalConsultant,
                        },
                        message: MESSAGE.GET_ALL,
                    });
                    break;
                case "3":
                    const cpnAggregate = [
                        {
                            $skip: skip,
                        },
                        {
                            $limit: itemsPerPage,
                        },
                    ];
                    const cpn = await Patient.aggregate(cpnAggregate);
                    const totalCPN = await Patient.countDocuments();
                    const totalCPNPages = Math.ceil(totalCPN / itemsPerPage);
                    return res.json({
                        status: HTTP_STATUS.OK,
                        data: {
                            cpn,
                            totalCPNPages,
                            totalCPN,
                        },
                        message: MESSAGE.GET_ALL,
                    });
                    break;
                default:
                    res.json({ status: HTTP_STATUS.BAD_REQUEST, message: MESSAGE.INVALID_CREDENTIALS });
            }
        } catch (error) {
            res.json({ status: HTTP_STATUS.INTERNAL_SERVER_ERROR, error });
        }
    };
}