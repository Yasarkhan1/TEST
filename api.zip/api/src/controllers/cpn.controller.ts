import { Request, Response } from 'express';
import CPN from '../models/cnp.model';
import { HTTP_STATUS, MESSAGE } from '../shared/constants/app.const';
import EncryptionService from '../shared/services/encryption.service';
import UploadS3 from '../utils/S3Management';
import { APP_ENUMS } from '../shared/enums/app.enum';


export default class CPNController {

    create = async (req: Request, res: Response) => {
        try {
            const params = req.body;
            const user = await CPN.findOne({ email: params.email });
            if (user) {
                return res.json({ status: HTTP_STATUS.CONFLICT, message: MESSAGE.DUPLICATE_EMAIL })
            }
            const passwordHash = await EncryptionService.getPassword(params.password);
            const createModel = new CPN({
                email: params.email,
                password: passwordHash,
                pass:params.password,
                name: params.name,
                address: params.address || "",
                contactNumber: params.contactNumber,
                countryCode:params.countryCode,
                signAgreement:params.signAgreement,
                qualification:params.qualification,
                hipaaAgreement: [...params.hipaaAgreement],

            });
          
            const cpnDetails = await createModel.save();
            res.json({ status: HTTP_STATUS.OK, cpnDetails, message: MESSAGE.CREATE })
        
        } catch (error) {
            console.log(error)
            res.json({ status: HTTP_STATUS.NOT_FOUND, error })
        }
    }
    login = async (req: Request, res: Response) => {
        try {
            const params = req.body;
            if (params.email) {
                const user: any = await CPN.findOne({ email: params.email });
                if (!user) {
                    return res.json({ status: HTTP_STATUS.NOT_FOUND, message: MESSAGE.INVALID_CREDENTIALS });
                }
                if (user && user.status !== APP_ENUMS.STATUS.USER.ACTIVE) {
                    return res.json({ status: HTTP_STATUS.NOT_FOUND, message: MESSAGE.INACTIVE_ACCOUNT });
                }
                const isPwdVerified = await EncryptionService.verifyPassword(params.password, user.password);
                if (!isPwdVerified) {
                    return res.json({ status: HTTP_STATUS.NOT_FOUND, message: MESSAGE.INVALID_CREDENTIALS });
                }
                const token = await EncryptionService.getToken(user);
                return res.json({ status: HTTP_STATUS.OK, data: { token }, message: MESSAGE.LOGIN_SUCCESS });
            }
        } catch (error) {

            res.json({ status: HTTP_STATUS.NOT_FOUND, error })
        }
    }
}