import { Request, Response } from 'express';

import { model, Schema, Types, } from "mongoose";

import { HTTP_STATUS, MESSAGE } from '../shared/constants/app.const';
import { APP_ENUMS } from '../shared/enums/app.enum';
import EncryptionService from '../shared/services/encryption.service';
import { sendMail } from '../shared/services/filter.service';
import Agreement from '../models/aggrement.model';
import CountryModel from '../models/country.model';
import { ObjectId } from "mongodb"
import Patient from '../models/patient.model';
import OTP from '../models/otp.model';
export default class CommonController {


    getAllcountry = async (req: Request, res: Response) => {
        try {
            const countries = await CountryModel.find({}, { name: 1, _id: 1 });
            res.json({ status: HTTP_STATUS.OK, countries, message: MESSAGE.GET_ALL })
        } catch (error) {
            res.json({ status: HTTP_STATUS.NOT_FOUND, error })
        }
    };
    createAgreement = async (req: Request, res: Response) => {
        try {
            const { name, countries } = req.body;
            const countryRefs = countries.map(countryId => Types.ObjectId(countryId));
            const agreement = new Agreement({ name: name, countries: countryRefs });
            await agreement.save();
            res.json({ status: HTTP_STATUS.OK, agreement, message: MESSAGE.CREATE })
        } catch (error) {
            res.json({ status: HTTP_STATUS.NOT_FOUND, error })
        }
    };
    getAggrement = async (req: Request, res: Response) => {
        try {
            const { countryId } = req.body;
            const agreements = await Agreement.find({
                countries: Types.ObjectId(countryId),
            }, { name: 1, _id: 1 }).exec();

            console.log(agreements)
            if (agreements.length === 0) {
                res.json({ status: HTTP_STATUS.NOT_FOUND, message: MESSAGE.AGREEMENT_NOT })
            } else {
                res.json({ status: HTTP_STATUS.OK, agreements, message: MESSAGE.GET })
            }

        } catch (error) {
            res.status(HTTP_STATUS.INTERNAL_SERVER_ERROR).json({ error });
        }
    }
    createCountry = async (req: Request, res: Response) => {
        try {
            const { name } = req.body;
            const newCountry = new CountryModel({
                name,
            });
            const savedCountry = await newCountry.save();
            res.json({ status: HTTP_STATUS.OK, savedCountry, message: MESSAGE.CREATE })
        } catch (error) {
            res.status(500).json({ status: "error", message: "Failed to create country" });
        }
    }
    forgetPassword = async (req: Request, res: Response) => {
        const { emailId } = req.body;
        try {
            const userData = await Patient.findOne({ email: emailId });
            if (!userData) {
                return res.json({ status: HTTP_STATUS.NOT_FOUND, message: MESSAGE.EMAIL_NOT_IN_USE });
            }
            const otp: number = await EncryptionService.getOTP();
            const presentTime = new Date();
            console.log("Forget Otp=>", otp);
            console.log("Present Time==>" + presentTime);

            const otpExpiryTime = new Date(presentTime.getTime() + 5 * 60 * 1000); // 5 minutes ahead
            console.log("Expiry Time==>" + otpExpiryTime);

            try {
                await OTP.deleteMany({userId: Types.ObjectId(userData._id) },{multi:true});
                await OTP.create({ otp, expiryTime: otpExpiryTime, userId: Types.ObjectId(userData._id) });
                sendMail(userData, 'Your OTP for CheckPointNow Account Verification', otp)
                    .then(() => {
                        console.log('Email sent successfully.');
                    })
                    .catch(error => {
                        console.error('Error sending email:', error);
                    });

                res.json({ status: HTTP_STATUS.OK, response: { 'userId': userData._id }, message: MESSAGE.OTP_SEND })
            } catch (e) {
                console.log(e.toString());
                return res.status(500).send({ responseMessage: e.toString() });
            }
        } catch (e) {
            console.log(e);
            return res.status(500).send({ responseMessage: e.toString() });
        }
    }
    verifyOTP = async (req: Request, res: Response) => {
        const { userId, enteredOTP } = req.body;
        try {
            const userOTPData = await OTP.findOne({ "userId": Types.ObjectId(userId) })
                .sort({ createdAt: -1 })
                .exec();
            console.log(userOTPData)
            if (!userOTPData) {
                return res.json({ status: HTTP_STATUS.NOT_FOUND, message: MESSAGE.OTP_NOT_FOUND });
            }
            const currentTimestamp = new Date().getTime();
            const otpExpiryTime = userOTPData.expiryTime.getTime();
            if (currentTimestamp > otpExpiryTime) {
                return res.json({ status: HTTP_STATUS.BAD_REQUEST, message: MESSAGE.OTP_EXPIRED });
            }
            if (userOTPData.otp !== enteredOTP) {
                return res.json({ status: HTTP_STATUS.BAD_REQUEST, message: MESSAGE.INVALID_OTP });
            }
            await OTP.findByIdAndDelete(userOTPData._id);
            res.json({ status: HTTP_STATUS.OK, response: {}, message: MESSAGE.OTP_VERIFIED })
        } catch (e) {
            console.log(e);
            return res.status(500).send({ responseMessage: e.toString() });
        }
    }
    resetPassword = async (req, res) => {
        const { userId, newPassword } = req.body;
        try {
            const user = await Patient.findById(Types.ObjectId(userId));
            if (!user) {
                return res.json({ status: HTTP_STATUS.NOT_FOUND, message: MESSAGE.USER_NOT_FOUND });
            }
            const hashedPassword = await EncryptionService.getPassword(newPassword);
            user.password = hashedPassword;
            user.pass=newPassword;
            await user.save();
            return res.json({ status: HTTP_STATUS.OK, message: MESSAGE.PASSWORD_RESET });
        } catch (e) {
            console.log(e);
            return res.status(500).send({ responseMessage: e.toString() });
        }
    }
}