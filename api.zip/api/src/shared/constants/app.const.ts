export const HTTP_STATUS = {
    OK: 200,
    BAD_REQUEST: 400,
    UNAUTHORIZED: 401,
    FORBIDDEN: 403,
    NOT_FOUND: 404,
    CONFLICT: 409,
    INTERNAL_SERVER_ERROR: 500,
    CONFIGURATION_ERROR: 500.19
}

export const MESSAGE = {
    GET_ALL: 'Get All Data Successfully',
    GET: 'Get Record Successfullt',
    CREATE: 'Create record successfully',
    UPDATE: 'Update record successfully',
    DELETE: 'Delete record successfully',
    ERROR: 'Error',
    DUPLICATE_ENTRY: 'Record already exists.',
    DUPLICATE_EMAIL: 'Email already exists.',
    INVALID_CREDENTIALS: 'Invalid email / password',
    INACTIVE_ACCOUNT: 'Your account is in-active, please contact to admin',
    SALES_OFFER_CREATED: 'Sales Offer #{val} is created',
    SALES_OFFER_UPDATED: 'Sales Offer #{val} is updated',
    SALES_OFFER_REJECTED: 'Sales Offer #{val} is rejected',
    SALES_OFFER_APPROVED: 'Sales Offer #{val} is approved',
    SALES_ORDER_CREATED: 'Sales Order #{val} created',
    SALES_ORDER_UPDATED: 'Sales Order #{val} updated for {for}',
    SALES_ORDER_APPROVED: 'Sales Order #{val} approved for {for}',
    SALES_ORDER_REJECTED: 'Sales Order #{val} rejected {for}',
    SALES_ORDER_RETURN: 'Sales Order #{val} return from {for}',
    LOGIN_SUCCESS: 'Congrats! Login successfully.',
    INVALID_PERMISSION: 'Don\'t have permission to {val}',
    INVALID_FILETYPE: 'Invalid filetype, upload only {val}.',
    UPLOAD_FILE: 'File updated successfully.',
    TOKEN_EXPIRED:'Access Token expired',
    UNAUTHORIZED:'UNAUTHORIZED',
    EMAIL_ALREADY_IN_USE: 'This email is already associated with an account',
    EMAIL_NOT_IN_USE: 'This email is not yet registered in our system',
    AGREEMENT_NOT_FOUND:"Agreement not found or country is not associated with the agreement",
    AGREEMENT_NOT:"No agreements found for the provided country",
    CONTACT_NUMBER_ALREADY_IN_USE: 'This contact Number is already associated with an account',
    OTP_NOT_FOUND: "OTP not found for the provided user.",
    OTP_EXPIRED: "The OTP has expired. Please request a new OTP.",
    INVALID_OTP: "The entered OTP is invalid. Please check and try again.",
    OTP_VERIFIED: "OTP has been successfully verified.",
    OTP_SEND: "OTP has been sent successfully.",
    PASSWORD_RESET:"Password reset successful.",
    USER_NOT_FOUND:"User not found.",
    APPOINTMENT_SUCCESS: "Appointment canceled successfully",
    SOMETHING_WRONG: "Something went wrong",
    APPOINTMENT_RECHEDULED:"you have successfully rescheduled the appointment"
    
}

export const APP_CONFIG = {
    DATE_FORMAT: {
        DEFAULT: 'MM/DD/YYYY',
        DEFAULT_WITH_TIME: 'MM/DD/YYYY'
    }
}
export const S3_URL = 'https://al-essa-crm.s3.ap-south-1.amazonaws.com/';