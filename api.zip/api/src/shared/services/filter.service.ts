import { MESSAGE } from "../constants/app.const";
import { createTransport } from 'nodemailer';
import { MailOptions } from 'nodemailer/lib/json-transport';
import { Transporter } from 'nodemailer/lib/smtp-transport';
import { ReadStream } from 'fs';
import CONFIG from '../../config/config';
export const pdfFilter = (req: any, file: any, cb: any) => {
  if (file.mimetype === 'application/pdf') {
    cb(null, true);
  } else {
    const errorMessage = MESSAGE.INVALID_FILETYPE.replace('{val}', 'PDF');
    cb(new Error(errorMessage), false);
  }
}

export const sendMail = async (userDetails: any, subject: string, otp: Number) => {
  const transporter = createTransport({
    service: 'GMAIL',
    auth: {
      user: CONFIG.EMAIL,
      pass: CONFIG.PASSWORD
    },
    port: 465,
    host: 'smtp.gmail.com'
  });

  const html = `
    <!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    body {
      margin: 0;
      padding: 0;
      font-family: Arial, sans-serif;
      background-color: #f5f5f5;
    }
    .container {
      max-width: 600px;
      margin: 0 auto;
      padding: 20px;
      background-color: #ffffff;
      border-radius: 8px;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }
    .header {
      text-align: center;
      margin-bottom: 20px;
    }
    .logo {
      width: 200px;
      margin: 0 auto;
    }
    .content {
      font-size: 16px;
      line-height: 1.5;
      margin-bottom: 20px;
    }
    .otp-code {
      font-size: 24px;
      font-weight: bold;
      color: #be141b;
    }
    .footer {
      font-size: 14px;
      color: #888;
      text-align: center;
      margin-top: 20px;
    }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <div class="logo">
        <img src="logo_image_url" alt="CheckPointNow Logo" />
      </div>
    </div>
    <div class="content">
      <p>Dear ${userDetails.personalDetails.name},</p>
      <p>Thank you for choosing CheckPointNow for your account verification. To ensure the security of your account, we have generated a One-Time Password (OTP) for you.</p>
      <p>Your OTP is: <span class="otp-code">${otp}</span></p>
      <p>Please use this OTP to verify your account. This code will expire in [expiry time], so please make sure to enter it promptly.</p>
      <p>If you didn't request this OTP or have any concerns about your account security, please contact our support team immediately at [support email or phone number].</p>
      <p>Thank you for using CheckPointNow to keep your account secure.</p>
      <p>Best regards,<br>The CheckPointNow Team</p>
    </div>
    <div class="footer">
      <p>Note: This is an automated message. Please do not reply to this email. If you need assistance, contact our support team at [support email or phone number].</p>
    </div>
  </div>
</body>
</html>`;

  const mailBody = {
    from: "<do_not_reply@gmail.com>",
    to: userDetails.email,
    subject: subject,
    html: html
  };

  await transporter.sendMail(mailBody);
};
export const sendSingupEmail = async (userDetails: any, subject: string, userType: number) => {
  const transporter = createTransport({
    service: 'GMAIL',
    auth: {
      user: CONFIG.EMAIL,
      pass: CONFIG.PASSWORD
    },
    port: 465,
    host: 'smtp.gmail.com'
  });
  let link = ""
  if (userType == 1) {
    link = "http://15.206.13.50:4000/signup-as-patient-1"
  } else if (userType == 2) {
    link = "http://15.206.13.50:4000/signup-as-expert-1"
  } else {
    link = "http://15.206.13.50:4000"
  }
  const html = `
  <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {
            font-family: Arial, sans-serif;
        }
        .container {
            max-width: 600px;
            margin: 0 auto;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        .logo {
            text-align: center;
        }
        .content {
            margin-top: 20px;
        }
        .btn {
            display: inline-block;
            padding: 10px 20px;
            background-color: #007BFF;
            color: #fff;
            text-decoration: none;
            border-radius: 5px;
        }
        .footer {
            margin-top: 20px;
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="logo">
            <img src="logo.png" alt="Checkpoint Now Logo">
        </div>
        <div class="content">
            <h2>Welcome to Our Platform - Account Details</h2>
            <p>We are thrilled to welcome you to our platform Checkpoint Now! Your account has been successfully created by our Admin, and we're excited to have you onboard.</p>
            <p>Here are your account details:</p>
            <ul>
                <li><strong>Email:</strong> ${userDetails.email}</li>
            </ul>
            <p>Please note that for security reasons, we have generated a temporary password for you. Upon logging in, you will be prompted to change your password to a more secure one.</p>
            <p>To get started, click on the link below to access our platform:</p>
            <a class="btn" href=${link}>Access Platform</a>
            <p>With your account, you'll have access to a wide range of features and services. Our platform offers a user-friendly interface, making it easy for you to navigate and utilize all the resources available.</p>
            <p>If you have any questions or encounter any issues while using our platform, feel free to reach out to our support team at <a href="mailto:[Support Email Address]">[Support Email Address]</a>. We're here to assist you every step of the way.</p>
            <p>Thank you for joining us! We look forward to seeing you thrive and achieve great things on our platform.</p>
            <p>Best regards,<br>CPN- Team</p>
        </div>
        <div class="footer">
            <p>&copy; 2023 Checkpoint Now. All rights reserved.</p>
        </div>
    </div>
</body>
</html>`;

  const mailBody = {
    from: "<do_not_reply@gmail.com>",
    to: userDetails.email,
    subject: subject,
    html: html
  };

  console.log(await transporter.sendMail(mailBody));
};
export const sendPatientCancelationEmail = async (userDetails: any, subject: string, userType: number) => {
  const transporter = createTransport({
    service: 'GMAIL',
    auth: {
      user: CONFIG.EMAIL,
      pass: CONFIG.PASSWORD
    },
    port: 465,
    host: 'smtp.gmail.com'
  });
  let link = ""
  if (userType == 1) {
    link = "http://15.206.13.50:4000/signup-as-patient-1"
  } else if (userType == 2) {
    link = "http://15.206.13.50:4000/signup-as-expert-1"
  } else {
    link = "http://15.206.13.50:4000"
  }
  const html = `
  <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Appointment Cancellation</title>
    <style>
        /* Reset some default styles for email clients */
        body, p {
            margin: 0;
            padding: 0;
        }

        /* Define a wrapper for the email content */
        .email-wrapper {
            max-width: 600px;
            margin: 0 auto;
            padding: 20px;
            font-family: Arial, sans-serif;
            background-color: #f5f5f5;
        }

        /* Style the header */
        .header {
            text-align: center;
            background-color: #007BFF;
            padding: 20px 0;
            color: #fff;
        }

        /* Style the main content */
        .content {
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
        }

        /* Style the cancellation notice */
        .cancellation-notice {
            font-size: 18px;
            margin-bottom: 20px;
        }

        /* Style the cancellation reason */
        .cancellation-reason {
            font-weight: bold;
            color: #ff0000;
        }

        /* Style the contact information */
        .contact-info {
            margin-top: 20px;
        }

        /* Style the footer */
        .footer {
            text-align: center;
            background-color: #007BFF;
            color: #fff;
            padding: 10px 0;
        }
    </style>
</head>
<body>
    <div class="email-wrapper">
        <div class="header">
            <h1>Appointment Cancellation</h1>
        </div>
        <div class="content">
            <p class="cancellation-notice">
                We regret to inform you that your appointment has been <span class="cancellation-reason">canceled</span> due to unforeseen circumstances.
            </p>
            <p>
                If you have any questions or need to reschedule, please feel free to contact us:
            </p>
            <div class="contact-info">
                <p>Email: <a href="mailto:contact@example.com">contact@example.com</a></p>
                <p>Phone: +1 (123) 456-7890</p>
            </div>
        </div>
        <div class="footer">
            <p>&copy; 2023 Your Company Name</p>
        </div>
    </div>
</body>
</html>`;

  const mailBody = {
    from: "<do_not_reply@gmail.com>",
    to: userDetails.email,
    subject: subject,
    html: html
  };

  console.log(await transporter.sendMail(mailBody));
};
export const sendExpertCancelationEmail = async (userDetails: any, subject: string, userType: number) => {
  const transporter = createTransport({
    service: 'GMAIL',
    auth: {
      user: CONFIG.EMAIL,
      pass: CONFIG.PASSWORD
    },
    port: 465,
    host: 'smtp.gmail.com'
  });
  let link = ""
  if (userType == 1) {
    link = "http://15.206.13.50:4000/signup-as-patient-1"
  } else if (userType == 2) {
    link = "http://15.206.13.50:4000/signup-as-expert-1"
  } else {
    link = "http://15.206.13.50:4000"
  }
  const html = `
  <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Appointment Cancellation</title>
    <style>
        /* Reset some default styles for email clients */
        body, p {
            margin: 0;
            padding: 0;
        }

        /* Define a wrapper for the email content */
        .email-wrapper {
            max-width: 600px;
            margin: 0 auto;
            padding: 20px;
            font-family: Arial, sans-serif;
            background-color: #f5f5f5;
        }

        /* Style the header */
        .header {
            text-align: center;
            background-color: #007BFF;
            padding: 20px 0;
            color: #fff;
        }

        /* Style the main content */
        .content {
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
        }

        /* Style the cancellation notice */
        .cancellation-notice {
            font-size: 18px;
            margin-bottom: 20px;
        }

        /* Style the cancellation reason */
        .cancellation-reason {
            font-weight: bold;
            color: #ff0000;
        }

        /* Style the contact information */
        .contact-info {
            margin-top: 20px;
        }

        /* Style the footer */
        .footer {
            text-align: center;
            background-color: #007BFF;
            color: #fff;
            padding: 10px 0;
        }
    </style>
</head>
<body>
    <div class="email-wrapper">
        <div class="header">
            <h1>Appointment Cancellation</h1>
        </div>
        <div class="content">
            <p class="cancellation-notice">
                We regret to inform you that your appointment has been <span class="cancellation-reason">canceled</span> due to unforeseen circumstances.
            </p>
            <p>
                If you have any questions or need to reschedule, please feel free to contact us:
            </p>
            <div class="contact-info">
                <p>Email: <a href="mailto:contact@example.com">contact@example.com</a></p>
                <p>Phone: +1 (123) 456-7890</p>
            </div>
        </div>
        <div class="footer">
            <p>&copy; 2023 Your Company Name</p>
        </div>
    </div>
</body>
</html>`;

  const mailBody = {
    from: "<do_not_reply@gmail.com>",
    to: userDetails.email,
    subject: subject,
    html: html
  };

  console.log(await transporter.sendMail(mailBody));
};

export default sendMail;