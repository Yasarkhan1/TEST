import * as bcryptjs from 'bcryptjs';
import * as JWT from 'jsonwebtoken';
import CONFIG from '../../config/config';

class EncryptionService {

    getToken = async (user: any) => {
        return await JWT.sign({
            iss: 'alassacrm.user',
            _id: user._id,
            role:user.role,
            iat: new Date().getTime(),
            exp: new Date().setDate(new Date().getDate() + 1)
        }, CONFIG.JWT_SECRET)
    }

    getTokenConslant = async (user: any) => {
        return await JWT.sign({
            iss: 'alassacrm.consultant',
            _id: user._id,
            role:user.role,
            iat: new Date().getTime(),
            exp: new Date().setDate(new Date().getDate() + 1)
        }, CONFIG.JWT_SECRETCONSLTANT)
    }

    getPassword = async (pwt: string) => {
        const salt = await bcryptjs.genSalt(10);
        return await bcryptjs.hash(pwt, salt);
    }

    verifyPassword = async (pwt: string, hashPwt: string) => {
        return await bcryptjs.compare(pwt, hashPwt);
    }
    getOTP=async () => {
        var otp = Math.floor(1000 + Math.random() * 9000);
        return otp; 
    }
}

export default  new EncryptionService();