class UtilityService { }

export default new UtilityService();