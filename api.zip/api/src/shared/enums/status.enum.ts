export enum UserStatusEnum {
    ACTIVE = 1,
    IN_ACTIVE = 0
}

export enum ApprovalStatusEnum {
    PENDING = 1,
    APPROVED = 2,
    REJECTED = 3
}

export enum OrderStatusEnum {
    SALES_ORDER = 1,
    SEND_TECH_REVIEW = 2,
    RETURN_TECH = 3,
    APPROVED_TECH = 4,
    REQ_PRODUCTION = 5,
    PERCHASE_ORDER_RAISED = 6,
    INVENTORY_RECEIVED = 7,
    REQ_DELIVERY = 8,
    PARTIAL_DELIVERY = 9,
    DELIVERIED = 10,
    PARTIALLY_FITTED = 11,
    COMPLETELY_FITTED = 12
}

export enum TransactionStatus {
    IN_PROGRESS = 0,
    CLEAR = 1,
    FAILED = 2,
}
export enum Country {
    USA = "United States",
    CAN = "Canada",
    UK = "United Kingdom",
    AUS = "Australia",
    GER = "Germany",
    FRA = "France",
    JPN = "Japan",
    CHN = "China",
    IND = "India",
    BRA = "Brazil"
  }