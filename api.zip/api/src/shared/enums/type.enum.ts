export enum OrderTypeEnum {
    SALES_OFFER = 'sales_offer',
    SALES_ORDER = 'sales_order',
}

export enum OrderStatusTypeEnum {
    SALES_OFFER = 'sales_offer',
    SALES_ORDER = 'sales_order',
    SEND_FOR_TECH = 'send_tech_review',
    RETURNED_FROM_TECH = 'returned_from_tech',
    APPROVED_BY_TECH = 'approved_by_tech',
    PROD_REQUEST = 'prod_request',
    PURCHASE_ORDER_RAISED = 'purchase_order_raised',
    INVENTORY_RECEIVED = 'inventory_received',
    REQ_FOR_DELIVERY = 'req_for_delivery',
    DELIVERED = 'delivered',
    PARTIAL_DELIVERY = 'partial_delivery',
    PARTIALLY_FITTED = 'partially_fitted',
    COMPLETELY_FITTED = 'completely_fitted'
}

export enum ApprovalStatusTypeEnum {
    APPROVED = 'approved',
    PENDING = 'pending',
    REJECTED = 'rejected'
}

export enum NotificationType {
    SALE_OFFER_CREATED = 'sales_offer_created',
    SALE_OFFER_UPDATED = 'sales_offer_updated',
    SALE_OFFER_APPROVED = 'sales_offer_approved',
    SALE_OFFER_REJECTED = 'sales_offer_rejected',
    SALE_ORDER_CREATED = 'sales_order_created',
    SALE_ORDER_UPDATED = 'sales_order_updated',
    SALE_ORDER_APPROVED = 'sales_order_approved',
    SALE_ORDER_REJECTED = 'sales_order_rejected',
}

export enum AlertType {
    SUCCESS = 'success',
    INFO = 'info',
    WARNING = 'warning',
    ERROR = 'error',
}

export enum UserType {
    SUPER_ADMIN = 'super_admin',
    ADMIN = 'admin',
    AREA_MANAGER = 'area_manager',
    BRAND_MANAGER = 'brand_manager',
    BRANCH_MANAGER = 'branch_manager',
    SALE_EXECUTIVE = 'sales_executive',
}

export enum TransactionType {
    CASE = 1,
    CHEQUE = 2,
    NET_BANKING = 3
}

export interface ExpertData {
    name: string;
    _id: string
}
export const expertNeed: ExpertData[] = [
    {
        name: "ExpertData1",
        _id: "64df87470e57dd4b8049d6f0"
    },
    {
        name: "ExpertData2",
        _id: "64df87470e57dd4b8049d6f0"
    },
];

export interface SoonData {
    name: string;
    _id: string
}
export const soon: SoonData[] = [
    {
        name: "Soon1",
        _id: "64df87470e57dd4b8049d6f0"
    },
    {
        name: "Soon2",
        _id: "64df87470e57dd4b8049d6f0"
    },
];

export const heightOptions = [
    { label: '150 - 170 cm', value: 160 },
];

export const weightOptions = [
    { label: '45 - 65 kg', value: 55 },
];

export const ageOptions = [
    { label: '18 - 30 years', value: 25 },
];

export const Cancer = [
    { label: 'I', value: "I" },
    { label: 'II', value: "II" },
    { label: 'III', value: "III" },
    { label: 'IV', value: "IV" },
]
export const chemotherapy = [
    { label: 'Yes', value: 'Yes' },
    { label: 'No', value: 'No' }
];

export const targtedTherapies = [
    { label: 'Yes', value: 'Yes' },
    { label: 'No', value: 'No' }
];

export const Radiation = [
    { label: 'Yes', value: 'Yes' },
    { label: 'No', value: 'No' }
];
export const immunotherapies = [
    { label: 'Yes', value: 'Yes' },
    { label: 'No', value: 'No' }
];
export const surgery = [
    { label: 'Yes', value: 'Yes' },
    { label: 'No', value: 'No' }
];
export const merried = [
    { label: 'Yes', value: 'Yes' },
    { label: 'No', value: 'No' }
];
export const employed = [
{ label: 'Yes', value: 'Yes' },
{ label: 'No', value: 'No' }
]
const currentYear = new Date().getFullYear();
export const yearOptions = Array.from({ length: 50 }, (_, index) => ({
    label: (currentYear - index).toString(),
    value: currentYear - index,
}));
export const relationshipOptions = [
    { label: 'Father', value: 'Father' },
    { label: 'Mother', value: 'Mother' },
    { label: 'Maternal Grandfather', value: 'Maternal Grandfather' },
    { label: 'Paternal Grandfather', value: 'Paternal Grandfather' },
    { label: 'Maternal Grandmother', value: 'Maternal Grandmother' },
    { label: 'Paternal Grandmother', value: 'Paternal Grandmother' },
    { label: 'Sister', value: 'Sister' },
    { label: 'Brother', value: 'Brother' },  
    { label: 'Uncle', value: 'Uncle' },
    { label: 'Aunt', value: 'Aunt' }  
];

export const alcohalUse= [
    { label: 'Yes', value: 'Yes' },
    { label: 'No', value: 'No' }
];
export const tobaccoUse= [
    { label: 'Yes', value: 'Yes' },
    { label: 'No', value: 'No' }
];


export const alcohalParWeek= [
    { label: '1', value: '1' },
    { label: '2', value: '2' }
];

export const tobaccoParDay= [
    { label: '1', value: '1' },
    { label: '2', value: '2' }
];

export const recreationalDrug=[
    { label: '1', value: '1' },
    { label: '2', value: '2' }
]

export const frequencyOptions = [
    { label: 'Once a day', value: 'once_day' },
    { label: 'Twice a day', value: 'twice_day' },
    { label: 'Three times a day', value: 'three_times_day' },
];

export const paymentOption =[
    { label: 'Master', value: 'Master' },
    { label: 'Visa', value: 'Visa' },
]

export const specialtiesOption =[
    { label: 'Endocrinology', value: 'Endocrinology' },
    { label: 'Gastroenterology', value: 'Gastroenterology' },
    { label: 'Pulmonology', value: 'Pulmonology' },
    { label: 'Hepatology', value: 'Hepatology' },
    { label: 'Neurology', value: 'Neurology' },
    { label: 'Rheumatology', value: 'Rheumatology' },
    { label: 'Dermatology', value: 'Dermatology' },
    { label: 'Cardiology', value: 'Cardiology' },
    { label: 'Nephrology', value: 'Nephrology' },
]

export const  medicalCourseOptions = [
    { label: 'MBBS', value: 'mbbs' },
    { label: 'BUMS', value: 'bums' },
    { label: 'BDS', value: 'bds' },
    { label: 'BHMS', value: 'bhms' },
    { label: 'BAMS', value: 'bams' },
    { label: 'BNYS', value: 'bnys' },
    { label: 'BPT', value: 'bpt' },
    { label: 'B.Sc Nursing', value: 'bsc-nursing' },
    { label: 'Pharmacy (B.Pharm)', value: 'bpharm' },
    { label: 'Physiotherapy (BPT)', value: 'physiotherapy' },
    { label: 'Optometry (B.Optom)', value: 'optometry' },
    { label: 'Radiology (B.Sc)', value: 'radiology' },
    { label: 'Pathology (B.Sc)', value: 'pathology' },
    { label: 'Nursing (B.Sc)', value: 'nursing' },
    { label: 'Ayurveda Nursing', value: 'ayurveda-nursing' },
    { label: 'Medical Lab Technology', value: 'mlt' },
    { label: 'Dental Hygiene', value: 'dental-hygiene' },
    { label: 'Anesthesia Technology', value: 'anesthesia-tech' },
    { label: 'Emergency Medical Technology', value: 'emt' },
    { label: 'Dialysis Technology', value: 'dialysis-tech' },
];

