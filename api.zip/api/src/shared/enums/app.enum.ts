import { ApprovalStatusEnum, OrderStatusEnum, TransactionStatus, UserStatusEnum } from "./status.enum";
import { AlertType, ApprovalStatusTypeEnum, NotificationType, OrderTypeEnum, TransactionType, UserType, OrderStatusTypeEnum } from "./type.enum";
import { PermissionEnum } from "./permission.enum";
import {Country  }  from "./status.enum";

export const APP_ENUMS = {
    TYPE: {
        APPROVAL_STATUS: ApprovalStatusTypeEnum,
        ORDER: OrderTypeEnum,
        NOTIFICATION: NotificationType,
        ALERT: AlertType,
        USER_TYPE: UserType,
        TRANSACTION: TransactionType,
        ORDER_STATUS: OrderStatusTypeEnum
    },
    PERMISSION: PermissionEnum,
    STATUS: {
        APPROVAL: ApprovalStatusEnum,
        USER: UserStatusEnum,
        ORDER: OrderStatusEnum,
        TRANSACTION: TransactionStatus
    },
    countries:[
        Country.USA,
        Country.CAN,
        Country.UK,
        Country.AUS,
        Country.GER,
        Country.FRA,
        Country.JPN,
        Country.CHN,
        Country.IND,
        Country.BRA
      ]
};